create view VIEW_PROGRESS_CSS as
select ddsrt.companyid,ddsrt.ddsrstudentid,ddsrt.subject,sum(ddsrt.time) time,max(ddsrt.type) type
        from ddsrtrainingrecord ddsrt
        group by ddsrt.companyid,ddsrt.ddsrstudentid,ddsrt.subject


/

