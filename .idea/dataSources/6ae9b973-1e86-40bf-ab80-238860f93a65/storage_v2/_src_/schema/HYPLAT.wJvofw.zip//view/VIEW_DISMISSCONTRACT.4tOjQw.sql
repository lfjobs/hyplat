create view VIEW_DISMISSCONTRACT as
select a.archiveskey
as dismisscontractkey,a.archivesid as contractid ,
s.staffID,s.staffName,s.sex,s.staffIdentityCard,
u.registerDate,a.contractSignDate,a.contractCode,
a.startValidity,a.endValidity,a.renewalDate,c.dimissionDate,
c.dimissionStatus,a.companyID from dt_hr_Staff s
join dtAudition u on s.staffID = u.staffID
join dtCOSDimissionStaff c  on u.staffID = c.staffID
join DT_ARCHIVES_ARCHIVES a on c.staffID = a.staffID where a.companyid=u.companyid and c.companyid = a.companyid


/

