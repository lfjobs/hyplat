create view VIEW_CONCOM as
select t."CCOMPANYKEY",t."CCOMPANYID",t."COMPANYNAME",t."ADDRESS",t."COMPANYADDR",t."COMPANYTEL",t."CRESPONSIBLE",t."RESPONSIBLETEL",t."REMARK",t."DEALIN",t."INDUSTRYTYPE",t."CUSTSTATUS" , c.contactconnectionkey , c.contactconnections ,c.contactconnectionid,c.companyid
from dtcontactcompany t, dtcontactconnection c where c.ccompanyid = t.ccompanyid


/

