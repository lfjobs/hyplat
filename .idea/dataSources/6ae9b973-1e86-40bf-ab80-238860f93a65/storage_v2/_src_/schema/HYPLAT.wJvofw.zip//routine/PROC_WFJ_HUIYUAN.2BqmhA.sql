create PROCEDURE          "PROC_WFJ_HUIYUAN" --生成会员卡预设数据 set serveroutput on;
is
v_count number(7);
v_guid  varchar2(50);
v_psd   number(6);
v_kahao number(9);
begin
  v_count:=1000;
   loop
   exit when v_count=0;
   v_guid:=sys_guid();
   select seq_huiyuan.nextval into v_kahao from dual;
   v_psd:=trunc(dbms_random.value(100000,999999));
   insert into dt_wfj_tempinfo ti (ti.tkey,ti.tsn,ti.tpas)
   values (v_guid,v_kahao,v_psd);
   insert into dt_wfj_huiyuan u (u.huiyuan_key,u.huiyuan_id,u.huiyuan_sn,u.huiyuan_pas)
   values
   (v_guid,v_guid,v_kahao,md5(v_psd));
   v_count:=v_count-1;
   if(v_count mod 10000 =0) then
   commit;
   dbms_output.put_line(v_count);
   end if;
  end loop;

end proc_wfj_huiyuan;


/

