create view VIEW_TEL_INFODEAL as
select a.id as recordid,a.userid,d.id as id,s.staffname,s.reference, a.telnumber,a.telcodetype,a.recordtype,a.customname,a.recordcontent,d.isdeal,a.company,d.company as dealcompany,a.recodedate,d.dealuser,d.dealdate,d.dealcontent,d.companyname
from dt_tel_telinrecord a
left Join dt_tel_telinrecorddeal d on a.id = d.telinrecordid
join dt_hr_staff s on a.userid = s.staffkey
UNION ALL

select b.id as recordid,b.userid,e.id as id,f.staffname,f.reference, b.telnumber,b.telcodetype,b.teltype,b.visiteduser,b.visitedcontent,NULL as isdeal,b.company,e.company as dealcompany,b.visitedtime,e.dealuser,e.dealdate,e.dealcontent,e.companyname
from dt_tel_teloutrecord b
left join dt_tel_telinrecorddeal e on e.teloutrecordid = b.id
join dt_hr_staff f on f.staffkey = b.userid


/

