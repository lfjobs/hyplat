create PROCEDURE          "PROC_TTES" 
is
v_count number(7);
begin
 null;
end proc_ttes;


/

