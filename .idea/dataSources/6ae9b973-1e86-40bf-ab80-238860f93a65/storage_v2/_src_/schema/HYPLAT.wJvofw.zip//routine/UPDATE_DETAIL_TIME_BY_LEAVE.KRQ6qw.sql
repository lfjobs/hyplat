create procedure update_detail_time_by_leave(v_days       in varchar2,
                                                        v_company_id in varchar2) is

  --定义游标类型
  type cus_cur_type is ref cursor return tb_elyc_trainer_leave%rowtype;

  --详细约车时间段游标
  c_teacher_leave cus_cur_type;
  --详细约车时间段行数据类型
  v_teacher_leave tb_elyc_trainer_leave%rowtype;
begin


  open c_teacher_leave for
              select *
      from tb_elyc_trainer_leave l
     where l.trainer_id in
           (select t.teacherid from tb_jp_teacher t where t.companyid = v_company_id)
       and  to_date(to_char(l.start_time,'yyyy-mm-dd'), 'yyyy-mm-dd') = to_date(v_days, 'yyyy-mm-dd');
            fetch c_teacher_leave
              into v_teacher_leave;
            --循环更新到教练详细可预约时间段表中
            while c_teacher_leave%found loop
              update tb_elyc_order_detail_time t
       set t.status       = '3',
           t.updatedate   = sysdate,
           t.updateperson = '数据库'
     where t.teacherid = v_teacher_leave.trainer_id
       and t.companyid = v_company_id
       and to_char(t.lessionstarttime, 'yyyy-mm-dd') = v_days
       and (((t.lessionstarttime between v_teacher_leave.start_time and
           v_teacher_leave.end_time) and
           t.lessionstarttime <> v_teacher_leave.end_time) or
           ((t.lessionendtime between v_teacher_leave.start_time and
           v_teacher_leave.end_time) and
           t.lessionendtime <> v_teacher_leave.start_time));
              commit;
              fetch c_teacher_leave into v_teacher_leave;
            end loop;




end update_detail_time_by_leave;
/

