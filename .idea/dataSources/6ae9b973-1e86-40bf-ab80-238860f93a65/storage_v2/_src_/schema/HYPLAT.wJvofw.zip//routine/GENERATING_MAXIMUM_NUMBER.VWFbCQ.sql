create PROCEDURE          "GENERATING_MAXIMUM_NUMBER" IS

ddate date;

cursor vcur_get_goodsnum is
  select goodsid,
         COMPANYID,
         CASHIERBILLSID,
         GOODSBILLSID,
         GOODSNUMBER,
         GOODSCODING,
         PRODUCTID
    from dtgoodsnum
   where gnkey = any
   (SELECT gnkey
            FROM (SELECT gnkey,
                         goodsid,
                         RANK() OVER(PARTITION BY goodsid ORDER BY goodsnumber desc) AS SeqNumber
                    FROM (SELECT gnkey, goodsid, goodsnumber
                            FROM Dtgoodsnum
                           WHERE goodsid in (SELECT goodsid
                                               FROM Dtgoodsnum
                                              GROUP BY goodsid
                                             HAVING COUNT(*) > 1)))
           WHERE SeqNumber = 1);

BEGIN
  select sysdate into ddate from dual;

  for num in  vcur_get_goodsnum loop
      insert into dtserialnumber
          (serialnumberKey,
           serialnumberID,
           companyID,
           goodsID,
           inventoryID,
           goodsnumber,
           datatime)
        values
          (get_Generate_Su('7', '0', '0'),
           get_table_ID('1', 'SerialNumber'),
           num.companyid,
           num.goodsID,
           num.cashierbillsid,
           num.goodsnumber,
           ddate);
  end loop;
END;


/

