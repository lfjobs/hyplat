create PROCEDURE          "PRO_COMMISSION_DESIGN" (vi_comid varchar2,
                                                  P_CURSOR OUT TESTPACKAGE.TEST_CURSOR, --返回的记录集
                                                  R_CURSOR OUT TESTPACKAGE.TEST_CURSOR) is

  vc_str_member varchar(5000);

  cursor VR_LAYOUT_ONE is
    select p.goodsname, m.me_number, yj_id
      from dt_pro_main m, dt_productpackaging p
     where p.ppid = m.code_id
       and dc_status = '00'
       and m.com_id = vi_comid
     order by me_number;

begin
  vc_str_member := 'select p1.goodsname,m.yj_id';
  for i in VR_LAYOUT_ONE loop
    vc_str_member := vc_str_member || ',max(decode(p.meid,''' || i.yj_id ||
                     ''',p.pro_money))' || i.goodsname;
  end loop;
  vc_str_member := vc_str_member ||
                   '  from dt_pro_layout p,dt_pro_main m,dt_productpackaging p1 where p.bsid=m.yj_id and m.com_id=''' ||
                   vi_comid ||
                   ''' and m.code_id=p1.ppid group by p1.goodsname,m.me_number,m.yj_id order by m.me_number';

  open P_CURSOR for vc_str_member;
  open R_CURSOR for
    select p1.goodsname, m.me_number, yj_id
      from dt_pro_main m, dt_productpackaging p1
     where p1.ppid = m.code_id
       and dc_status = '00'
       and m.com_id = vi_comid
     order by me_number;
end PRO_COMMISSION_DESIGN;


/

