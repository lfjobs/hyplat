create view VIEW_PROGRESS_CSSP as
select ddsrt.companyid,ddsrt.ddsrstudentid,ddsrt.subject,ddsrt.program,sum(ddsrt.time) time,max(ddsrt.type) type
        from ddsrtrainingrecord ddsrt
        group by ddsrt.companyid,ddsrt.ddsrstudentid,ddsrt.subject,ddsrt.program


/

