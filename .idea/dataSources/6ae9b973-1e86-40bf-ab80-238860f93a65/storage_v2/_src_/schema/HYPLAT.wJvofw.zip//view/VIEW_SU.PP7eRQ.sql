create view VIEW_SU as
select  DISTINCT
st.companyName,
st.staffname,
st.staffcode ,
jt.APPRAISALKEY,jt.APPRAISALID,jt.COMPANYID,jt.STAFFID,
jt.CHECKPERSON,jt.WORKDATESATURATION,jt.APPRAISALDATE,
jt.RESPONSIBILITY1,jt.RESPONSIBILITY2,jt.RESPONSIBILITY3,
jt.ACHIEVEMENTS1,jt.ACHIEVEMENTS2,jt.ACHIEVEMENTS3,
jt.TASK1,jt.TASK2,jt.TASK3,jt.ABILITY1,jt.ABILITY2,
jt.ABILITY3,jt.MANNER1,jt.MANNER2,jt.MANNER3,jt.STATUS

 from
dt_hr_staff_appraisal jt join view_sc st on
jt.staffid = st.staffid and jt.companyid = st.companyid


/

