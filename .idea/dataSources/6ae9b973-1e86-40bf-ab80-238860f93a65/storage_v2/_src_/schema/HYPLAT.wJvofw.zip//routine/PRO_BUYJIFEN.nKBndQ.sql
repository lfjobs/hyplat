create PROCEDURE PRO_BUYJIFEN(VI_COM_ID    VARCHAR2, --平台公司ID
                                         VI_JOU_NUM   VARCHAR2, --订单编号
                                         VI_STAFF_ID  VARCHAR2, --付款人ID
                                         VI_PRO_SCCID VARCHAR2, --付款人账号ID
                                         VI_MONEY     VARCHAR2, --购买金币金额数
                                         VI_APPSTYLE  VARCHAR2, --支付方式
                                         VI_MERSEQ_ID VARCHAR2 --第三方交易号
                                         ) IS
  --积分充值
  V_DDID      DTGOODSBILLS.GOODSBILLSID%TYPE; --订单物品ID
  V_CK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --出库单据ID
  V_RK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --入库单据ID
  V_NEW_CA_ID DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  V_NEW_GB_ID DTGOODSBILLS.GOODSBILLSID%TYPE; --物品单据ID
  V_CA_SK_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --收款单据ID
  --V_CA_ZK_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --支款单据ID
  V_ZK_JUM DTCASHIERBILLS.JOURNALNUM%TYPE; --支款单编号

  V_GOOD_BI_ID DTGOODSBILLS.GOODSBILLSID%TYPE; --购买产品单据ID
  V_GUIZE_ID   DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE; --积分规则ID

  V_CASH_ID DTCASHIERBILLS.CASHIERBILLSID%TYPE; --订单单据ID

  --当前会员信息
  V_COM_ID    T_ESHOP_CUSCOM.COMPANYID%TYPE; --当前会员公司ID
  V_COM_NAME  DTCOMPANY.COMPANYNAME%TYPE; --公司名称
  V_G_SN      DTCOMPANY.GROUPCOMPANYSN%TYPE; --集团组织机构
  V_CNAME     DTCOMPANY.COMPANYNAME%TYPE; --平台公司名称
  V_GSN       DTCOMPANY.GROUPCOMPANYSN%TYPE; --平台集团组织机构
  V_NEW_JF_ID DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE; --新生成金币表ID

  V_S_NAME    DT_HR_STAFF.STAFFNAME%TYPE; --操作人姓名
  V_S_CODE    DT_HR_STAFF.STAFFCODE%TYPE; --操作人编号
  V_S_ACCOUNT T_ESHOP_CUSCOM.ACCOUNT%TYPE; --操作人微分金账号账号

  --仓库信息
  V_DEPOT_ID     DTDEPOTMANAGE.DEPOTID%TYPE; --仓库ID
  V_DEPOT_NAME   DTDEPOTMANAGE.DEPOTNAME%TYPE; --仓库名称
  V_DEPOT_ITEMID DTDEPOTMANAGE.ITEMID%TYPE; --仓库类别
  V_STOCK_TYPE   DT_INV_STOCKINVT.Type%TYPE; --库存盘点明细类型 00：入库 01：出库

  V_COUNTNUM NUMBER(5); --条数

  VII_MONEY NUMBER(20, 2); --积分数

BEGIN

  VII_MONEY := ROUND(TO_NUMBER(VI_MONEY) * 100, 2); --积分数

  --查询购买人信息
  SELECT S.STAFFNAME, S.STAFFCODE
    INTO V_S_NAME, V_S_CODE
    FROM DT_HR_STAFF S
   WHERE S.STAFFID = VI_STAFF_ID;

  SELECT T.ACCOUNT
    INTO V_S_ACCOUNT
    FROM T_ESHOP_CUSCOM T
   WHERE T.SCCID = VI_PRO_SCCID;

  --查询平台公司名称、组织机构id
  SELECT C.COMPANYNAME, C.GROUPCOMPANYSN
    INTO V_CNAME, V_GSN
    FROM DTCOMPANY C
   WHERE C.COMPANYID = VI_COM_ID;
  -----------------------------------------------购买积分人员订单收支款单--------------------------------------

  IF VI_MERSEQ_ID IS NOT NULL AND VI_MONEY IS NOT NULL THEN
  
    V_COUNTNUM := 0;
  
    SELECT COUNT(*)
      INTO V_COUNTNUM
      FROM DT_INV_INVT I
     WHERE GOODSNAME = '微分金积分'
       AND COMPANYID = VI_COM_ID
       AND I.INVENQUANTITY >= VII_MONEY
       AND WAREHOUSENAME = '销售库';
  
    IF V_COUNTNUM > 0 THEN
    
      V_COUNTNUM := 0;
    
      SELECT COUNT(*)
        INTO V_COUNTNUM
        FROM DTPAYCASHIERBILL
       WHERE TRADE_NO = VI_MERSEQ_ID;
    
      IF V_COUNTNUM <= 0 THEN
      
        V_COUNTNUM := 0;
      
        --资金仓库信息
        SELECT D.DEPOTNAME, D.DEPOTID, D.ITEMID
          INTO V_DEPOT_NAME, V_DEPOT_ID, V_DEPOT_ITEMID
          FROM DTDEPOTMANAGE D
         WHERE D.COMPANYID = VI_COM_ID
           AND D.DEPOTPID = '003'
           AND D.DEPOTNAME = '资金仓库';
      
        INSERT INTO DTPAYCASHIERBILL
          (GNKEY, PCBID, PAYJOURNALNUM, ORIJOURNALNUM, TRADE_NO)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           FUN_GET_ID('pcbid'),
           VI_JOU_NUM,
           VI_JOU_NUM,
           VI_MERSEQ_ID);
      
        --订单
        V_CASH_ID := FUN_GET_ID('cashiertally');
        INSERT INTO DTCASHIERBILLS
          (CASHIERBILLSKEY,
           CASHIERBILLSID,
           COMPANYID,
           BILLSTYPE,
           JOURNALNUM,
           STAFFID,
           STAFFNAME,
           STAFFCODE,
           CASHIERDATE,
           STATUS,
           FKSTATUS,
           WFSTATUS1,
           WFSTATUS4,
           COMPANYNAME,
           PROID,
           PROJECTNAME, --项目名称
           GROUPCOMPANYSN,
           INPUTID,
           INPUTNAME,
           APPSTYLE,
           PRICESUB,
           CONTACTUSERID,
           CTUSERNAME,
           STATUSBILL,
           TRADE_NO, --第三方交易号
           JNUMORDER)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           V_CASH_ID,
           VI_COM_ID,
           '项目收入预算单',
           VI_JOU_NUM,
           '', --购买人ID
           '系统生成', --购买人名称
           '', --购买人编号
           SYSDATE,
           '15', --已入库
           '04', --已分配积分
           '00',
           VI_APPSTYLE,
           V_CNAME, --公司名称
           '007',
           '购买积分',
           V_GSN, --集团组织机构ID
           VI_STAFF_ID, --制单人ID
           V_S_NAME, --制单人名称
           VI_APPSTYLE,
           VI_MONEY,
           VI_STAFF_ID,
           V_S_NAME,
           '04',
           VI_MERSEQ_ID,
           VI_JOU_NUM);
      
        --订单收发货表
        INSERT INTO DT_ORDER_BILL_ADD
          (OA_KEY,
           OA_ID,
           OA_COM_ID,
           OA_STAFF_ID,
           OA_BILL_ID,
           OA_BILL_JOUNUM,
           RECEIVENAME,
           RECEIVETEL,
           OA_GYS_ID,
           OA_SCCID)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           FUN_GET_ID('DtOrderBillAdd'),
           VI_COM_ID,
           VI_STAFF_ID,
           V_CASH_ID,
           VI_JOU_NUM,
           V_S_NAME,
           V_S_ACCOUNT,
           VI_COM_ID, --供应商id
           VI_PRO_SCCID);
      
        V_GOOD_BI_ID := FUN_GET_ID('goodsbills');
        INSERT INTO DTGOODSBILLS
          (GOODSBILLSKEY,
           GOODSBILLSID,
           CASHIERBILLSID,
           SUBJECTSID,
           SUBJECTSNAME,
           COSTTYPE, --费用类别
           PAYTYPE, --付款方式
           WEIGHT,
           GOODSID,
           QUANTITY,
           PRICE,
           MONEY,
           GOODSVARIABLEID, --单位
           IDENTIFYINGCODE, --00
           BATCHNUMBER, --批号
           GOODSNOMBER, --物品在账单中的排列序号
           GOODSNUM,
           GOODSNAME,
           TYPEID,
           STANDARD,
           KCSTATUS, --15：已入库
           GOODSTATUS, --状态00正常 01维修02报废
           PPID)
          SELECT DBMS_RANDOM.STRING('X', 32),
                 V_GOOD_BI_ID,
                 V_CASH_ID,
                 A.SUBJECTID,
                 A.SUBJECTNAME,
                 '', --费用类别
                 VI_APPSTYLE,
                 A.WEIGHT,
                 A.GOODSID,
                 TO_CHAR(VII_MONEY,
                         'fm999999999999999999999999999999990.999999999'),
                 '0.01',
                 TO_CHAR(ROUND(VI_MONEY, 2),
                         'fm999999999999999999999999999999990.999999999'),
                 A.VARIABLEID,
                 '00',
                 '',
                 '1',
                 A.GOODSNUM,
                 A.GOODSNAME,
                 A.TYPE,
                 A.STANDARD,
                 '15',
                 '00',
                 A.PPID
            FROM DT_PRODUCTPACKAGING A
           WHERE A.COMPANYID = VI_COM_ID
             AND A.GOODSNAME = '微分金积分';
      
        --收款单（平台收入）
        V_CA_SK_ID := FUN_GET_ID('cashiertally');
        INSERT INTO DTCASHIERBILLS
          (CASHIERBILLSKEY,
           CASHIERBILLSID,
           COMPANYID,
           BILLSTYPE,
           JOURNALNUM,
           STAFFID,
           STAFFNAME,
           STAFFCODE,
           CASHIERDATE,
           STATUS,
           FKSTATUS,
           WFSTATUS1,
           WFSTATUS4,
           COMPANYNAME,
           PROID,
           PROJECTNAME, --项目名称
           GROUPCOMPANYSN,
           INPUTID,
           INPUTNAME,
           APPSTYLE,
           PRICESUB,
           CCOMPANYID,
           CCOMPANYNAME,
           STATUSBILL,
           TRADE_NO, --第三方交易号
           JNUMORDER)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           V_CA_SK_ID,
           VI_COM_ID,
           '收款单',
           FUN_GET_BILL_ID(),
           '',
           '系统生成', --会员名称
           '', --会员编号
           SYSDATE,
           '15', --已入库
           '04',
           '00',
           VI_APPSTYLE,
           V_CNAME, --公司名称
           '007',
           '购买积分',
           V_GSN, --集团组织机构ID
           '',
           '系统生成',
           VI_APPSTYLE,
           VI_MONEY,
           '',
           '',
           '04',
           VI_MERSEQ_ID,
           VI_JOU_NUM);
      
        --商品表
        V_NEW_GB_ID := FUN_GET_ID('goodsbills');
        INSERT INTO DTGOODSBILLS
          (GOODSBILLSKEY,
           GOODSBILLSID,
           CASHIERBILLSID,
           SUBJECTSID,
           SUBJECTSNAME,
           COSTTYPE, --费用类别
           PAYTYPE, --付款方式
           WEIGHT,
           GOODSID,
           QUANTITY,
           PRICE,
           MONEY,
           GOODSVARIABLEID, --单位
           IDENTIFYINGCODE, --00
           BATCHNUMBER, --批号
           GOODSNOMBER, --物品在账单中的排列序号
           GOODSNUM,
           GOODSNAME,
           TYPEID,
           STANDARD,
           KCSTATUS, --15：入出库
           GOODSTATUS, --状态00正常 01维修02报废
           PPID)
          SELECT DBMS_RANDOM.STRING('X', 32),
                 V_NEW_GB_ID,
                 V_CA_SK_ID,
                 A.SUBJECTID,
                 A.SUBJECTNAME,
                 '', --费用类别
                 VI_APPSTYLE,
                 A.WEIGHT,
                 A.GOODSID,
                 TO_CHAR(VII_MONEY,
                         'fm999999999999999999999999999999990.999999999'),
                 '0.01',
                 TO_CHAR(ROUND(VI_MONEY, 2),
                         'fm999999999999999999999999999999990.999999999'),
                 A.VARIABLEID,
                 '00',
                 '',
                 '1',
                 A.GOODSNUM,
                 A.GOODSNAME,
                 A.TYPE,
                 A.STANDARD,
                 '15',
                 '00',
                 A.PPID
            FROM DT_PRODUCTPACKAGING A
           WHERE A.COMPANYID = VI_COM_ID
             AND A.GOODSNAME = '微分金积分';
      
        --转账表
        INSERT INTO DTCASHAPPLYBILLS
          (CASHAPPLYBILLSKEY,
           CASHAPPLYBILLSID,
           APPROPRIATIONMONEY, --付款金额
           APPROPRIATIONDATE, --付款时间
           APPROPRIATESTATUS, --付款状态 00：未付款  01：已付款  02：暂不付款
           APPROPRIATIONNUM, --付款账号
           PROJECTNAME, --项目名称
           CASHIERBILLSID,
           APPROPRIATIONCOMPANYID, --付款方ID
           APPROPRIATIONCOMPANYNAME, --付款方NAME
           RECEIVABLESID, --收款方ID
           RECEIVABLESNAME, --收款方NAME
           RECROPRIATIONNUM, --收款账号
           APPSTYLE) --付款方式
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           FUN_GET_ID('cashapply'),
           VI_MONEY,
           SYSDATE,
           '01',
           '', --付款账号
           '购买积分',
           V_CA_SK_ID,
           V_COM_ID,
           V_COM_NAME,
           V_COM_ID,
           '北京天太世统科技有限责任公司',
           '',
           VI_APPSTYLE);
      
        -------------------------------------生成积分出入库单据----------------------------------------
      
        --收支款单产品保存 2
        --进销存单据表
        INSERT INTO DT_INV_FB
          (FINANCIALBILLKEY,
           FINANCIALBILLID,
           GROUPCOMPANYSN,
           COMPANYID,
           ORGANIZATIONID,
           DEPARTMENTID,
           BILLSTATUS,
           BILLSTYPE,
           BILLSDATE,
           BILLSTAFFID,
           BILLSTAFFNAME,
           DEPOTID,
           DEPOTNAME,
           CASHIERBILLSID)
          SELECT DBMS_RANDOM.STRING('X', 32),
                 FUN_GET_ID('financial'),
                 A.GROUPCOMPANYSN,
                 A.COMPANYID,
                 A.ORGANIZATIONID,
                 A.DEPARTMENTID,
                 '15',
                 '收款单',
                 SYSDATE,
                 A.INPUTID,
                 A.INPUTNAME,
                 V_DEPOT_ID,
                 V_DEPOT_NAME,
                 V_CA_SK_ID
            FROM DTCASHIERBILLS A
           WHERE A.CASHIERBILLSID = V_DDID;
      
        SELECT COUNT(*)
          INTO V_COUNTNUM
          FROM DT_PRODUCTPACKAGING A
         WHERE A.COMPANYID = VI_COM_ID
           AND A.GOODSNAME = '银行存款';
        
        IF V_COUNTNUM > 0 THEN
          --平台现金库存盘点表
          INSERT INTO DT_INV_STOCKINVT
            (STOCKINVKEY,
             STOCKINVID,
             COMPANYID,
             GROUPCOMPANYSN,
             GOODSID,
             GOODSTYPE,
             GOODSNAME,
             INVENQUANTITY,
             TYPE,
             STAFFID,
             STAFFNAME,
             WAREHOUSE,
             WAREHOUSENAME,
             GOODSBILLSID,
             intime)
            SELECT DBMS_RANDOM.STRING('X', 32),
                   FUN_GET_ID('STOCKINV'),
                   VI_COM_ID,
                   '',
                   A.GOODSID,
                   A.TYPE,
                   A.GOODSNAME,
                   VI_MONEY,
                   '01',
                   VI_STAFF_ID,
                   V_S_NAME,
                   V_DEPOT_ID,
                   V_DEPOT_NAME,
                   V_NEW_GB_ID,
                   Sysdate
              FROM DT_PRODUCTPACKAGING A
             WHERE A.COMPANYID = VI_COM_ID
               AND A.GOODSNAME = '银行存款';
        
        ELSE
        
          INSERT INTO DT_INV_STOCKINVT
            (STOCKINVKEY,
             STOCKINVID,
             COMPANYID,
             GROUPCOMPANYSN,
             GOODSNAME,
             INVENQUANTITY,
             TYPE,
             STAFFID,
             STAFFNAME,
             WAREHOUSE,
             WAREHOUSENAME,
             GOODSBILLSID,
             intime)
          VALUES
            (DBMS_RANDOM.STRING('X', 32),
             FUN_GET_ID('stockinv'),
             VI_COM_ID,
             '',
             '银行存款',
             VI_MONEY,
             '01',
             VI_STAFF_ID,
             V_S_NAME,
             V_DEPOT_ID,
             V_DEPOT_NAME,
             V_NEW_GB_ID,
             sysdate);
        
        END IF;
      
        --平台现金库存表
        UPDATE DT_INV_INVT
           SET INVENQUANTITY = TO_CHAR(TO_NUMBER(NVL(INVENQUANTITY, 0)) +
                                       VI_MONEY,
                                       'FM999999999999999999999999999999990.999999999'),
               SUMPRICE      = TO_CHAR(TO_NUMBER(NVL(SUMPRICE, 0)) +
                                       VI_MONEY,
                                       'FM999999999999999999999999999999990.999999999')
         WHERE GOODSNAME = '银行存款'
           AND WAREHOUSE = V_DEPOT_ID
           AND COMPANYID = VI_COM_ID
           AND SOURCE = '销售盈利';
      
        IF SQL%NOTFOUND THEN
        
          --平台现金库存表
          UPDATE DT_INV_INVT
             SET INVENQUANTITY = TO_CHAR(TO_NUMBER(NVL(INVENQUANTITY, 0)) +
                                         VI_MONEY,
                                         'FM999999999999999999999999999999990.999999999'),
                 SUMPRICE      = TO_CHAR(TO_NUMBER(NVL(SUMPRICE, 0)) +
                                         VI_MONEY,
                                         'FM999999999999999999999999999999990.999999999')
           WHERE GOODSNAME = '银行存款'
             AND WAREHOUSE = V_DEPOT_ID
             AND COMPANYID = VI_COM_ID
             AND SOURCE = '上级拨款';
        
          IF SQL%NOTFOUND THEN
          
            INSERT INTO DT_INV_INVT
              (INVENTORYKEY,
               INVENTORYID,
               COMPANYID,
               GROUPCOMPANYSN,
               WAREHOUSE,
               GOODSNAME,
               UNIT,
               UNITPRICE,
               INVENQUANTITY,
               SUMPRICE,
               SOURCE)
            VALUES
              (DBMS_RANDOM.STRING('X', 32),
               FUN_GET_ID('inventory'),
               VI_COM_ID,
               '',
               V_DEPOT_ID,
               '银行存款',
               '元',
               '1',
               VI_MONEY,
               VI_MONEY,
               '销售盈利');
          
          END IF;
          
        END IF;
        
      END IF;
      
      --收支款单产品保存结束
    
      --查询会员公司名称
      IF V_COM_ID IS NOT NULL THEN
        SELECT C.COMPANYNAME, C.GROUPCOMPANYSN
          INTO V_COM_NAME, V_G_SN
          FROM DTCOMPANY C
         WHERE COMPANYID = V_COM_ID;
      
      ELSE
      
        SELECT T.COMPANYID, T.PSEUDO_COMPANY_NAME, C.GROUPCOMPANYSN
          INTO V_COM_ID, V_COM_NAME, V_G_SN
          FROM T_ESHOP_CUSCOM T
          LEFT JOIN DTCOMPANY C
            ON T.COMPANYID = C.COMPANYID
         WHERE T.COMPANYID IS NOT NULL
           AND ROWNUM = 1
         START WITH T.SCCID = VI_PRO_SCCID
        CONNECT BY PRIOR T.SUPPERSCCID = T.SCCID;
      
      END IF;
    
      --用户积分入库单
      V_RK_CA_ID := FUN_GET_ID('cashiertally');
    
      INSERT INTO DTCASHIERBILLS
        (CASHIERBILLSKEY,
         CASHIERBILLSID,
         COMPANYID,
         BILLSTYPE,
         JOURNALNUM,
         STAFFID,
         STAFFNAME,
         STAFFCODE,
         CASHIERDATE,
         STATUS,
         COMPANYNAME,
         PROID,
         PROJECTNAME, --项目名称
         GROUPCOMPANYSN,
         INPUTID,
         INPUTNAME,
         APPSTYLE,
         PRICESUB,
         CCOMPANYID,
         CCOMPANYNAME,
         STATUSBILL,
         JNUMORDER)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         V_RK_CA_ID,
         V_COM_ID,
         '积分入库单',
         FUN_GET_BILL_ID(),
         VI_STAFF_ID,
         V_S_NAME, --会员名称
         V_S_CODE, --会员编号
         SYSDATE,
         '15', --已入库
         V_COM_NAME, --公司名称
         '007',
         '积分购买',
         V_G_SN, --集团组织机构ID
         VI_STAFF_ID,
         V_S_NAME,
         '14',
         TO_CHAR(ROUND(VI_MONEY, 2),
                 'FM999999999999999999999999999999990.999999999'),
         VI_COM_ID,
         '北京天太世统科技有限责任公司',
         '04',
         VI_JOU_NUM);
    
      --添加关系表数据
      INSERT INTO DTRELATEDBILL
        (RBKEY, RBID, CASHID, CASHFID)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         FUN_GET_ID('relatedbill'),
         V_CASH_ID,
         V_RK_CA_ID);
    
      --平台积分出库单
      V_CK_CA_ID := FUN_GET_ID('cashiertally');
      V_ZK_JUM   := FUN_GET_BILL_ID();
    
      INSERT INTO DTCASHIERBILLS
        (CASHIERBILLSKEY,
         CASHIERBILLSID,
         COMPANYID,
         BILLSTYPE,
         JOURNALNUM,
         STAFFID,
         STAFFNAME,
         STAFFCODE,
         CASHIERDATE,
         STATUS,
         COMPANYNAME,
         PROID,
         PROJECTNAME, --项目名称
         GROUPCOMPANYSN,
         INPUTID,
         INPUTNAME,
         APPSTYLE,
         PRICESUB,
         CCOMPANYID,
         CCOMPANYNAME,
         STATUSBILL,
         JNUMORDER)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         V_CK_CA_ID,
         VI_COM_ID,
         '积分出库单',
         V_ZK_JUM,
         VI_STAFF_ID,
         V_S_NAME, --会员名称
         V_S_CODE, --会员编号
         SYSDATE,
         '16', --已出库
         V_CNAME, --公司名称
         '007',
         '积分购买',
         V_GSN, --集团组织机构ID
         VI_STAFF_ID,
         V_S_NAME,
         '14',
         TO_CHAR(ROUND(VI_MONEY, 2),
                 'fm999999999999999999999999999999990.999999999'),
         V_COM_ID,
         V_COM_NAME,
         '04',
         VI_JOU_NUM);
    
      --平台\用户积分出库\入库产品表
      FOR I IN 1 .. 2 LOOP
      
        IF I = 1 THEN
        
          V_DEPOT_NAME := '销售库';
          V_DEPOT_ID   := NULL;
          V_NEW_CA_ID  := V_RK_CA_ID;
          V_STOCK_TYPE := '00';
        
        ELSE
        
          SELECT D.DEPOTNAME, D.DEPOTID, D.ITEMID
            INTO V_DEPOT_NAME, V_DEPOT_ID, V_DEPOT_ITEMID
            FROM DTDEPOTMANAGE D
           WHERE D.COMPANYID = VI_COM_ID
             AND D.DEPOTPID = '001'
             AND D.DEPOTNAME = '销售库';
        
          V_NEW_CA_ID  := V_CK_CA_ID;
          V_STOCK_TYPE := '01';
        
        END IF;
      
        V_NEW_GB_ID := FUN_GET_ID('goodsbills');
      
        SELECT COUNT(*)
          INTO V_COUNTNUM
          FROM DT_PRODUCTPACKAGING A
         WHERE A.COMPANYID = VI_COM_ID
           AND A.GOODSNAME = '微分金积分';
        IF V_COUNTNUM > 0 THEN
          INSERT INTO DTGOODSBILLS
            (GOODSBILLSKEY,
             GOODSBILLSID,
             CASHIERBILLSID,
             SUBJECTSID,
             SUBJECTSNAME,
             COSTTYPE, --费用类别
             PAYTYPE, --付款方式
             WEIGHT,
             GOODSID,
             QUANTITY,
             PRICE,
             MONEY,
             DEPOTID, --库房ID
             DEPOTNAME, --库房名称
             GOODSVARIABLEID, --单位
             IDENTIFYINGCODE, --00
             BATCHNUMBER, --批号
             GOODSNOMBER, --物品在账单中的排列序号
             GOODSNUM,
             GOODSNAME,
             TYPEID,
             STANDARD,
             KCSTATUS, --15：已入库
             GOODSTATUS, --状态00正常 01维修02报废
             PPID)
            SELECT DBMS_RANDOM.STRING('X', 32),
                   V_NEW_GB_ID,
                   V_NEW_CA_ID,
                   A.SUBJECTID,
                   A.SUBJECTNAME,
                   '', --费用类别
                   VI_APPSTYLE,
                   A.WEIGHT,
                   A.GOODSID,
                   TO_CHAR(VII_MONEY,
                           'fm999999999999999999999999999999990.999999999'),
                   '0.01',
                   TO_CHAR(ROUND(VI_MONEY, 2),
                           'fm999999999999999999999999999999990.999999999'),
                   V_DEPOT_ID,
                   V_DEPOT_NAME,
                   A.VARIABLEID,
                   '00',
                   '',
                   '1',
                   A.GOODSNUM,
                   A.GOODSNAME,
                   A.TYPE,
                   A.STANDARD,
                   '15',
                   '00',
                   A.PPID
              FROM DT_PRODUCTPACKAGING A
             WHERE A.COMPANYID = VI_COM_ID
               AND A.GOODSNAME = '微分金积分';
        
        ELSE
          INSERT INTO DTGOODSBILLS
            (GOODSBILLSKEY,
             GOODSBILLSID,
             CASHIERBILLSID,
             PAYTYPE, --付款方式
             QUANTITY,
             PRICE,
             MONEY,
             DEPOTNAME, --库房名称
             IDENTIFYINGCODE, --00
             GOODSNAME,
             KCSTATUS, --15：已入库
             GOODSTATUS) --状态00正常 01维修02报废
          VALUES
            (DBMS_RANDOM.STRING('X', 32),
             V_NEW_GB_ID,
             V_NEW_CA_ID,
             VI_APPSTYLE,
             TO_CHAR(VII_MONEY,
                     'fm999999999999999999999999999999990.999999999'),
             '0.01',
             TO_CHAR(ROUND(VI_MONEY, 2),
                     'fm999999999999999999999999999999990.999999999'),
             '销售库',
             '00',
             '微分金积分',
             '15',
             '00');
        
        END IF;
      
        if i = 2 then
        
          --平台积分库存盘点表
        
          INSERT INTO DT_INV_STOCKINVT
            (STOCKINVKEY,
             STOCKINVID,
             COMPANYID,
             GROUPCOMPANYSN,
             GOODSID,
             GOODSTYPE,
             GOODSNAME,
             INVENQUANTITY,
             TYPE,
             STAFFID,
             SUMMONEY,
             STAFFNAME,
             WAREHOUSE,
             WAREHOUSENAME,
             GOODSBILLSID,
             intime)
            SELECT DBMS_RANDOM.STRING('X', 32),
                   FUN_GET_ID('stockinv'),
                   VI_COM_ID,
                   VI_COM_ID,
                   A.GOODSID,
                   A.TYPE,
                   A.GOODSNAME,
                   TO_CHAR(VII_MONEY,
                           'fm999999999999999999999999999999990.999999999'),
                   V_STOCK_TYPE,
                   VI_STAFF_ID,
                   TO_CHAR(ROUND(VI_MONEY, 2),
                           'fm999999999999999999999999999999990.999999999'),
                   V_S_NAME,
                   V_DEPOT_ID,
                   V_DEPOT_NAME,
                   V_NEW_GB_ID,
                   sysdate
              FROM DT_PRODUCTPACKAGING A
             WHERE A.COMPANYID = VI_COM_ID
               AND A.GOODSNAME = '微分金积分';
        end if;
      
      END LOOP;
    
      --进销存单据表
      INSERT INTO DT_INV_FB
        (FINANCIALBILLKEY,
         FINANCIALBILLID,
         GROUPCOMPANYSN,
         COMPANYID,
         BILLSTATUS,
         BILLSTYPE,
         JOURNALNUM,
         BILLSDATE,
         BILLSTAFFID,
         BILLSTAFFNAME,
         DEPOTID,
         DEPOTNAME,
         CASHIERBILLSID)
        SELECT DBMS_RANDOM.STRING('X', 32),
               FUN_GET_ID('FINANCIAL'),
               V_GSN,
               VI_COM_ID,
               '22',
               '积分出库单',
               V_ZK_JUM,
               SYSDATE,
               A.INPUTID,
               A.INPUTNAME,
               V_DEPOT_ID,
               V_DEPOT_NAME,
               V_CK_CA_ID
          FROM DTCASHIERBILLS A
         WHERE A.CASHIERBILLSID = V_DDID;
    
      --添加关系表数据
      INSERT INTO DTRELATEDBILL
        (RBKEY, RBID, CASHID, CASHFID, BILLTYPE)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         FUN_GET_ID('relatedbill'),
         V_CASH_ID,
         V_CK_CA_ID,
         '收款单');
    
      --添加关系表数据
      INSERT INTO DTRELATEDBILL
        (RBKEY, RBID, CASHID, CASHFID, BILLTYPE)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         FUN_GET_ID('relatedbill'),
         V_CK_CA_ID,
         V_RK_CA_ID,
         '收款单');
    
      ----------------------------用户积分存储值改变------------------------------------
    
      SELECT G.WFJ_GUIZE_ID
        INTO V_GUIZE_ID
        FROM DT_WFJ_GUIZE G
       WHERE G.WFJ_GUIZE_NAME = '积分充值';
    
      --往会员积分表以及积分收支明细表里存值
    
      UPDATE DT_WFJ_BONUSPOINTS
         SET BONUSPOINTSCORE = ROUND(BONUSPOINTSCORE + VII_MONEY, 2)
       WHERE SCCID = VI_PRO_SCCID;
    
      IF SQL%NOTFOUND THEN
      
        V_NEW_JF_ID := FUN_GET_ID('BonusPoints');
        INSERT INTO DT_WFJ_BONUSPOINTS
          (BONUSPOINTSKEY, BONUSPOINTSID, SCCID, BONUSPOINTSCORE)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           V_NEW_JF_ID,
           VI_PRO_SCCID,
           VII_MONEY);
      
      else
      
        SELECT BONUSPOINTSID
          INTO V_NEW_JF_ID
          FROM DT_WFJ_BONUSPOINTS
         WHERE SCCID = VI_PRO_SCCID;
      
      END IF;
    
      --积分收支明细
    
      INSERT INTO DT_WFJ_BONUSPOINTS_DETAIL
        (BONUSPOINTSDETAILKEY,
         BONUSPOINTSDETAILID,
         BONUSPOINTSDETAILNAME,
         BONUSPOINTSDETAILSCORE,
         BONUSPOINTSDETAILDATE,
         WFJGUIZEID,
         BONUSPOINTSID,
         WFJCASHID,
         WFJGOODID,
         PPID)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         FUN_GET_ID('BonusPointsDetail'),
         '积分充值',
         VII_MONEY,
         SYSDATE,
         V_GUIZE_ID, --规则外键
         V_NEW_JF_ID,
         V_RK_CA_ID, --积分入库单据ID
         V_GOOD_BI_ID,
         '');
    
      ------------------------------平台积分库存改变-----------------------------------------
    
      --平台积分库存表
      UPDATE DT_INV_INVT
         SET INVENQUANTITY = TO_CHAR(TO_NUMBER(NVL(INVENQUANTITY, 0)) -
                                     VII_MONEY,
                                     'FM999999999999999999999999999999990.999999999'),
             SUMPRICE      = TO_CHAR(TO_NUMBER(NVL(SUMPRICE, 0)) - VI_MONEY,
                                     'FM999999999999999999999999999999990.999999999')
       WHERE GOODSNAME = '微分金积分'
         AND COMPANYID = VI_COM_ID
         AND WAREHOUSENAME = '销售库';
    
      COMMIT;
    
    END IF;
  
  END IF;
END PRO_BUYJIFEN;
/

