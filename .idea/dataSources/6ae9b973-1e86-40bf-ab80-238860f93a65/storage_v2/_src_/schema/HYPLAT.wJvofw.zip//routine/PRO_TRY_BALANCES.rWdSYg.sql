create PROCEDURE          "PRO_TRY_BALANCES" (vi_work_id IN varchar2,
                                             vi_com_id IN varchar2, --公司id
                                             vi_date_s IN char, --起始日期
                                             vi_date_e IN char, --终止日期
                                             vi_acc_s IN char, --起始科目
                                             vi_acc_e IN char, --终止科目
                                             vi_dept IN char, --部门id
                                             vi_type IN char, --A：总额式，B：余额式
                                             P_CURSOR OUT TESTPACKAGE.TEST_CURSOR)--返回的记录集) 
 IS
  vc_open_ym char(6);
  vc_date_s  dt_inv_voucher.VOUCHERDATE%TYPE;
  vc_date_e  dt_inv_voucher.VOUCHERDATE%TYPE;
  vc_open2_ym char(6);
  
  cursor vcur_get_vouchers is
    select sum(decode(DIRECTION, 'D', STANDARDMONEY, 0)) org_amt_d,
           sum(decode(DIRECTION, 'C', STANDARDMONEY, 0)) org_amt_c,
           sum(decode(DIRECTION, 'D', ACCOUNTINGMONEY, 0)) amt_d,
           sum(decode(DIRECTION, 'C', ACCOUNTINGMONEY, 0)) amt_c,
           CURRENCYID,
           CURRENCYNAME,
           ORG_ID,
           SUBJECTSID,
           SUBJECTSNAME,
           SUBJECTSCODE
      from dt_inv_voucher a, dt_inv_vouchers b
     where a.VOUCHERID = b.VOUCHERID
       and a.COMPANYID = vi_com_id
       and ((a.org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
       and a.VOUCHERDATE between vc_date_s AND vc_date_e
       AND b.subjectscode between vi_acc_s AND vi_acc_e
     group by CURRENCYID, CURRENCYNAME, ORG_ID, SUBJECTSID,SUBJECTSNAME,SUBJECTSCODE;
     
     
     cursor vcur_sort_bcdays IS
    select a.rowid, a.*, rownum rowsort
      from TEM_TB a
     where work_id = vi_work_id
     order by SUBJECTSID,
              CUR_ID,
              ORG_ID,
              sort;
begin
  --处理期初
  vc_open_ym := fun_get_openym(vi_com_id, substrb(vi_date_s, 1, 6));
  
  IF to_number(substrb(vi_date_s, 5, 2)) = 1 THEN

      vc_open2_ym:=to_char(to_number(substrb(vi_date_s, 1, 4)) -1) || to_char(12);
      
  ELSE
    
      vc_open2_ym:=substrb(vi_date_s, 1, 4) ||
                 to_char(to_number(substrb(vi_date_s, 5, 2)) - 1, 'FM00');
  END IF;
    
  IF vc_open_ym = substrb(vi_date_s, 1, 6) THEN
    INSERT INTO TEM_TB
      (WORK_KEY,
       WORK_ID,
       COM_ID,
       ORG_ID,
       SUBJECTSID,
       CUR_ID,
       CUR_NAME,
       SUBJECTSCODE,
       SUBJECTSNAME,
       DB_AMT,
       CB_AMT,
       DE_AMT,
       CE_AMT,
       DBD_AMT,
       CBD_AMT,
       DED_AMT,
       CED_AMT,
       ACC_YM,
       SORT)
      SELECT dbms_random.string('x', 32),
             vi_work_id,
             vi_com_id,
             ORGID,
             SUBJECTSID,
             CURRENCYID,
             CURRENCYNAME,
             SUBJECTSCODE,
             SUBJECTSNAME,
             ACLDMONEY,
             ACLCMONEY,
             ACLDMONEY,
             ACLCMONEY,
             SCLDMONEY,
             SCLCMONEY,
             SCLDMONEY,
             SCLCMONEY,
             substrb(vi_date_s, 1, 6),
             0
        FROM DT_INV_DYCO
       WHERE COMPANYID = VI_COM_ID
         and ((orgid = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
         AND DYCO_YEAR = vc_open_ym
         AND SUBJECTSCODE between vi_acc_s and vi_acc_e;
  ELSE
    
    
    
    INSERT INTO TEM_TB
      (WORK_KEY,
       WORK_ID,
       COM_ID,
       ORG_ID,
       SUBJECTSID,
       CUR_ID,
       CUR_NAME,
       SUBJECTSCODE,
       SUBJECTSNAME,
       DB_AMT,
       CB_AMT,
       DE_AMT,
       CE_AMT,
       DBD_AMT,
       CBD_AMT,
       DED_AMT,
       CED_AMT,
       ACC_YM,
       SORT)
      SELECT dbms_random.string('x', 32),
             vi_work_id,
             vi_com_id,
             ORG_ID,
             SUBJECTSID,
             CURRENCYID,
             CURRENCYNAME,
             SUBJECTSCODE,
             SUBJECTSNAME,
             ACLDMONEY,
             ACLCMONEY,
             ACLDMONEY,
             ACLCMONEY,
             SCLDMONEY,
             SCLCMONEY,
             SCLDMONEY,
             SCLCMONEY,
             substrb(vi_date_s, 1, 6),
             0
        FROM DT_INV_DMCO
       WHERE COMPANYID = VI_COM_ID
         and ((org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
         AND YEARMONTH = vc_open2_ym
         AND SUBJECTSCODE between vi_acc_s and vi_acc_e;
  END IF;
  --处理期初，起始日期不是起始月份的第一天。
  IF substrb(vi_date_s, 7, 2) <> '01' THEN
    vc_date_s := substrb(vi_date_s, 1, 6) || '01';
    vc_date_e := substrb(vi_date_s, 1, 6) ||
                 to_char(to_number(substrb(vi_date_s, 7, 2)) - 1, 'FM00');
    FOR i in vcur_get_vouchers LOOP
      UPDATE TEM_TB
         SET DB_AMT  = NVL(DB_AMT, 0) + I.amt_d,
             CB_AMT  = NVL(CB_AMT, 0) + I.AMT_C,
             DE_AMT  = NVL(DE_AMT, 0) + I.amt_d,
             CE_AMT  = NVL(CE_AMT, 0) + I.AMT_C,
             DBD_AMT = NVL(DBD_AMT, 0) + I.ORG_amt_d,
             CBD_AMT = NVL(CBD_AMT, 0) + I.ORG_AMT_C,
             DED_AMT = NVL(DED_AMT, 0) + I.ORG_AMT_D,
             CED_AMT = NVL(CED_AMT, 0) + I.ORG_AMT_C
       WHERE COM_ID = VI_COM_ID
         AND ((org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
         AND ACC_YM = substrb(vi_date_s, 1, 6)
         AND CUR_ID = I.CURRENCYID
         AND CUR_NAME = I.CURRENCYNAME
         AND ORG_ID = I.ORG_ID
         and SUBJECTSID = i.SUBJECTSID
         AND SUBJECTSCODE between vi_acc_s and vi_acc_e;
         
      IF SQL%NOTFOUND THEN
        INSERT INTO TEM_TB
          (WORK_KEY,
           WORK_ID,
           COM_ID,
           ORG_ID,
           SUBJECTSID,
           CUR_ID,
           CUR_NAME,
           SUBJECTSCODE,
           SUBJECTSNAME,
           DB_AMT,
           CB_AMT,
           DE_AMT,
           CE_AMT,
           DBD_AMT,
           CBD_AMT,
           DED_AMT,
           CED_AMT,
           ACC_YM,
           SORT)
        VALUES
          (dbms_random.string('x', 32),
           vi_work_id,
           vi_com_id,
           i.org_id,
           i.SUBJECTSID,
           i.CURRENCYID,
           i.CURRENCYNAME,
           i.SUBJECTSCODE,
           i.SUBJECTSNAME,
           i.amt_d,
           i.amt_c,
           i.amt_d,
           i.amt_c,
           i.org_amt_d,
           i.org_amt_c,
           i.org_amt_d,
           i.org_amt_c,
           substrb(vi_date_s, 1, 6),
           0);
      END IF;
    END LOOP;
  END IF;
  --处理本期，起始日期不是起始月份的第一天。
  vc_date_s := vi_date_s;
  vc_date_e := vi_date_e;
  FOR i in vcur_get_vouchers LOOP
    UPDATE TEM_TB
       SET D_AMT   = NVL(D_AMT, 0) + I.amt_d,
           C_AMT   = NVL(C_AMT, 0) + I.AMT_C,
           DE_AMT  = NVL(DE_AMT, 0) + I.amt_d,
           CE_AMT  = NVL(CE_AMT, 0) + I.AMT_C,
           DD_AMT  = NVL(DD_AMT, 0) + I.ORG_amt_d,
           CD_AMT  = NVL(CD_AMT, 0) + I.ORG_AMT_C,
           DED_AMT = NVL(DED_AMT, 0) + I.ORG_AMT_D,
           CED_AMT = NVL(CED_AMT, 0) + I.ORG_AMT_C
     WHERE COM_ID = VI_COM_ID
       AND ((org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
       AND ACC_YM = substrb(vi_date_s, 1, 6)
       AND CUR_ID = I.CURRENCYID
       AND CUR_NAME = I.CURRENCYNAME
       AND ORG_ID = I.ORG_ID
       and SUBJECTSID = i.SUBJECTSID
       AND SUBJECTSCODE between vi_acc_s and vi_acc_e;
       
    IF SQL%NOTFOUND THEN
      INSERT INTO TEM_TB
        (WORK_KEY,
         WORK_ID,
         COM_ID,
         ORG_ID,
         SUBJECTSID,
         CUR_ID,
         CUR_NAME,
         SUBJECTSCODE,
         SUBJECTSNAME,
         D_AMT,
         C_AMT,
         DE_AMT,
         CE_AMT,
         DD_AMT,
         CD_AMT,
         DED_AMT,
         CED_AMT,
         ACC_YM,
         SORT)
      VALUES
        (dbms_random.string('x', 32),
         vi_work_id,
         vi_com_id,
         i.org_id,
         i.SUBJECTSID,
         i.CURRENCYID,
         i.CURRENCYNAME,
         i.SUBJECTSCODE,
         i.SUBJECTSNAME,
         i.amt_d,
         i.amt_c,
         i.amt_d,
         i.amt_c,
         i.org_amt_d,
         i.org_amt_c,
         i.org_amt_d,
         i.org_amt_c,
         substrb(vi_date_s, 1, 6),
         0);
    END IF;
  END LOOP;
  IF vi_type = 'B' THEN
    update TEM_TB
       set DB_AMT  = Decode(sign(db_amt - cb_amt), 1, db_amt - cb_amt, 0),
           CB_AMT  = Decode(sign(CB_AMT - db_amt), 1, CB_AMT - db_amt, 0),
           D_AMT   = Decode(sign(D_AMT - C_AMT), 1, D_AMT - C_AMT, 0),
           C_AMT   = Decode(sign(C_AMT - D_AMT), 1, C_AMT - D_AMT, 0),
           DE_AMT  = Decode(sign(DE_AMT - CE_AMT), 1, DE_AMT - CE_AMT, 0),
           CE_AMT  = Decode(sign(CE_AMT - DE_AMT), 1, CE_AMT - DE_AMT, 0),
           DED_AMT = Decode(sign(DED_AMT - CED_AMT), 1, DED_AMT - CED_AMT, 0),
           CED_AMT = Decode(sign(CED_AMT - DED_AMT), 1, db_amt - DED_AMT, 0),
           DBD_AMT = Decode(sign(DBD_AMT - CBD_AMT), 1, DBD_AMT - CBD_AMT, 0),
           CBD_AMT = Decode(sign(CBD_AMT - DBD_AMT), 1, CBD_AMT - DBD_AMT, 0),
           DD_AMT  = Decode(sign(DD_AMT - CD_AMT), 1, DD_AMT - CD_AMT, 0),
           CD_AMT  = Decode(sign(CD_AMT - DD_AMT), 1, CD_AMT - DD_AMT, 0)
     WHERE WORK_ID = VI_WORK_ID
       AND COM_ID = VI_COM_ID
       AND ((org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
       AND ACC_YM = SUBSTRB(VI_DATE_S, 1, 6)
       AND SUBJECTSCODE between vi_acc_s and vi_acc_e;
  END IF;
  
  FOR i in vcur_sort_bcdays LOOP
    update TEM_TB set sort = i.rowsort where rowid = i.rowid;
  END LOOP;
  
  COMMIT;
open P_CURSOR for select * from TEM_TB where WORK_ID=vi_work_id;

END;


/

