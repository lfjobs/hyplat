create trigger "trg_logoff_default"
    before insert or update
    on T_ESHOP_CUSCOM
    for each row
BEGIN
    :NEW.logOff := NVL(:NEW.logOff, '0');
END;
/

