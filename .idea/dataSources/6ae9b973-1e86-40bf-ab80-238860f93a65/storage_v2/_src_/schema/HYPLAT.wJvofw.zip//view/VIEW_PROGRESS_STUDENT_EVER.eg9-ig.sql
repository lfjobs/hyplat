create view VIEW_PROGRESS_STUDENT_EVER as
select ddsrt.companyid,ddsrt.ddsrstudentid,decode(ddsrt.subject,'科目一','01','科目二','02','科目三','03','04') subject,sum(ddsrt.time) time,max(ddsrt.type) type
        from ddsrtrainingrecord ddsrt
        group by ddsrt.companyid,ddsrt.ddsrstudentid,ddsrt.subject


/

