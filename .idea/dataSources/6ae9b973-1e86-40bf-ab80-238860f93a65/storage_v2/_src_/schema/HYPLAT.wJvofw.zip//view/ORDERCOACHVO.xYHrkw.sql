create view ORDERCOACHVO as
select s.staffkey,
       s.staffid,
       s.staffname,
       s.staffcode,
       s.headimage,
       t.subject,
       t.content,
       c.trainarea,
       wc.woti_strdaydate,
       wc.woti_enddaydate,
       t.drivelictype,
       t.cartype
  from Dtcoachinfo c
  left join dt_hr_staff s on c.staffid = s.staffid
 right join (select f.subjectname as subject,f.drivelictype,m.cartype,
                    f.staffid,
                    wm_concat(f.subjectcontent) as content
               from dtTeachSubject f right join dt_car_carinformation m on f.staffid = m.staffid
              group by f.subjectname, f.staffid,f.drivelictype,m.cartype) t on s.staffid = t.staffid
 right join (select w.staffcoid, w.woti_strdaydate, w.woti_enddaydate
               from dtWorkTime w
              group by w.staffcoid, w.woti_strdaydate, w.woti_enddaydate) wc on t.staffid = wc.staffcoid


/

