create procedure sayhelloworld
as
begin
 dbms_output.put_line('helloword');
end;
/

