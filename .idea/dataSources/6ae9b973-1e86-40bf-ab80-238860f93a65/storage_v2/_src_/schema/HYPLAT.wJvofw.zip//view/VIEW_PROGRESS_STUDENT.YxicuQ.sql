create view VIEW_PROGRESS_STUDENT as
select ddp.studentid,max(dhs.recordcode) studentcode,max(ddp.registrationdate) registrationdate,max(upper(ddp.registrationcarname)) registrationcarname,
max(ddp.schoolopendate) schoolopendate,max(ddp.studentname) studentname,
max(ddp.studentsex) studentsex,max(ddp.studentphone) studentphone
,max(ddp.studentcard) studentcard,max(ddp.barcode) barcode,
wmsys.wm_concat(decode(ddpt.coachname,null,'无',ddpt.coachname) || '(' || decode(ddpt.docstatus,'04','科四','03','科三','02','科二','科一') ||')') coach
,sum(case when ddpt.docstatus='01'  then '1' else '0' end ) entrance,
sum(case when ddpt.docstatus='01' and ddpt.studentstatus in ('08','06','07') then '1' else '0' end ) subjectone,
sum(case when ddpt.docstatus='02' and ddpt.studentstatus in ('05','06','07') then '1' else '0' end ) subjecttwo,
sum(case when ddpt.docstatus='03' and ddpt.studentstatus in ('05','06','07') then '1' else '0' end ) subjectthree,
sum(case when ddpt.docstatus='04' and ddpt.studentstatus in ('05','06','07') then '1' else '0' end ) subjectfour,
sum(case when ddpt.docstatus='04' and ddpt.studentstatus in ('07') then '1' else '0' end ) graduation ,
ddp.companyid  companyid,
wm_concat(ddpt.docstatus || ddpt.studentstatus) status
from dt_driving_principal ddp
left join dt_driving_principal_type ddpt on ddpt.drivingprincipalid=ddp.drivingprincipalid
left join dt_hr_staff dhs on dhs.staffid=ddp.studentid
group by ddp.companyid,ddp.studentid
order by max(ddp.registrationdate) desc nulls last


/

