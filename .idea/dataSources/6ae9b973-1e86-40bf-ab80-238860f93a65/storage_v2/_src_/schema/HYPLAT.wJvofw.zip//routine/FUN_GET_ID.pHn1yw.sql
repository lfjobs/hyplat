create FUNCTION          "FUN_GET_ID" (vc_type in varchar2)

  RETURN varchar2 AS
  vc_id  varchar2(50);
  vc_yms char(6);
BEGIN
  vc_id :=vc_type||TO_CHAR (SYSDATE,'yyyymmdd')||dbms_random.string('x', 10)||trunc(dbms_random.value(0,10000000000));
  RETURN vc_id;
END;


/

