create view VIEW_SC as
select  DISTINCT c.companyid || s.staffkey as coskey, t.categoryname,t.staffcategoryid,
(select company.companyname from dtcompany company where company.companyid = c.companyid) as companyname,
c.companyid as companyid, s.staffid as staffid,
s.staffstatus as staffstatus,s.staffcode as staffcode,s.recordcode as recordcode,
s.staffname as staffname,s.usednmae as usednmae ,s.sex as sex,
s.nativeplace as nativeplace,s.nationality as nationality ,s.nation as nation,
s.staffidentitycard as staffidentitycard,s.address as address,s.staffAddress as staffAddress,
s.referenceorganization as referenceorganization,
s.reference as reference,s.referencecode as referencecode,s.verifytime as verifytime,
s.staffdesc as staffdesc,s.birthday as birthday,s.photo as photo,c.organizationid,dhd.postname as postname
from dt_hr_staff s
 left join dtcos c on c.staffID = s.staffID
 left join dtaudition t on c.staffID = t.staffID and t.companyid = c.companyID and t.status = '22'
 left join dt_hr_deptpost dhd on c.deppostid=dhd.deppostid
 where c.cosStatus = '50' and c.status = '01'


/

