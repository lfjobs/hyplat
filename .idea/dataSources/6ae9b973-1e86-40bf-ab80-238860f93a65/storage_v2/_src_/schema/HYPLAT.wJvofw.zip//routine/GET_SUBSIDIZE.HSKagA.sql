create PROCEDURE GET_subsidize(VI_COM_ID   VARCHAR2, --平台公司ID
                                          VI_CASH_ID  VARCHAR2, --单据ID
                                          VI_JOU_NUM  VARCHAR2,
                                          VI_WFSTATUS VARCHAR2 --支付状态
                                          ) /**消费补助**/
 IS
  V_AMOUNT     DT_PRO_SETUP_SUB.AMOUNT%TYPE; --消费补助分配金额（元）
  V_YJ_AMOUNT  DT_DAILIMEMBER.JBNUM%TYPE; --消费补助分配金额（元）
  V_YJ_AMOUNT2 DT_DAILIMEMBER.JBNUM%TYPE; --消费补助分配金额（元）
  v_sb_type    dt_subsidize_backup.sb_type%type; --消费补助种类

  V_SCCID T_ESHOP_CUSCOM_SUB.SCCID%TYPE; --分虚拟货币的账号ID
  V_SNAME DT_HR_STAFF.STAFFNAME%TYPE; --分虚拟货币的人员名称
  V_SCODE DT_HR_STAFF.STAFFCODE%TYPE; --份虚拟货币的人员编号
  V_SID   DT_HR_STAFF.STAFFID%TYPE; --分虚拟货币的人员ID

  V_SNAME1 DT_HR_STAFF.STAFFNAME%TYPE; --操作人员名称
  V_SCODE1 DT_HR_STAFF.STAFFCODE%TYPE; --操作人员编号
  V_SID1   DT_HR_STAFF.STAFFID%TYPE; --操作人员ID

  V_JOU_NUM DTCASHIERBILLS.JOURNALNUM%TYPE; --订单编号

  V_COM_ID   DTCOMPANY.COMPANYID%TYPE; --供应商公司ID
  V_COM_NAME DTCOMPANY.COMPANYNAME%TYPE; --供应商公司名称
  V_G_SN     DTCOMPANY.GROUPCOMPANYSN%TYPE; --供应商组织机构ID

  V_p_COM_NAME DTCOMPANY.COMPANYNAME%TYPE; --平台公司名称
  V_p_G_SN     DTCOMPANY.GROUPCOMPANYSN%TYPE; --平台组织机构ID

  V_RK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --入库单ID
  V_CK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --入库单ID
  V_NEW_CA_ID DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  V_CK_JUM    DTCASHIERBILLS.JOURNALNUM%TYPE; --入库单编号
  V_NEW_GB_ID DTGOODSBILLS.GOODSBILLSID%TYPE;

  V_DEPOT_NAME   DTDEPOTMANAGE.DEPOTNAME%TYPE;
  V_DEPOT_ID     DTDEPOTMANAGE.DEPOTID%TYPE;
  V_DEPOT_ITEMID DTDEPOTMANAGE.ITEMID%TYPE;

  --V_JIFEN_SCORE DT_WFJ_JIFEN_DETAIL.JIFEN_DETAIL_SCORE%TYPE;
  V_NEW_JF_ID DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE;

  V_GUIZE_ID   DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE;
  V_GUIZE_NAME DT_WFJ_GUIZE.WFJ_GUIZE_NAME%TYPE;

  V_XJHB     VARCHAR2(20);
  V_PRO_XJHB VARCHAR2(10);

  V_COUNT NUMBER; --条数

  V_SUBJECTID   DTSUBJECTS.SUBJECTSID%TYPE;
  V_SUBJECTNAME DTSUBJECTS.SUBJECTSID%TYPE;
  V_WEIGHT      DT_PRODUCTPACKAGING.WEIGHT%TYPE;
  V_GOODSID     DT_PRODUCTPACKAGING.GOODSID%TYPE;
  V_VARIABLEID  DT_PRODUCTPACKAGING.VARIABLEID%TYPE;
  V_GOODSNUM    DT_PRODUCTPACKAGING.GOODSNUM%TYPE;
  V_GOODSNAME   DT_PRODUCTPACKAGING.GOODSNAME%TYPE;
  V_TYPE        DT_PRODUCTPACKAGING.TYPE%TYPE;
  V_STANDARD    DT_PRODUCTPACKAGING.STANDARD%TYPE;
  V_PPID        DT_PRODUCTPACKAGING.PPID%TYPE; --虚拟货币产品id

  /**根据产品查询每个代理商分配虚拟币个数**/
  CURSOR VCUR_GET_SETUP_SUB IS
    SELECT dm.jb_num, DM.STAFF_ID, DM.M_ID, dm.sb_type
      FROM dt_subsidize_backup DM
     WHERE dm.cash_id = VI_CASH_ID;

BEGIN

  select count(*)
    into V_COUNT
    from dt_subsidize_backup s
   where s.cash_id = VI_CASH_ID;

  IF V_COUNT > 0 and v_count <= 6 THEN
  
    OPEN VCUR_GET_SETUP_SUB;
  
    FETCH VCUR_GET_SETUP_SUB
      INTO V_YJ_AMOUNT, v_SID, V_SCCID, v_sb_type;
  
    WHILE VCUR_GET_SETUP_SUB%FOUND LOOP
    
      IF V_YJ_AMOUNT > 0 THEN
      
        SELECT t.companyid
          into V_COM_ID
          FROM t_eshop_cuscom t
         where t.companyid is not null
           and rownum = 1
         START WITH t.sccid = V_SCCID
        CONNECT BY PRIOR t.suppersccid = t.sccid;
      
        select c.companyname, c.groupcompanysn
          into V_COM_NAME, V_G_SN
          from dtcompany c
         where c.companyid = V_COM_ID;
      
        V_AMOUNT := ROUND(TO_NUMBER(V_YJ_AMOUNT) / 100, 4);
      
        /**查询该产品及现在循环的代理商类别下是否绑定账号**/
      
        V_XJHB     := '微分金积分';
        V_PRO_XJHB := '积分';
      
        --查询虚拟产品信息
        SELECT COUNT(*)
          INTO v_COUNT
          FROM DT_PRODUCTPACKAGING A
         WHERE A.COMPANYID = VI_COM_ID
           AND A.GOODSNAME = v_XJHB;
      
        if v_COUNT > 0 then
        
          SELECT A.SUBJECTID,
                 A.SUBJECTNAME,
                 A.WEIGHT,
                 A.GOODSID,
                 A.VARIABLEID,
                 A.GOODSNUM,
                 A.GOODSNAME,
                 A.TYPE,
                 A.STANDARD,
                 A.PPID
            into v_SUBJECTID,
                 v_SUBJECTNAME,
                 v_WEIGHT,
                 v_GOODSID,
                 v_VARIABLEID,
                 v_GOODSNUM,
                 v_GOODSNAME,
                 v_TYPE,
                 v_STANDARD,
                 v_PPID
            FROM DT_PRODUCTPACKAGING A
           WHERE A.COMPANYID = VI_COM_ID
             AND A.GOODSNAME = v_XJHB;
        else
          v_SUBJECTID   := null;
          v_SUBJECTNAME := null;
          v_WEIGHT      := null;
          v_GOODSID     := null;
          v_VARIABLEID  := null;
          v_GOODSNUM    := null;
          v_GOODSNAME   := v_XJHB;
          v_TYPE        := '虚拟产品';
          v_STANDARD    := null;
          v_PPID        := null;
        end if;
      
        --查询账号绑定的人员名称,编号，ID
        SELECT S.STAFFNAME, S.STAFFCODE
          INTO v_SNAME, v_SCODE
          FROM DT_HR_STAFF S
         WHERE S.STAFFID = v_SID;
      
        --查询规则信息
      
        if v_sb_type = '1' then
        
          SELECT G.WFJ_GUIZE_ID, g.wfj_guize_name
            INTO V_GUIZE_ID, V_GUIZE_NAME
            FROM DT_WFJ_GUIZE G
           WHERE G.WFJ_GUIZE_NAME = '创业红包';
        
        elsif v_sb_type = '2' then
        
          SELECT G.WFJ_GUIZE_ID, g.wfj_guize_name
            INTO V_GUIZE_ID, V_GUIZE_NAME
            FROM DT_WFJ_GUIZE G
           WHERE G.WFJ_GUIZE_NAME = '粉丝红包';
        
        else
          SELECT G.WFJ_GUIZE_ID, g.wfj_guize_name
            INTO V_GUIZE_ID, V_GUIZE_NAME
            FROM DT_WFJ_GUIZE G
           WHERE G.WFJ_GUIZE_NAME = '消费红包';
        end if;
      
        --消费补助入库单
      
        V_RK_CA_ID := FUN_GET_ID('cashierTally');
      
        INSERT INTO DTCASHIERBILLS
          (CASHIERBILLSKEY,
           CASHIERBILLSID,
           COMPANYID,
           BILLSTYPE,
           JOURNALNUM,
           STAFFID,
           STAFFNAME,
           STAFFCODE,
           CASHIERDATE,
           STATUS,
           COMPANYNAME,
           PROID,
           PROJECTNAME, --项目名称
           GROUPCOMPANYSN,
           INPUTID,
           INPUTNAME,
           APPSTYLE,
           PRICESUB,
           CCOMPANYID,
           CCOMPANYNAME,
           STATUSBILL,
           JNUMORDER)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           V_RK_CA_ID,
           V_COM_ID,
           V_PRO_XJHB || '入库单',
           FUN_GET_BILL_ID(),
           V_SID,
           V_SNAME, --会员名称
           V_SCODE, --会员编号
           SYSDATE,
           '15',
           V_COM_NAME, --公司名称
           '002',
           V_GUIZE_NAME,
           V_G_SN, --集团组织机构ID
           V_SID1,
           V_SNAME1,
           '08',
           TO_CHAR(V_AMOUNT,
                   'FM999999999999999999999999999999990.999999999'),
           VI_COM_ID,
           V_COM_NAME,
           '04',
           VI_JOU_NUM);
      
        --添加关系表数据
      
        /*INSERT INTO DTRELATEDBILL
          (RBKEY, RBID, CASHID, CASHFID)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           FUN_GET_ID('RELATEDBILL'),
           VI_CASH_ID,
           V_RK_CA_ID);*/
      
        --平台佣金出库单
      
        V_CK_CA_ID := FUN_GET_ID('cashierTally');
      
        V_CK_JUM := FUN_GET_BILL_ID();
      
        INSERT INTO DTCASHIERBILLS
          (CASHIERBILLSKEY,
           CASHIERBILLSID,
           COMPANYID,
           BILLSTYPE,
           JOURNALNUM,
           STAFFID,
           STAFFNAME,
           STAFFCODE,
           CASHIERDATE,
           STATUS,
           COMPANYNAME,
           PROID,
           PROJECTNAME, --项目名称
           GROUPCOMPANYSN,
           INPUTID,
           INPUTNAME,
           APPSTYLE,
           PRICESUB,
           CCOMPANYID,
           CCOMPANYNAME,
           CONTACTUSERID,
           CTUSERNAME,
           STATUSBILL,
           JNUMORDER)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           V_CK_CA_ID,
           VI_COM_ID,
           V_PRO_XJHB || '出库单',
           V_CK_JUM,
           V_SID1,
           V_SNAME1, --会员名称
           V_SCODE1, --会员编号
           SYSDATE,
           '16',
           V_p_COM_NAME, --公司名称
           '002',
           V_GUIZE_NAME,
           V_p_G_SN, --集团组织机构ID
           V_SID1,
           V_SNAME1,
           '08',
           TO_CHAR(V_AMOUNT,
                   'FM999999999999999999999999999999990.999999999'),
           V_COM_ID,
           V_COM_NAME,
           V_SID,
           V_SNAME,
           '04',
           VI_JOU_NUM);
      
        --平台\用户佣金出库\入库产品表
        FOR I IN 1 .. 2 LOOP
          IF I = 1 THEN
            --入库
            V_DEPOT_NAME := '销售库';
            V_DEPOT_ID   := NULL;
            V_NEW_CA_ID  := V_RK_CA_ID;
          ELSE
            --出库
            SELECT D.DEPOTNAME, D.DEPOTID, D.ITEMID
              INTO V_DEPOT_NAME, V_DEPOT_ID, V_DEPOT_ITEMID
              FROM DTDEPOTMANAGE D
             WHERE D.COMPANYID = VI_COM_ID
               AND D.DEPOTPID = '001'
               AND D.DEPOTSTATE = '00'
               AND D.DEPOTNAME = '销售库';
          
            V_NEW_CA_ID := V_CK_CA_ID;
          
          END IF;
        
          V_NEW_GB_ID := FUN_GET_ID('goodsbills');
          V_COUNT     := 0;
        
          IF I = 2 THEN
            --平台金币库存盘点表
            INSERT INTO DT_INV_STOCKINVT
              (STOCKINVKEY,
               STOCKINVID,
               COMPANYID,
               GROUPCOMPANYSN,
               GOODSID,
               GOODSTYPE,
               GOODSNAME,
               INVENQUANTITY,
               TYPE,
               STAFFID,
               STAFFNAME,
               WAREHOUSE,
               WAREHOUSENAME,
               GOODSBILLSID,
               INTIME)
            values
              (DBMS_RANDOM.STRING('X', 32),
               FUN_GET_ID('stockinv'),
               VI_COM_ID,
               V_p_G_SN,
               V_GOODSID,
               V_TYPE,
               V_GOODSNAME,
               TO_CHAR(V_YJ_AMOUNT,
                       'FM999999999999999999999999999999990.999999999'),
               '01',
               V_SID1,
               V_SNAME1,
               V_DEPOT_ID,
               V_DEPOT_NAME,
               V_NEW_GB_ID,
               SYSDATE);
          
          END IF;
        
          INSERT INTO DTGOODSBILLS
            (GOODSBILLSKEY,
             GOODSBILLSID,
             --COMPANYID,
             CASHIERBILLSID,
             SUBJECTSID,
             SUBJECTSNAME,
             COSTTYPE, --费用类别
             PAYTYPE, --付款方式
             WEIGHT,
             GOODSID,
             QUANTITY,
             PRICE,
             MONEY,
             DEPOTID, --库房ID
             DEPOTNAME, --库房名称
             GOODSVARIABLEID, --单位
             IDENTIFYINGCODE, --00
             BATCHNUMBER, --批号
             GOODSNOMBER, --物品在账单中的排列序号
             GOODSNUM,
             GOODSNAME,
             TYPEID,
             STANDARD,
             KCSTATUS, --16：已出库
             GOODSTATUS, --状态00正常 01维修02报废
             PPID)
          values
            (DBMS_RANDOM.STRING('X', 32),
             V_NEW_GB_ID,
             --COMPANYID,
             V_NEW_CA_ID,
             V_SUBJECTID,
             V_SUBJECTNAME,
             '', --费用类别
             '08',
             V_WEIGHT,
             V_GOODSID,
             TO_CHAR(V_YJ_AMOUNT,
                     'FM999999999999999999999999999999990.999999999'),
             '0.01',
             TO_CHAR(V_AMOUNT,
                     'FM999999999999999999999999999999990.999999999'),
             V_DEPOT_ID,
             V_DEPOT_NAME,
             V_VARIABLEID,
             '00',
             '',
             '1',
             V_GOODSNUM,
             V_GOODSNAME,
             V_TYPE,
             V_STANDARD,
             '15',
             '00',
             V_PPID);
        
        END LOOP;
      
        --进销存单据表
        INSERT INTO DT_INV_FB
          (FINANCIALBILLKEY,
           FINANCIALBILLID,
           GROUPCOMPANYSN,
           COMPANYID,
           BILLSTATUS,
           BILLSTYPE,
           --JOURNALNUM,
           BILLSDATE,
           BILLSTAFFID,
           BILLSTAFFNAME,
           DEPOTID,
           DEPOTNAME,
           CASHIERBILLSID)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           FUN_GET_ID('financial'),
           V_p_G_SN,
           VI_COM_ID,
           '22',
           V_PRO_XJHB || '出库单',
           --CK_JUM,
           SYSDATE,
           '',
           '系统生成',
           V_DEPOT_ID,
           V_DEPOT_NAME,
           V_CK_CA_ID);
      
        --添加关系表数据
        /*INSERT INTO DTRELATEDBILL
          (RBKEY, RBID, CASHID, CASHFID)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           FUN_GET_ID('relatedbill'),
           VI_CASH_ID,
           V_CK_CA_ID);*/
      
        --添加关系表数据
        /*INSERT INTO DTRELATEDBILL
          (RBKEY, RBID, CASHID, CASHFID)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           FUN_GET_ID('relatedbill'),
           V_CK_CA_ID,
           V_RK_CA_ID);*/
      
        ----------------------------------------------------用户金币存储值改变------------------------------------
      
        --往会员金币表以及金币收支明细表里存值
        SELECT COUNT(*)
          INTO V_COUNT
          FROM DT_WFJ_JIFEN
         WHERE STAFF_ID = V_SID
           AND SCCID = V_SCCID;
      
        UPDATE DT_WFJ_BONUSPOINTS
           SET BONUSPOINTSCORE = NVL(BONUSPOINTSCORE, 0) + V_YJ_AMOUNT
         WHERE SCCID = V_SCCID;
      
        IF SQL%NOTFOUND THEN
          V_NEW_JF_ID := FUN_GET_ID('BonusPoints');
        
          INSERT INTO DT_WFJ_BonusPoints
            (bonuspointskey, bonuspointsid, sccid, bonuspointscore)
          VALUES
            (DBMS_RANDOM.STRING('x', 32),
             V_NEW_JF_ID,
             V_SCCID,
             V_YJ_AMOUNT);
        
        ELSE
        
          SELECT BONUSPOINTSID
            INTO V_NEW_JF_ID
            FROM DT_WFJ_BONUSPOINTS
           WHERE SCCID = V_SCCID;
        
        END IF;
      
        --金币收支明细
        INSERT INTO DT_WFJ_BonusPoints_Detail
          (bonuspointsdetailkey,
           bonuspointsdetailid,
           bonuspointsdetailname,
           bonuspointsdetaildate,
           bonuspointsdetailscore,
           wfjguizeid,
           bonuspointsid,
           wfjcashid)
        VALUES
          (DBMS_RANDOM.STRING('x', 32),
           FUN_GET_ID('BonusPointsDetail'),
           V_GUIZE_NAME,
           SYSDATE,
           TO_CHAR(V_YJ_AMOUNT,
                   'FM999999999999999999999999999999990.999999999'),
           V_GUIZE_ID, --规则外键
           V_NEW_JF_ID,
           V_RK_CA_ID --金币入库单据ID
           );
      
        --平台积分库存表
      
        UPDATE DT_INV_INVT
           SET INVENQUANTITY = TO_CHAR(TO_NUMBER(NVL(INVENQUANTITY, 0)) -
                                       V_YJ_AMOUNT,
                                       'FM999999999999999999999999999999990.999999999'),
               SUMPRICE      = TO_CHAR(TO_NUMBER(NVL(SUMPRICE, 0)) -
                                       V_AMOUNT,
                                       'FM999999999999999999999999999999990.999999999')
         WHERE GOODSNAME = V_XJHB
           AND COMPANYID = VI_COM_ID
           AND WAREHOUSENAME = '销售库';
      
      end if;
    
      FETCH VCUR_GET_SETUP_SUB
        INTO V_YJ_AMOUNT, v_SID, V_SCCID, v_sb_type;
    
    END LOOP;
    CLOSE VCUR_GET_SETUP_SUB;
  END IF;
END GET_subsidize;
/

