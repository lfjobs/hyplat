create PROCEDURE PRO_DATAPROCESSING IS

  CASHID   VARCHAR2(50);
  BTYPE    VARCHAR2(50);
  V_NUM    NUMBER;
  V_SUM    NUMBER;
  V_SDATE  DATE;
  V_EDATE  DATE;
  VI_COUNT NUMBER;

  V_BEGIN_TIME TIMESTAMP := SYSTIMESTAMP;
  V_PROC_NAME  VARCHAR2(1000) := 'PRO_DATAPROCESSING/' ||
                                 TO_CHAR(sysdate, 'YYYY-MM-DD');
  V_EXE_MSG    CLOB;
  V_ERR_MSG    VARCHAR2(1000);
  RESULT       VARCHAR2(100);

  V_LOG CLOB;

  V_IMPORT_DATE DATE;
  V_BUSI_DATE   DATE;
  V_MONTH_BEGIN DATE;
  V_MONTH_END   DATE;

  CURSOR CASH IS
    SELECT C.CASHIERBILLSID CID, C.BILLSTYPE BTYPE
      FROM DTCASHIERBILLS C
     WHERE C.CASHIERDATE BETWEEN V_SDATE AND V_EDATE;

BEGIN

  V_SUM := 0;
  V_NUM := 0;
  --V_SDATE := TO_DATE('2019-09-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
  --V_EDATE := TO_DATE('2019-09-30 23:59:59', 'yyyy-mm-dd hh24:mi:ss');
  V_PROC_NAME := V_PROC_NAME || '/' || TO_CHAR(V_SDATE, 'yyyymmdd') || '-' ||
                 TO_CHAR(V_EDATE, 'yyyymmdd');

  /*SELECT COUNT(*)
   INTO VI_COUNT
   FROM PROGRAM_EXECUTE_LOG
  WHERE PROGRAM_NAME LIKE 'PRO_DATAPROCESSING%'
    AND IS_SUCCEED = 'N'
    AND SYSDATE - 1 / 24 <= EXECUTE_ENDTIME;*/

  --IF VI_COUNT > 0 THEN

  --V_ERR_MSG := '已执行，重复执行-';
  --GOTO PROCESS_ERRMSG;

  --ELSE

  DBMS_LOB.CREATETEMPORARY(V_EXE_MSG, TRUE); --初始化CLOB
  DBMS_LOB.CREATETEMPORARY(V_LOG, TRUE); --初始化CLOB

  V_MONTH_END   := DATE '2019-09-30';
  V_MONTH_BEGIN := TRUNC(V_MONTH_END, 'MM');
  V_BUSI_DATE   := V_MONTH_BEGIN;

  WHILE (V_BUSI_DATE <= V_MONTH_END) LOOP
  
    V_SDATE := V_BUSI_DATE;
    V_EDATE := V_BUSI_DATE + 1;
  
    FOR i IN 1 .. (24 * 60) LOOP
      V_IMPORT_DATE := V_BUSI_DATE + i / (24 * 60);
    
      /*OPEN CASH; --打开游标
      LOOP
      --取游标值给变量
      FETCH CASH
      INTO CASHID, BTYPE;*/
      FOR V_POS IN CASH LOOP
        CASHID := V_POS.CID;
        BTYPE  := V_POS.BTYPE;
      
        --DBMS_OUTPUT.PUT_LINE('name:' || BTYPE);
      
        -- 应收款单 10909              DT_SR_YINGSHOUBILL DT_SR_YINGSHOUGOOD
        -- 支款单 19855                DT_ZC_BILL         DT_ZC_GOOD
        -- 缴款单 36871                DT_ZC_JIAOKUANBILL DT_ZC_JIAOKUANGOOD
        -- 预入款单 58289              DT_SR_YURUKUANBILL DT_SR_YURUKUANGOOD
        -- 物流出库单 58613            DT_K_G_WULIUBILL   DT_K_G_WULIUGOOD
        -- 项目支出预算单 62474        DT_ZC_YUSUANBILL   DT_ZC_YUSUANGOOD
        -- 拨款单 63002                DT_ZC_BOKUANBILL   DT_ZC_BOKUANGOOD
        -- 费用报销单 73903            DT_SR_FEIYONGBILL  DT_SR_FEIYONGGOOD
        -- 物流入库单 79834            DT_K_E_WULIUBILL   DT_K_E_WULIUGOOD
        -- 收款单 309765               DT_SR_BILL         DT_SR_GOOD
        -- 销售出库单 443921           DT_K_G_SALESBILL   DT_K_G_SALESGOOD
        -- 项目收入预算单 467024       DT_SR_YUSUANBILL   DT_SR_YUSUANGOOD
      
        -- 积分入库单 5385728          DT_K_E_JIFENBILL   DT_K_E_JIFENGOOD (- - 2019-07-31)
        --                             DT_K_E_JIFENBILL2  DT_K_E_JIFENGOOD2 (2019-08-01 - )
        --                             DT_K_E_JIFENBILL3  DT_K_E_JIFENGOOD3 (2021-03-13 - )
        -- 积分出库单 5399916          DT_K_G_JIFENBILL   DT_K_G_JIFENGOOD (- - 2019-07-31)
        --                             DT_K_G_JIFENBILL2  DT_K_G_JIFENGOOD2 (2019-08-01 - )
        --                             DT_K_G_JIFENBILL3  DT_K_G_JIFENGOOD3 (2021-03-13 - )
        -- 金币出库单 8093057          DT_K_G_JINBIBILL   DT_K_G_JINBIGOOD (- - 2019-07-31)
        --                             DT_K_G_JINBIBILL2  DT_K_G_JINBIGOOD2 (2019-08-01 - )
        -- 金币入库单 8136129          DT_K_E_JINBIBILL   DT_K_E_JINBIGOOD (- - 2019-07-31)
        --                             DT_K_E_JINBIBILL2  DT_K_E_JINBIGOOD2 (2019-08-01 - )
        -- 其他                        DT_HIST_CASH       DT_HIST_GOOD
      
        DECLARE
          V_COUNT           NUMBER;
          V_TAB_CASH_NAME   VARCHAR2(50);
          V_TAB_GOOD_NAME   VARCHAR2(50);
          V_CREATE_C_STRING VARCHAR2(1000);
          --V_ALTER_C_STRING VARCHAR2(1000);
          V_INSERT_C_STRING VARCHAR2(1000);
          V_CREATE_G_STRING VARCHAR2(1000);
          --V_ALTER_G_STRING VARCHAR2(1000);
          V_INSERT_G_STRING VARCHAR2(1000);
          V_CASH_COUNT      NUMBER;
          V_GOOD_COUNT      NUMBER;
        BEGIN
        
          V_NUM := V_NUM + 1;
        
          IF BTYPE = '应收款单' THEN
            V_TAB_CASH_NAME := 'DT_SR_YINGSHOUBILL';
            V_TAB_GOOD_NAME := 'DT_SR_YINGSHOUGOOD';
          ELSIF BTYPE = '支款单' THEN
            V_TAB_CASH_NAME := 'DT_ZC_BILL';
            V_TAB_GOOD_NAME := 'DT_ZC_GOOD';
          ELSIF BTYPE = '缴款单' THEN
            V_TAB_CASH_NAME := 'DT_ZC_JIAOKUANBILL';
            V_TAB_GOOD_NAME := 'DT_ZC_JIAOKUANGOOD';
          ELSIF BTYPE = '预入款单' THEN
            V_TAB_CASH_NAME := 'DT_SR_YURUKUANBILL';
            V_TAB_GOOD_NAME := 'DT_SR_YURUKUANGOOD';
          ELSIF BTYPE = '物流出库单' THEN
            V_TAB_CASH_NAME := 'DT_K_G_WULIUBILL';
            V_TAB_GOOD_NAME := 'DT_K_G_WULIUGOOD';
          ELSIF BTYPE = '项目支出预算单' THEN
            V_TAB_CASH_NAME := 'DT_ZC_YUSUANBILL';
            V_TAB_GOOD_NAME := 'DT_ZC_YUSUANGOOD';
          ELSIF BTYPE = '拨款单' THEN
            V_TAB_CASH_NAME := 'DT_ZC_BOKUANBILL';
            V_TAB_GOOD_NAME := 'DT_ZC_BOKUANGOOD';
          ELSIF BTYPE = '费用报销单' THEN
            V_TAB_CASH_NAME := 'DT_SR_FEIYONGBILL';
            V_TAB_GOOD_NAME := 'DT_SR_FEIYONGGOOD';
          ELSIF BTYPE = '物流入库单' THEN
            V_TAB_CASH_NAME := 'DT_K_E_WULIUBILL';
            V_TAB_GOOD_NAME := 'DT_K_E_WULIUGOOD';
          ELSIF BTYPE = '收款单' THEN
            V_TAB_CASH_NAME := 'DT_SR_BILL';
            V_TAB_GOOD_NAME := 'DT_SR_GOOD';
          ELSIF BTYPE = '销售出库单' THEN
            V_TAB_CASH_NAME := 'DT_K_G_SALESBILL';
            V_TAB_GOOD_NAME := 'DT_K_G_SALESGOOD';
          ELSIF BTYPE = '项目收入预算单' THEN
            V_TAB_CASH_NAME := 'DT_SR_YUSUANBILL';
            V_TAB_GOOD_NAME := 'DT_SR_YUSUANGOOD';
          ELSIF BTYPE = '积分入库单' THEN
            --V_TAB_CASH_NAME := 'DT_K_E_JIFENBILL';(- - 2019-07-31)
            --V_TAB_GOOD_NAME := 'DT_K_E_JIFENGOOD';
            V_TAB_CASH_NAME := 'DT_K_E_JIFENBILL2';
            V_TAB_GOOD_NAME := 'DT_K_E_JIFENGOOD2';
          ELSIF BTYPE = '积分出库单' THEN
            --V_TAB_CASH_NAME := 'DT_K_G_JIFENBILL';(- - 2019-07-31)
            --V_TAB_GOOD_NAME := 'DT_K_G_JIFENGOOD';
            V_TAB_CASH_NAME := 'DT_K_G_JIFENBILL2';
            V_TAB_GOOD_NAME := 'DT_K_G_JIFENGOOD2';
          ELSIF BTYPE = '金币出库单' THEN
            --V_TAB_CASH_NAME := 'DT_K_G_JINBIBILL';(- - 2019-07-31)
            --V_TAB_GOOD_NAME := 'DT_K_G_JINBIGOOD';
            V_TAB_CASH_NAME := 'DT_K_G_JINBIBILL2';
            V_TAB_GOOD_NAME := 'DT_K_G_JINBIGOOD2';
          ELSIF BTYPE = '金币入库单' THEN
            --V_TAB_CASH_NAME := 'DT_K_E_JINBIBILL';(- - 2019-07-31)
            --V_TAB_GOOD_NAME := 'DT_K_E_JINBIGOOD';
            V_TAB_CASH_NAME := 'DT_K_E_JINBIBILL2';
            V_TAB_GOOD_NAME := 'DT_K_E_JINBIGOOD2';
          ELSE
            V_TAB_CASH_NAME := 'DT_HIST_CASH';
            V_TAB_GOOD_NAME := 'DT_HIST_GOOD';
          END IF;
        
          V_COUNT := 0;
        
          SELECT COUNT(*)
            INTO V_CASH_COUNT
            FROM TAB
           WHERE TNAME = V_TAB_CASH_NAME;
        
          SELECT COUNT(*)
            INTO V_GOOD_COUNT
            FROM TAB
           WHERE TNAME = V_TAB_GOOD_NAME;
        
          IF V_CASH_COUNT <= 0 AND V_GOOD_COUNT <= 0 THEN
          
            V_CREATE_C_STRING := ' CREATE TABLE ' || V_TAB_CASH_NAME ||
                                 ' AS ' ||
                                 ' SELECT * FROM DTCASHIERBILLS WHERE 1 = 0 ';
          
            EXECUTE IMMEDIATE V_CREATE_C_STRING;
          
            /*V_ALTER_C_STRING := ' ALTER TABLE ' || V_TAB_CASH_NAME ||
            'ADD PRIMARY KEY (CASHIERBILLSKEY)';
            
            EXECUTE IMMEDIATE V_ALTER_C_STRING;*/
          
            V_CREATE_G_STRING := ' CREATE TABLE ' || V_TAB_GOOD_NAME ||
                                 ' AS ' ||
                                 ' SELECT * FROM DTGOODSBILLS WHERE 1 = 0 ';
          
            EXECUTE IMMEDIATE V_CREATE_G_STRING;
          
            /*V_ALTER_G_STRING := ' ALTER TABLE ' || V_TAB_GOOD_NAME ||
            'ADD PRIMARY KEY (GOODSBILLSKEY)';
            
            EXECUTE IMMEDIATE V_ALTER_G_STRING;*/
          
          END IF;
        
          EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || V_TAB_CASH_NAME ||
                            ' C WHERE C.CASHIERBILLSID =''' || CASHID || ''''
            INTO V_CASH_COUNT;
        
          EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || V_TAB_GOOD_NAME ||
                            ' G WHERE G.CASHIERBILLSID =''' || CASHID || ''''
            INTO V_GOOD_COUNT;
        
          IF V_CASH_COUNT <= 0 THEN
          
            V_CASH_COUNT := 0;
          
            V_INSERT_C_STRING := 'INSERT INTO ' || V_TAB_CASH_NAME ||
                                 ' SELECT * FROM DTCASHIERBILLS C WHERE C.CASHIERBILLSID =''' ||
                                 CASHID || '''';
          
            EXECUTE IMMEDIATE V_INSERT_C_STRING;
          
          END IF;
        
          IF V_GOOD_COUNT <= 0 THEN
          
            V_GOOD_COUNT := 0;
          
            V_INSERT_G_STRING := 'INSERT INTO ' || V_TAB_GOOD_NAME ||
                                 ' SELECT * FROM DTGOODSBILLS G WHERE G.CASHIERBILLSID =''' ||
                                 CASHID || '''';
            EXECUTE IMMEDIATE V_INSERT_G_STRING;
          
          END IF;
        
          EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || V_TAB_CASH_NAME ||
                            ' C WHERE C.CASHIERBILLSID =''' || CASHID || ''''
            INTO V_CASH_COUNT;
        
          EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || V_TAB_GOOD_NAME ||
                            ' G WHERE G.CASHIERBILLSID =''' || CASHID || ''''
            INTO V_GOOD_COUNT;
        
          IF V_GOOD_COUNT > 0 THEN
          
            DELETE DTGOODSBILLS G WHERE G.CASHIERBILLSID = CASHID;
          
          END IF;
        
          IF V_CASH_COUNT > 0 THEN
          
            DELETE DTCASHIERBILLS C WHERE C.CASHIERBILLSID = CASHID;
          
          END IF;
        
          IF V_NUM = 100 THEN
            COMMIT;
            V_SUM := V_SUM + 1;
            V_NUM := 0;
          END IF;
        
        END;
      
      END LOOP;
    
      /*EXIT WHEN CASH%NOTFOUND;
      
      END LOOP;
      CLOSE CASH;*/ --关闭游标
    
      IF V_NUM > 0 THEN
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('V_NUM:' || V_NUM);
      END IF;
    
    END LOOP;
  
    V_BUSI_DATE := V_BUSI_DATE + 1;
  END LOOP;

  --END IF;

  ROLLBACK;

  DBMS_LOB.APPEND(V_EXE_MSG, V_SUM * 100 + V_NUM || '条提交执行成功!');

  SYS_SAVELOG(V_PROC_NAME, 'Y', V_EXE_MSG, V_BEGIN_TIME, V_LOG);

  DBMS_LOB.FREETEMPORARY(V_EXE_MSG);
  DBMS_LOB.FREETEMPORARY(V_LOG);

  --异常处理
  RETURN; --若为顺序执行到此位置，则直接返回

  <<PROCESS_ERRMSG>>
  SYS_PROCESS_ERRMSG(V_PROC_NAME,
                     V_EXE_MSG,
                     V_ERR_MSG,
                     V_BEGIN_TIME,
                     V_LOG,
                     RESULT);
EXCEPTION
  WHEN OTHERS THEN
  
    V_ERR_MSG := 'SQL CODE:' || SQLCODE || CHR(10) || SQLERRM || CHR(10) ||
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() || CHR(10) ||
                 '有问题单据号：' || CASHID || CHR(10) || '有问题单据类别：' || BTYPE;
    DBMS_LOB.APPEND(V_EXE_MSG, V_ERR_MSG);
    SYS_SAVELOG(V_PROC_NAME, 'N', V_EXE_MSG, V_BEGIN_TIME, V_LOG);
    RESULT := V_ERR_MSG; --错误号对应的信息
    ROLLBACK;
  
  /*报错：ORA-01031: 权限不足。
  grant connect,resource,dba to cssy；
  赋权DBA之后，还有这个错误。
  执行 grant all privileges to cssy
  赋予任何主机访问数据的权限，问题得到了解决。*/

END PRO_DATAPROCESSING;
/

