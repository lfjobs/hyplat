create view DT_OA_SAFE_INSPECT_INFOVO as
select info.inspectno,kind.name as typename,info.makedate,info.attachment,--单据信息
dtc.companyname as tsicompany,dto2.organizationname as tsidept,dto.organizationname,dts.staffname as tsiperson,dts.recordcode as tsipersoncode,info.position as tsiPersonPost,--检测公司信息
dtcc.companyname as exunitname,dtcc.companytel as exunittel,dtcc.cresponsible as exunitperson,info.contactcompanybanknum as exunitbanknum,--往来单位信息
dtcc.responsibletel as exunitpersontel,dtcc.companyaddr as exunitaddr,dtcc.industrytype as exunitindustry,info.unitrelationship as exunitrelation,--往来单位信息
cu.staffname as experson,cu.reference as expersontel,cu.staffidentitycard as expersonIdcard,info.contactuserbanknum as expersonbanknum,--往来个人信息
cu.referencecode as expersonqq,cu.staffaddress as expersonaddr,info.personalrelationship as expersonrelation, --往来个人信息
info.id as inspectID,--单据ID
dto.organizationid as departmentID,--单据所在部门ID
dtc.companyid as tsicompanyID,--检测公司ID
dto2.organizationid as tsiDeptID,--检测人部门ID（子部门）
dts.staffid as tsiPersonID,--检测人ID
dtcc.ccompanyid as exunitID,--被检测单位ID
cu.staffid as expersonID,--被检测个人ID
info.safetypeid as inspectTypeID,--安全类别ID
info.key as inspectKey
from DT_OA_SAFE_INSPECT_INFO info
left join dtcompany dtc on dtc.companyid = info.companyid
left join DT_OA_SAFEKIND kind on info.safetypeid = kind.id
left join DTcorganization dto on dto.organizationid = info.departmentid
left join DTcorganization dto2 on dto2.organizationid = info.persondepartmentid
left join dt_hr_staff dts on dts.staffid = info.staffID
left join dtcontactconnection dtcont on dtcont.ccompanyid = info.departmentid
left join dtcontactcompany dtcc on dtcc.ccompanyid = info.contactcompanyid
left join dt_hr_staff cu on cu.staffid = info.contactuserid


/

