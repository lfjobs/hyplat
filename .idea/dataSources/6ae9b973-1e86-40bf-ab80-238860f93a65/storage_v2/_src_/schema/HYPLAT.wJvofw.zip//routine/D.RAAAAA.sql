create PROCEDURE          "D" IS

  b_acc      t_eshop_cuscom.account%type;
  tj_acc     t_eshop_cuscom.account%type;
  b_custype  t_eshop_cuscom.custype%type;
  pro_acc    varchar2(50);
  pro_cutype varchar2(50);

  cursor vcur_get_vouchers is
    select btj.account, tj.account
      from (select t.account, t.custype, m.mkid
              from dtmarketing m, t_eshop_cuscom t
             where t.account = m.userid) btj,
           (select t.account, t.custype, m.mkid
              from dtmarketing m, t_eshop_cuscom t
             where t.account = m.mkuserid) tj
     where tj.mkid = btj.mkid
       and tj.custype < btj.custype;

  cursor vcur_get_voucher2 is
    select btj.account, tj.superioragent
      from (select t.account, t.custype, m.mkid
              from dtmarketing m, t_eshop_cuscom t
             where t.account = m.userid) btj,
           (select t.account, t.custype, m.mkid, t.superioragent
              from dtmarketing m, t_eshop_cuscom t
             where t.account = m.mkuserid) tj
     where tj.mkid = btj.mkid
       and tj.custype = btj.custype;

  cursor vcur_get_voucher3 is
    select btj.account, btj.custype, tj.account
      from (select t.account, t.custype, m.mkid
              from dtmarketing m, t_eshop_cuscom t
             where t.account = m.userid) btj,
           (select t.account, t.custype, m.mkid
              from dtmarketing m, t_eshop_cuscom t
             where t.account = m.mkuserid) tj
     where tj.mkid = btj.mkid
       and tj.custype > btj.custype;

  cursor vcur_get_ud is
    SELECT t.account, t.custype
      FROM T_ESHOP_CUSCOM t
     START WITH t.ACCOUNT = tj_acc
    CONNECT BY PRIOR t.SUPERIORAGENT = t.ACCOUNT;
begin

  open vcur_get_vouchers;
  fetch vcur_get_vouchers
    into b_acc, tj_acc;
  LOOP
    EXIT WHEN vcur_get_vouchers%notFOUND;

    if tj_acc = '15810799888' then
      tj_acc := '18080818767';
    end if;

    update t_eshop_cuscom t
       set t.superioragent = tj_acc
     where t.account = b_acc;

    FETCH vcur_get_vouchers
      into b_acc, tj_acc;
  end loop;
  COMMIT;
  close vcur_get_vouchers;

  open vcur_get_voucher2;
  fetch vcur_get_voucher2
    into b_acc, tj_acc;
  LOOP
    EXIT WHEN vcur_get_voucher2%notFOUND;

    if tj_acc = '15810799888' then
      tj_acc := '18080818767';
    end if;

    update t_eshop_cuscom t
       set t.superioragent = tj_acc
     where t.account = b_acc;

    FETCH vcur_get_voucher2
      into b_acc, tj_acc;
  end loop;
  COMMIT;
  close vcur_get_voucher2;

  open vcur_get_voucher3;
  fetch vcur_get_voucher3
    into b_acc, b_custype, tj_acc;
  LOOP
    EXIT WHEN vcur_get_voucher3%notFOUND;

    open vcur_get_ud;
    fetch vcur_get_ud
      into pro_acc, pro_cutype;
    LOOP
      EXIT WHEN vcur_get_ud%notFOUND;

      if pro_cutype < b_custype then
        update t_eshop_cuscom t
           set t.superioragent = pro_acc
         where t.account = b_acc;
        EXIT;
      end if;
      fetch vcur_get_ud
        into pro_acc, pro_cutype;
    end loop;
    close vcur_get_ud;

    FETCH vcur_get_voucher3
      into b_acc, b_custype, tj_acc;
  end loop;
  COMMIT;
  close vcur_get_voucher3;

END d;


/

