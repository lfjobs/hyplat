create view VIEW_CSP as
select c.staffname ,c.coskey, c.staffid ,c.sex ,
c.staffidentitycard ,c.staffcode ,c.companyname,c.companyid as cspcompanyid,
p.payscaleid,p.scale,p.position,p.positionpay,p.basepay,p.worknight,p.workweek,p.workholidays,p.pushmoney,
p.timingmoney,p.piecerate,p.paaward,p.stpay,p.secrecypay,p.safetyaward,p.expenseallowances,p.discountedcost,
p.premium,p.alimony,p.pietypay,p.campaignpay,p.telecompay,p.pkpay,p.living,p.pitax,p.status,p.awardpay,p.companyid,p.payscalekey
,p.montasks,p.goaltasks,p.unpremium,p.kkqnpay
from dtcsp s
left join  view_sc c on c.staffid =s.staffid and c.companyid = s.companyid
left join dtpayscale p on s.payscaleid = p.payscaleid  and s.companyid = p.companyid


/

