create PROCEDURE GET_ASSIGN_COST(VI_CASH_ID  VARCHAR2, --单据ID
                                            VI_STAFF_ID VARCHAR2, --操作人ID
                                            VI_MONEY    VARCHAR2, --供应商成本（金币积分数）
                                            VO_CASH_JUM OUT VARCHAR --库存金币不够的单据ID
                                            ) /**供应商佣金**/
 IS
  V_GOODSID   DT_PRODUCTPACKAGING.GOODSID%TYPE; --物品id
  V_TYPE      DT_PRODUCTPACKAGING.TYPE%TYPE; --物品类型
  V_GOODSNAME DT_PRODUCTPACKAGING.GOODSNAME%TYPE; --物品名称

  V_SCCID  T_ESHOP_CUSCOM.SCCID%TYPE; --供应商帐号id
  V_SCCID2 T_ESHOP_CUSCOM.SCCID%TYPE; --客户帐号id

  V_COM_ID       DTCOMPANY.COMPANYID%TYPE; --平台公司ID
  V_COM_NAME     DTCOMPANY.COMPANYNAME%TYPE; --平台公司名称
  V_G_SN         DTCOMPANY.GROUPCOMPANYSN%TYPE; --平台组织机构ID
  V_GYS_COM_ID   DTCOMPANY.COMPANYID%TYPE; --平台公司ID
  V_GYS_COM_NAME DTCOMPANY.COMPANYNAME%TYPE; --平台公司名称
  V_GYS_G_SN     DTCOMPANY.GROUPCOMPANYSN%TYPE; --平台组织机构ID

  V_PROJECTNAME DTCASHIERBILLS.PROJECTNAME%TYPE; --项目名称

  V_PRO_SID   DT_HR_STAFF.STAFFID%TYPE; --操作人员ID
  V_PRO_SCODE DT_HR_STAFF.STAFFCODE%TYPE; --份虚拟货币的人员编号
  V_PRO_SNAME DT_HR_STAFF.STAFFNAME%TYPE; --分虚拟货币的人员名称

  V_SNAME DT_HR_STAFF.STAFFNAME%TYPE; --分虚拟货币的人员名称
  V_SCODE DT_HR_STAFF.STAFFCODE%TYPE; --份虚拟货币的人员编号

  V_JOU_NUM   DTCASHIERBILLS.JOURNALNUM%TYPE; --订单编号
  V_CK_JUM    DTCASHIERBILLS.JOURNALNUM%TYPE; --出库编号
  V_RK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --入库单id
  V_CK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --出库单id
  V_NEW_CA_ID DTCASHIERBILLS.CASHIERBILLSID%TYPE; --新单据表id
  V_NEW_GB_ID DTGOODSBILLS.GOODSBILLSID%TYPE; --新产品单据表id

  V_DEPOT_NAME   DTDEPOTMANAGE.DEPOTNAME%TYPE; --库房名称
  V_DEPOT_ID     DTDEPOTMANAGE.DEPOTID%TYPE; --库房id
  V_DEPOT_ITEMID DTDEPOTMANAGE.ITEMID%TYPE; --库房类型

  V_GUIZE_ID DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE; --规则id

  V_NEW_JF_ID DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE; --新积分id

  V_G_PPID     DTGOODSBILLS.PPID%TYPE; --产品ID
  V_GOOD_QUAN  DTGOODSBILLS.QUANTITY%TYPE; --产品数量
  V_GOOD_BI_ID DTGOODSBILLS.GOODSBILLSID%TYPE; --物品单据ID
  V_G_NAME     DTGOODSBILLS.GOODSNAME%TYPE; --产品名称
  V_JIANGPIN   DTGOODSBILLS.PREMIUMS%TYPE; --是否是奖品
  V_JB_PRICE   DTGOODSBILLS.PRICE%TYPE; --
  V_COST_PRICE DTGOODSBILLS.COSTMONEY%TYPE;
  V_GOOD_MONEY DTGOODSBILLS.MONEY%TYPE;

  V_SCORE      NUMBER;
  V_SCORE1     NUMBER;
  V_SUM_MONEY  NUMBER; --单据总金额
  V_COUNTNUM   NUMBER(5); --条数 
  V_XJHB       VARCHAR2(20);
  V_PRO_XJHB   VARCHAR2(10);
  V_WFSTATUS   DTCASHIERBILLS.WFSTATUS4%TYPE; --支付方式
  V_SUM_MONEY2 NUMBER; --代理对应不上人的金额数

  v_value dtpaybackupbill.hdpay%type; --接收参数值

  V_JB_SUM NUMBER;

  --关于促销品ljc
  /*促销品相关攒封
  V_PT_COUNT NUMBER;
  
  V_MONEY_TEMP NUMBER;*/

  CURSOR VCUR_GET_GOODS IS
    SELECT G.PPID,
           G.QUANTITY,
           G.GOODSBILLSID,
           G.GOODSNAME,
           G.PREMIUMS,
           G.COSTMONEY,
           G.PRICE,
           G.MONEY
      FROM DTCASHIERBILLS CB, DTGOODSBILLS G
     WHERE CB.CASHIERBILLSID = G.CASHIERBILLSID
       AND CB.CASHIERBILLSID = VI_CASH_ID
       AND CB.FKSTATUS = '03'
       AND CB.STATUSBILL = '04'
       AND CB.STATUS != '99';

  /*促销品相关攒封
  CURSOR VAR_GET_PTGOODS IS
    SELECT COSTMONEY
      FROM DTGOODSBILLS
     WHERE CASHIERBILLSID IN
           (SELECT PA.PTCASHIERBILLSID
              FROM DTGOODSBILLS GB, DT_PROMOTIONASSOCIATION PA
             WHERE GB.CASHIERBILLSID = PA.CASHIERBILLSID
               AND GB.CASHIERBILLSID = VI_CASH_ID);*/

BEGIN

  V_SUM_MONEY2 := 0;
  V_JB_SUM     := 0;
  V_XJHB       := '微分金金币';
  V_PRO_XJHB   := '金币';

  SELECT COUNT(*)
    INTO V_COUNTNUM
    FROM DTCASHIERBILLS C
   WHERE C.CASHIERBILLSID = VI_CASH_ID
     AND C.FKSTATUS = '03'
     AND C.STATUS != '99';

  IF V_COUNTNUM > 0 THEN
  
    V_COUNTNUM := 0;
    V_COM_ID   := 'company201009046vxdyzy4wg0000000025';
  
    --查询当前操作人信息
    SELECT S.STAFFNAME, S.STAFFCODE
      INTO V_SNAME, V_SCODE
      FROM DT_HR_STAFF S
     WHERE S.STAFFID = VI_STAFF_ID;
  
    --查询平台公司名称、组织机构ID
    SELECT C.COMPANYNAME, C.GROUPCOMPANYSN
      INTO V_COM_NAME, V_G_SN
      FROM DTCOMPANY C
     WHERE C.COMPANYID = V_COM_ID;
  
    --供应商信息
    SELECT CB.JOURNALNUM,
           C.COMPANYID, --供货商ID
           C.COMPANYNAME, --供货商名称
           C.GROUPCOMPANYSN, --供货商集团标识
           T.STAFFID,
           T.SCCID,
           S.STAFFCODE,
           S.STAFFNAME,
           to_number(nvl(CB.PRICESUB, 0)) * 100,
           cb.wfstatus4,
           cb.projectname
      INTO V_JOU_NUM,
           V_GYS_COM_ID,
           V_GYS_COM_NAME,
           V_GYS_G_SN,
           V_PRO_SID,
           V_SCCID,
           V_SCODE,
           V_SNAME,
           V_SUM_MONEY,
           V_WFSTATUS,
           V_PROJECTNAME
      FROM DTCASHIERBILLS CB, DTCOMPANY C, T_ESHOP_CUSCOM T, DT_HR_STAFF S
     WHERE CB.COMPANYID = T.COMPANYID
       AND S.STAFFID = T.STAFFID
       AND CB.COMPANYID = C.COMPANYID
       AND CB.CASHIERBILLSID = VI_CASH_ID;
  
    --判断库存里金币是否够
    SELECT COUNT(*)
      INTO V_COUNTNUM
      FROM DT_INV_INVT I
     WHERE GOODSNAME = V_XJHB
       AND COMPANYID = V_COM_ID
       AND I.INVENQUANTITY >= V_SUM_MONEY
       AND SOURCE = '用户兑换';
  
    IF V_COUNTNUM <= 0 THEN
    
      V_COUNTNUM := 0;
    
      SELECT COUNT(*)
        INTO V_COUNTNUM
        FROM DT_INV_INVT I
       WHERE GOODSNAME = V_XJHB
         AND COMPANYID = V_COM_ID
         AND I.INVENQUANTITY >= V_SUM_MONEY
         AND SOURCE = '批量生产';
    
    END IF;
  
    if V_COUNTNUM > 0 then
    
      SELECT COUNT(*)
        INTO V_COUNTNUM
        FROM DT_INV_INVT I
       WHERE GOODSNAME = '微分金积分'
         AND COMPANYID = V_COM_ID
         AND I.INVENQUANTITY >= V_SUM_MONEY
         AND WAREHOUSENAME = '销售库';
    
    end if;
  
    IF V_COUNTNUM <= 0 THEN
    
      VO_CASH_JUM := V_JOU_NUM;
    
      GOTO HERE;
    
    END IF;
  
    V_COUNTNUM := 0;
    if V_WFSTATUS != '05' and V_WFSTATUS != '07' then
      SELECT COUNT(*)
        INTO V_COUNTNUM
        FROM DTCASHIERBILLS C
       WHERE C.JNUMORDER = V_JOU_NUM
         AND C.BILLSTYPE = '收款单'
         AND C.STATUS != '99';
    else
      V_COUNTNUM := 1;
    end if;
    IF V_COUNTNUM = 1 THEN
    
      V_COUNTNUM := 0;
    
      SELECT COUNT(*)
        INTO V_COUNTNUM
        FROM DT_MEMBER_BACKUP T
       WHERE T.CASH_ID = VI_CASH_ID
         AND T.STATUS IS NULL
         AND T.JB_BL IS NULL;
    
      IF V_COUNTNUM <= 0 THEN
      
        V_COUNTNUM := 0;
      
        SELECT COUNT(*)
          INTO V_COUNTNUM
          FROM DT_MEMBER_BACKUP T
         WHERE T.CASH_ID = VI_CASH_ID
           AND T.STATUS IS NULL;
      
        IF V_COUNTNUM <= 8 THEN
        
          V_COUNTNUM := 0;
        
          IF VI_MONEY IS NOT NULL THEN
          
            SELECT O.OA_SCCID
              INTO V_SCCID2
              FROM DT_ORDER_BILL_ADD O
             WHERE O.OA_BILL_ID = VI_CASH_ID;
            --代理商
            OPEN VCUR_GET_GOODS;
          
            FETCH VCUR_GET_GOODS
              INTO V_G_PPID,
                   V_GOOD_QUAN,
                   V_GOOD_BI_ID,
                   V_G_NAME,
                   V_JIANGPIN,
                   V_JB_PRICE,
                   V_COST_PRICE,
                   V_GOOD_MONEY;
            LOOP
              EXIT WHEN VCUR_GET_GOODS%NOTFOUND;
              --代理商
              GET_PROXY(V_COM_ID,
                        V_G_NAME,
                        V_GOOD_BI_ID,
                        V_G_PPID,
                        VI_CASH_ID,
                        VI_STAFF_ID,
                        V_WFSTATUS);
            
              V_JB_SUM := V_JB_SUM +
                          round(V_JB_PRICE * V_GOOD_QUAN * 100, 2);
            
              FETCH VCUR_GET_GOODS
                INTO V_G_PPID,
                     V_GOOD_QUAN,
                     V_GOOD_BI_ID,
                     V_G_NAME,
                     V_JIANGPIN,
                     V_JB_PRICE,
                     V_COST_PRICE,
                     V_GOOD_MONEY;
            
            END LOOP;
          
            CLOSE VCUR_GET_GOODS;
          
            --V_SUM_MONEY := VI_MONEY;
          
            --V_SUM_MONEY := VI_MONEY + 0;
            IF VI_MONEY > 0 THEN
            
              BEGIN
                --标注是否是进件订单 1：进件订单不分供应商的钱
                SELECT P.HDPAY
                  INTO V_VALUE
                  FROM DTPAYBACKUPBILL P
                 WHERE P.JOURNALNUM = V_JOU_NUM;
              EXCEPTION
                WHEN OTHERS THEN
                  V_VALUE := NULL;
              END;
            
              --判断是否生成供应商金币出入库单
              IF V_VALUE IS NULL THEN
              
                --供应商金币入库单
                V_RK_CA_ID := FUN_GET_ID('cashierbills');
                INSERT INTO DTCASHIERBILLS
                  (CASHIERBILLSKEY,
                   CASHIERBILLSID,
                   COMPANYID,
                   BILLSTYPE,
                   JOURNALNUM,
                   STAFFID,
                   STAFFNAME,
                   STAFFCODE,
                   CASHIERDATE,
                   STATUS,
                   COMPANYNAME,
                   PROID,
                   PROJECTNAME, --项目名称
                   GROUPCOMPANYSN,
                   INPUTID,
                   INPUTNAME,
                   APPSTYLE,
                   PRICESUB,
                   CCOMPANYID,
                   CCOMPANYNAME,
                   STATUSBILL,
                   JNUMORDER)
                VALUES
                  (DBMS_RANDOM.STRING('X', 32),
                   V_RK_CA_ID,
                   V_GYS_COM_ID,
                   '金币入库单',
                   FUN_GET_BILL_ID(),
                   V_PRO_SID,
                   V_PRO_SNAME, --会员名称
                   V_PRO_SCODE, --会员编号
                   SYSDATE,
                   '15',
                   V_GYS_COM_NAME, --公司名称
                   '002',
                   '供应商成本金币分配',
                   V_GYS_G_SN, --集团组织机构ID
                   VI_STAFF_ID,
                   V_SNAME,
                   '08',
                   TO_CHAR(VI_MONEY / 100,
                           'FM999999999999999999999999999999990.999999999'),
                   V_COM_id,
                   V_COM_NAME,
                   '04',
                   V_JOU_NUM);
              
                --添加关系表数据
                INSERT INTO DTRELATEDBILL
                  (RBKEY, RBID, CASHID, CASHFID)
                VALUES
                  (DBMS_RANDOM.STRING('X', 32),
                   FUN_GET_ID('RELATEDBILL'),
                   VI_CASH_ID,
                   V_RK_CA_ID);
              
                --平台金币出库单
                V_CK_CA_ID := FUN_GET_ID('cashierbills');
                V_CK_JUM   := FUN_GET_BILL_ID();
                INSERT INTO DTCASHIERBILLS
                  (CASHIERBILLSKEY,
                   CASHIERBILLSID,
                   COMPANYID,
                   BILLSTYPE,
                   JOURNALNUM,
                   STAFFID,
                   STAFFNAME,
                   STAFFCODE,
                   CASHIERDATE,
                   STATUS,
                   COMPANYNAME,
                   PROID,
                   PROJECTNAME, --项目名称
                   GROUPCOMPANYSN,
                   INPUTID,
                   INPUTNAME,
                   APPSTYLE,
                   PRICESUB,
                   CCOMPANYID,
                   CCOMPANYNAME,
                   CONTACTUSERID,
                   CTUSERNAME,
                   STATUSBILL,
                   JNUMORDER)
                VALUES
                  (DBMS_RANDOM.STRING('X', 32),
                   V_CK_CA_ID,
                   V_COM_id,
                   '金币出库单',
                   V_CK_JUM,
                   VI_STAFF_ID,
                   V_SNAME, --会员名称
                   V_SCODE, --会员编号
                   SYSDATE,
                   '16',
                   V_COM_NAME, --公司名称
                   '002',
                   '供应商成本金币分配',
                   V_G_SN, --集团组织机构ID
                   VI_STAFF_ID,
                   V_SNAME,
                   '08',
                   TO_CHAR(VI_MONEY / 100,
                           'FM999999999999999999999999999999990.999999999'),
                   V_COM_ID,
                   V_COM_NAME,
                   V_PRO_SID,
                   V_PRO_SNAME,
                   '04',
                   V_JOU_NUM);
              
                --平台\用户金币出库\入库产品表
                FOR I IN 1 .. 2 LOOP
                  IF I = 1 THEN
                    --入库
                    V_DEPOT_NAME := '销售库';
                    V_DEPOT_ID   := NULL;
                    V_NEW_CA_ID  := V_RK_CA_ID;
                  
                    V_GOODSID   := NULL;
                    V_TYPE      := NULL;
                    V_GOODSNAME := V_XJHB;
                  ELSE
                    --出库
                    SELECT D.DEPOTNAME, D.DEPOTID, D.ITEMID
                      INTO V_DEPOT_NAME, V_DEPOT_ID, V_DEPOT_ITEMID
                      FROM DTDEPOTMANAGE D
                     WHERE D.COMPANYID = V_COM_ID
                       AND D.DEPOTNAME = '销售库';
                  
                    SELECT A.GOODSID, A.TYPE, A.GOODSNAME
                      INTO V_GOODSID, V_TYPE, V_GOODSNAME
                      FROM DT_PRODUCTPACKAGING A
                     WHERE A.COMPANYID = V_COM_id
                       AND A.GOODSNAME = V_XJHB;
                  
                    V_NEW_CA_ID := V_CK_CA_ID;
                  END IF;
                
                  V_NEW_GB_ID := FUN_GET_ID('goodsbills');
                
                  SELECT COUNT(*)
                    INTO V_COUNTNUM
                    FROM DT_PRODUCTPACKAGING A
                   WHERE A.COMPANYID = V_COM_id
                     AND A.GOODSNAME = V_XJHB;
                
                  IF I = 2 THEN
                    --平台金币库存盘点表
                    INSERT INTO DT_INV_STOCKINVT
                      (STOCKINVKEY,
                       STOCKINVID,
                       COMPANYID,
                       GROUPCOMPANYSN,
                       GOODSID,
                       GOODSTYPE,
                       GOODSNAME,
                       INVENQUANTITY,
                       TYPE,
                       STAFFID,
                       STAFFNAME,
                       WAREHOUSE,
                       WAREHOUSENAME,
                       GOODSBILLSID,
                       INTIME)
                    VALUES
                      (DBMS_RANDOM.STRING('X', 32),
                       FUN_GET_ID('stockinv'),
                       V_COM_ID,
                       V_g_sn,
                       V_GOODSID,
                       V_TYPE,
                       V_GOODSNAME,
                       TO_CHAR(VI_MONEY,
                               'FM999999999999999999999999999999990.999999999'),
                       '01',
                       VI_STAFF_ID,
                       V_SNAME,
                       V_DEPOT_ID,
                       V_DEPOT_NAME,
                       V_NEW_GB_ID,
                       SYSDATE);
                  
                  END IF;
                
                  IF V_COUNTNUM > 0 THEN
                  
                    INSERT INTO DTGOODSBILLS
                      (GOODSBILLSKEY,
                       GOODSBILLSID,
                       --COMPANYID,
                       CASHIERBILLSID,
                       SUBJECTSID,
                       SUBJECTSNAME,
                       COSTTYPE, --费用类别
                       PAYTYPE, --付款方式
                       WEIGHT,
                       GOODSID,
                       QUANTITY,
                       PRICE,
                       MONEY,
                       DEPOTID, --库房ID
                       DEPOTNAME, --库房名称
                       GOODSVARIABLEID, --单位
                       IDENTIFYINGCODE, --00
                       BATCHNUMBER, --批号
                       GOODSNOMBER, --物品在账单中的排列序号
                       GOODSNUM,
                       GOODSNAME,
                       TYPEID,
                       STANDARD,
                       KCSTATUS, --16：已出库
                       GOODSTATUS, --状态00正常 01维修02报废
                       PPID)
                      SELECT DBMS_RANDOM.STRING('X', 32),
                             V_NEW_GB_ID,
                             --COMPANYID,
                             V_NEW_CA_ID,
                             A.SUBJECTID,
                             A.SUBJECTNAME,
                             '', --费用类别
                             '08',
                             A.WEIGHT,
                             A.GOODSID,
                             TO_CHAR(VI_MONEY,
                                     'FM999999999999999999999999999999990.999999999'),
                             '0.01',
                             TO_CHAR(VI_MONEY / 100,
                                     'FM999999999999999999999999999999990.999999999'),
                             V_DEPOT_ID,
                             V_DEPOT_NAME,
                             A.VARIABLEID,
                             '00',
                             '',
                             '1',
                             A.GOODSNUM,
                             A.GOODSNAME,
                             A.TYPE,
                             A.STANDARD,
                             '15',
                             '00',
                             A.PPID
                        FROM DT_PRODUCTPACKAGING A
                       WHERE A.COMPANYID = V_COM_id
                         AND A.GOODSNAME = V_XJHB;
                  
                  ELSE
                  
                    INSERT INTO DTGOODSBILLS
                      (GOODSBILLSKEY,
                       GOODSBILLSID,
                       --COMPANYID,
                       CASHIERBILLSID,
                       PAYTYPE, --付款方式
                       QUANTITY,
                       PRICE,
                       MONEY,
                       DEPOTNAME, --库房名称
                       IDENTIFYINGCODE, --00
                       GOODSNAME,
                       KCSTATUS, --15：已入库
                       GOODSTATUS) --状态00正常 01维修02报废
                    VALUES
                      (DBMS_RANDOM.STRING('X', 32),
                       V_NEW_GB_ID,
                       --COM_ID,
                       V_NEW_CA_ID,
                       '08',
                       TO_CHAR(VI_MONEY,
                               'FM999999999999999999999999999999990.999999999'),
                       '0.01',
                       TO_CHAR(VI_MONEY / 100,
                               'FM999999999999999999999999999999990.999999999'),
                       '销售库',
                       '00',
                       V_XJHB,
                       '15',
                       '00');
                  
                  END IF;
                
                END LOOP;
              
                --进销存单据表
                INSERT INTO DT_INV_FB
                  (FINANCIALBILLKEY,
                   FINANCIALBILLID,
                   GROUPCOMPANYSN,
                   COMPANYID,
                   BILLSTATUS,
                   BILLSTYPE,
                   JOURNALNUM,
                   BILLSDATE,
                   BILLSTAFFID,
                   BILLSTAFFNAME,
                   DEPOTID,
                   DEPOTNAME,
                   CASHIERBILLSID)
                VALUES
                  (DBMS_RANDOM.STRING('X', 32),
                   FUN_GET_ID('financial'),
                   V_g_sn,
                   V_COM_id,
                   '22',
                   '金币出库单',
                   V_CK_JUM,
                   SYSDATE,
                   '',
                   '系统生成',
                   V_DEPOT_ID,
                   V_DEPOT_NAME,
                   V_CK_CA_ID);
              
                ----------------------------------------------------用户金币存储值改变------------------------------------
              
                SELECT G.WFJ_GUIZE_ID
                  INTO V_GUIZE_ID
                  FROM DT_WFJ_GUIZE G
                 WHERE G.WFJ_GUIZE_NAME = '供应商成本'
                   AND G.COMPANY_ID = V_COM_ID;
              
                --往会员金币表以及金币收支明细表里存值
                UPDATE DT_WFJ_JIFEN
                   SET WFJ_JIFEN_SCORE = NVL(WFJ_JIFEN_SCORE, 0) + VI_MONEY
                 WHERE STAFF_ID = V_PRO_SID
                   AND SCCID = V_SCCID;
              
                IF SQL%NOTFOUND THEN
                
                  V_NEW_JF_ID := FUN_GET_ID('wfjjifen');
                
                  INSERT INTO DT_WFJ_JIFEN
                    (WFJ_JIFEN_KEY,
                     WFJ_JIFEN_ID,
                     STAFF_ID,
                     WFJ_JIFEN_SCORE,
                     WFJ_JIFEN_STATE,
                     COMPANY_ID,
                     SCCID)
                  VALUES
                    (DBMS_RANDOM.STRING('X', 32),
                     V_NEW_JF_ID,
                     V_PRO_SID,
                     VI_MONEY,
                     0,
                     V_COM_ID,
                     V_SCCID);
                
                ELSE
                
                  SELECT WFJ_JIFEN_ID
                    INTO V_NEW_JF_ID
                    FROM DT_WFJ_JIFEN
                   WHERE STAFF_ID = V_PRO_SID
                     AND SCCID = V_SCCID;
                
                END IF;
              
                OPEN VCUR_GET_GOODS;
              
                FETCH VCUR_GET_GOODS
                  INTO V_G_PPID,
                       V_GOOD_QUAN,
                       V_GOOD_BI_ID,
                       V_G_NAME,
                       V_JIANGPIN,
                       V_JB_PRICE,
                       V_COST_PRICE,
                       V_GOOD_MONEY;
                LOOP
                  EXIT WHEN VCUR_GET_GOODS%NOTFOUND;
                
                  IF V_JIANGPIN IS NULL OR V_JIANGPIN = '0' THEN
                  
                    /*促销品相关攒封
                    SELECT COUNT(PA.PTCASHIERBILLSID)
                      INTO V_PT_COUNT
                      FROM DTGOODSBILLS GB, DT_PROMOTIONASSOCIATION PA
                     WHERE GB.CASHIERBILLSID = PA.CASHIERBILLSID
                       AND GB.CASHIERBILLSID = VI_CASH_ID;
                    
                    V_MONEY_TEMP := 0;
                    
                    IF V_PT_COUNT > 0 THEN
                    
                      FOR PTGOODS IN VAR_GET_PTGOODS LOOP
                      
                        V_MONEY_TEMP := (V_MONEY_TEMP +
                                        TO_NUMBER(PTGOODS.COSTMONEY));
                      
                      END LOOP;
                    
                    END IF;
                    
                    V_MONEY_TEMP := (TO_NUMBER(V_GOOD_QUAN) *
                                    TO_NUMBER(V_JB_PRICE) - V_MONEY_TEMP);
                    
                    V_SCORE := ROUND(V_MONEY_TEMP * 100, 4);*/
                  
                    V_SCORE := ROUND(TO_NUMBER(V_GOOD_QUAN) *
                                     TO_NUMBER(V_JB_PRICE) * 100,
                                     4);
                  
                    --金币收支明细
                    INSERT INTO DT_WFJ_JIFEN_DETAIL
                      (JIFEN_DETAIL_KEY,
                       JIFEN_DETAIL_ID,
                       JIFEN_DETAIL_NAME,
                       JIFEN_DETAIL_DATE,
                       JIFEN_DETAIL_SCORE,
                       JIFEN_DETAIL_STATE,
                       WFJ_GUIZE_ID,
                       WFJ_JIFEN_ID,
                       WFJ_CASH_ID,
                       WFJ_GOOD_ID)
                    VALUES
                      (DBMS_RANDOM.STRING('X', 32),
                       FUN_GET_ID('wfjjifendetail'),
                       V_G_NAME || '-供应商成本',
                       SYSDATE,
                       TO_CHAR(V_SCORE,
                               'FM999999999999999999999999999999990.999999999'),
                       1,
                       V_GUIZE_ID, --规则外键
                       V_NEW_JF_ID,
                       V_RK_CA_ID, --金币入库单据ID
                       V_GOOD_BI_ID);
                  
                  END IF;
                
                  FETCH VCUR_GET_GOODS
                    INTO V_G_PPID,
                         V_GOOD_QUAN,
                         V_GOOD_BI_ID,
                         V_G_NAME,
                         V_JIANGPIN,
                         V_JB_PRICE,
                         V_COST_PRICE,
                         V_GOOD_MONEY;
                
                END LOOP;
              
                CLOSE VCUR_GET_GOODS;
              
                -------------------------------------------------平台金币库存改变-----------------------------------------
              
                --平台金币库存表
              
                UPDATE DT_INV_INVT
                   SET INVENQUANTITY = TO_CHAR(TO_NUMBER(NVL(INVENQUANTITY,
                                                             0)) - VI_MONEY,
                                               'FM999999999999999999999999999999990.999999999'),
                       SUMPRICE      = TO_CHAR(TO_NUMBER(NVL(SUMPRICE, 0)) -
                                               VI_MONEY / 100,
                                               'FM999999999999999999999999999999990.999999999')
                 WHERE GOODSNAME = V_XJHB
                   AND COMPANYID = V_COM_ID
                   AND SOURCE = '用户兑换'
                   AND WAREHOUSENAME = '销售库';
              
                IF SQL%NOTFOUND THEN
                
                  UPDATE DT_INV_INVT
                     SET INVENQUANTITY = TO_CHAR(TO_NUMBER(NVL(INVENQUANTITY,
                                                               0)) -
                                                 VI_MONEY,
                                                 'FM999999999999999999999999999999990.999999999'),
                         SUMPRICE      = TO_CHAR(TO_NUMBER(NVL(SUMPRICE, 0)) -
                                                 VI_MONEY / 100,
                                                 'FM999999999999999999999999999999990.999999999')
                   WHERE GOODSNAME = V_XJHB
                     AND COMPANYID = V_COM_ID
                     AND SOURCE = '批量生产'
                     AND WAREHOUSENAME = '销售库';
                
                END IF;
              
              END IF;
            
            END IF;
          
            -------------------------------------------------奖品成本-----------------------------------------
            OPEN VCUR_GET_GOODS;
          
            FETCH VCUR_GET_GOODS
              INTO V_G_PPID,
                   V_GOOD_QUAN,
                   V_GOOD_BI_ID,
                   V_G_NAME,
                   V_JIANGPIN,
                   V_JB_PRICE,
                   V_COST_PRICE,
                   V_GOOD_MONEY;
            LOOP
              EXIT WHEN VCUR_GET_GOODS%NOTFOUND;
            
              IF V_JIANGPIN = '1' THEN
                --奖品成本
                CB_PREMIUMS(V_COM_ID,
                            VI_CASH_ID,
                            VI_STAFF_ID,
                            V_JB_PRICE * 100);
              END IF;
            
              FETCH VCUR_GET_GOODS
                INTO V_G_PPID,
                     V_GOOD_QUAN,
                     V_GOOD_BI_ID,
                     V_G_NAME,
                     V_JIANGPIN,
                     V_JB_PRICE,
                     V_COST_PRICE,
                     V_GOOD_MONEY;
            
            END LOOP;
          
            CLOSE VCUR_GET_GOODS;
          
            -------------------------------------------------业务佣金-----------------------------------------
            BEGIN
              SELECT T.JB_NUM
                INTO V_SCORE1
                FROM DT_MEMBER_BACKUP T
               WHERE T.CASH_ID = VI_CASH_ID
                 AND T.STATUS IS NULL
                 AND ROWNUM = 1;
            EXCEPTION
              When OTHERS then
                V_SCORE1 := null;
            END;
          
            IF V_SCORE1 IS NOT NULL THEN
            
              GET_NEW_PROPORTION_COST(VI_CASH_ID,
                                      V_COM_ID,
                                      V_WFSTATUS,
                                      V_JOU_NUM,
                                      V_PROJECTNAME);
            
            ELSE
            
              GET_PROPORTION_COST(VI_CASH_ID,
                                  V_COM_ID,
                                  V_WFSTATUS,
                                  V_JOU_NUM);
            
            END IF;
            --消费补助
            GET_SUBSIDIZE(V_COM_ID, VI_CASH_ID, V_JOU_NUM, V_WFSTATUS);
          
            UPDATE DTCASHIERBILLS C
               SET C.FKSTATUS = '04'
             WHERE C.STATUSBILL = '04'
               AND C.BILLSTYPE = '项目收入预算单'
               AND C.FKSTATUS = '03'
               AND C.CASHIERBILLSID = VI_CASH_ID;
          
            SELECT NVL(SUM(M.JB_NUM), 0) + V_JB_SUM
              INTO V_JB_SUM
              FROM DT_MEMBER_BACKUP M
             WHERE M.CASH_JUM = V_JOU_NUM;
          
            SELECT NVL(SUM(D.JBNUM), 0) + V_JB_SUM
              INTO V_JB_SUM
              FROM DT_DAILIMEMBER D
             WHERE D.CASHJUM = V_JOU_NUM;
          
            SELECT NVL(SUM(S.JB_NUM), 0) + V_JB_SUM
              INTO V_JB_SUM
              FROM DT_SUBSIDIZE_BACKUP S
             WHERE S.CASH_JUM = V_JOU_NUM;
          
            IF V_JB_SUM > V_SUM_MONEY THEN
              ROLLBACK;
              GOTO HERE;
            ELSE
              COMMIT;
            END IF;
          
          END IF;
        END IF;
      END IF;
    END IF;
  END IF;
  <<HERE>>
  NULL;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('SQL CODE:' || SQLCODE || CHR(10) || SQLERRM ||
                         CHR(10) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE());
  
END GET_ASSIGN_COST;
/

