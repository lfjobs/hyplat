create view DTCOSJOBTASKVO as
select
(select co.companyName from Dtcompany co where co.companyid = jt.companyid)companyName,
(select org.organizationName from dtcorganization org where org.organizationID = jt.organizationid)organizationName,
 st.staffname,
  st.staffcode ,
  jt.jobtaskkey,jt.jobtaskid,jt.companyid,jt.organizationid,jt.staffid,jt.neededtime,jt.tasknumber,
  jt.taskname,jt.startdate,jt.enddate,jt.bonuspoint,jt.penaltypoint,jt.checkuptime,jt.actualperformance,
  jt.actualbonuspoint,jt.actualpenaltypoint,jt.status,jt.codeid,jt.codevalue
from dtcosjobtask jt
join dt_hr_staff st
on jt.staffid = st.staffid and exists
(select 1 from view_sc s where jt.companyid = s.companyid and jt.staffid = s.staffid)


/

