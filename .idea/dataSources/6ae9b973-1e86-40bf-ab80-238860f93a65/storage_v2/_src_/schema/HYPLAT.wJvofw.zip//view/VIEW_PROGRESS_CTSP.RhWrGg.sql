create view VIEW_PROGRESS_CTSP as
select ddsrs.companyid,ddsrs.type,decode(ddsrs.subject,'科目一','01','科目二','02','科目三','03','04') subject,ddsrs.program,sum(ddsrs.time) alltime from ddsrsyllabus ddsrs
       group by ddsrs.companyid,ddsrs.type,ddsrs.subject,ddsrs.program


/

