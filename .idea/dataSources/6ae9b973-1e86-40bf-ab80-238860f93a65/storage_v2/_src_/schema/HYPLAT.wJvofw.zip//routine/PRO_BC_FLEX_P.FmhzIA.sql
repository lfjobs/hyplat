create PROCEDURE          "PRO_BC_FLEX_P" (vi_Beg_Date IN dt_inv_result.STARTDATE%TYPE, --起时间
                                          vi_End_Date IN dt_inv_result.enddate%TYPE, --止时间
                                          vi_Kind     IN dt_inv_result.tab_type%TYPE, --报表类别（A:资产负债表，B ：损益表C:资产负债表以及损益表 ）
                                          vi_Unit     IN CHAR, --单位注记：Y 千元    N 元
                                          vi_Detail   IN CHAR, --是否列印明细：Y 列印明细N 不列印明细
                                          vi_work_id  IN varchar2, --列印id
                                          vi_com_id   IN CHAR --公司id
                                          ) IS
  v_tab_symbol  DT_INV_CCBSGL.tab_symbol%TYPE; --当前报表类别最大报表代号
  v_pla_type    DT_INV_CCPBSGL.pla_type%TYPE; --计算类别（A:会计科目，B:报表代号）
  v_Pre_Accn    DT_INV_CCPBSGL.ST_CONTENTS%TYPE; --会计科目（报表代号）
  v_Cal_Mode    DT_INV_CCPBSGL.PLA_MODE%TYPE; --计算方式（A:加，B:减）
  v_open_ym     dt_inv_dyco.DYCO_YEAR%TYPE; --年度
  v_OpenAmt     dt_inv_result.RE_MONEY%TYPE; --结果金额(借贷相减)
  --v_SumAmt      dt_inv_result.RE_MONEY%TYPE; --金额(???)  
  v_Amt         dt_inv_result.RE_MONEY%TYPE; --当前报表类别的金额
  v_com_id      dt_inv_result.com_id%TYPE; --公司id
  v_Acc_No      DTCSUBJECTS.SUBJECTSNUMBERS%TYPE; --科目编号
  v_Rst_id      dt_inv_result.re_id%TYPE; --印标id
  v_D_Amt       dt_inv_result.RE_MONEY%TYPE; --借方金额(临时变量)
  v_C_Amt       dt_inv_result.RE_MONEY%TYPE; --贷方金额(临时变量)
  vn_Number     NUMBER;
  v_Amt_chk     dt_inv_result.RE_MONEY%TYPE; --金额(???)
  v_Amt_chk1    dt_inv_result.RE_MONEY%TYPE; --金额(???)
  v_Perc        dt_inv_result.RE_PET%TYPE; --百分比 
  vi_sy_amt     number;
  v_tab_symbol1 dt_inv_result.tab_symbol%TYPE; --报表代号
  v_count       NUMBER;

  ------第一步  报表代号集合

  CURSOR vcur_Prnm IS --根据条件查询 A资产负债或者 B 损益 赋值到变量vcur_Prnm (当前报表类别代号分组查询 )
    SELECT tab_symbol
      FROM DT_INV_CCBSGL
     WHERE tab_type = vi_Kind --当前报表类别
       AND com_id = v_com_id
     ORDER BY tab_symbol;
  ----------2  计算公式集合
  CURSOR vcur_Prnd IS --查询当前报表类别最大报表代号的计算类别（A:会计科目，B:报表代号），会计科目（报表代号），计算方式（A:加，B:减）
    SELECT pla_type, ST_CONTENTS, PLA_MODE --计算类别（A:会计科目，B:报表代号），会计科目（报表代号），计算方式（A:加，B:减）
      FROM DT_INV_CCPBSGL
     WHERE tab_symbol = v_tab_symbol --当前报表类别最大报表代号
       AND pla_type = v_pla_type --计算类别（A:会计科目，B:报表代号）
       AND com_id = v_com_id; --公司id

  ---------3
  CURSOR vcur_Mark IS --查询当前报表类别是本期损益注记的代号
    SELECT tab_symbol --报表代号
      FROM DT_INV_CCBSGL
     WHERE tab_type = vi_Kind --报表类别（A:资产负债表，B：损益表）
       AND NVL(cgl_ation, 'N') = 'Y' --本期损益注记（Y/N Y:损益，N:为默认值），nvl(字段，‘x’)字段值等于null就这个函数得到的结果就是'x',一般用于存在空值比较的情况下
       AND com_id = v_com_id;
  ----4
  TYPE vcur_Acct IS REF CURSOR;
  vcur_Acc vcur_Acct;
  ----5
  PROCEDURE Write_Percent(vi_Mark IN CHAR) IS --过程查询资产或负债 (A\B)
  BEGIN
    ---(1)
    SELECT MAX(tab_symbol) -- 资产或负债的 报表代号（当前报表类别最大报表代号赋值）一个
      INTO v_tab_symbol --报表代号
      FROM DT_INV_CCBSGL
     WHERE NVL(BS_ATION, 'N') = vi_Mark --资产负债损益表内容注记( A:资产,B:负债及股东权益,C:营业收入净值,D:本期纯益,E:其他)
       AND tab_type = vi_Kind --报表类别（A:资产负债表，B：损益表）
       AND com_id = v_com_id;
    ----(2)
    SELECT RE_MONEY --资产或损益的金额 ，条件是最大的报表代号（ 当前报表类别的金额赋值
      INTO v_Amt --金额
      FROM dt_inv_result
     WHERE tab_type = vi_Kind --报表类别（A:资产负债表，B：损益表）
       AND com_id = v_com_id
       AND STARTDATE = vi_Beg_Date ----起时间
       AND ENDDATE = vi_End_Date --止时间
       AND tab_symbol = v_tab_symbol; --报表代号
  
    IF vi_Mark = 'N' THEN
      --不属于资产负债损益表内容注记赋值到变量v_Amt_chk1 来源（2）
      v_Amt_chk1 := v_Amt;
    END IF;
  
    IF vi_Mark = 'Y' THEN
      --不属于资产负债损益表内容注记赋值到变量v_Amt_chk 来源（2）
      v_Amt_chk := v_Amt;
    END IF;
  
    IF v_Amt <> 0 THEN
      -- Round 函数 (四舍五入)
      --描述 : 传回一个数值，该数值是按照指定的小数位元数进行四舍五入运算的结果。
      --SELECT ROUND( number, [ decimal_places ] ) FROM DUAL
      --参数:
      --number : 欲处理之数值
      --decimal_places : 四舍五入 , 小数取几位 ( 预设为 0 )
      UPDATE dt_inv_result --根据资产负债类别查询自定AB 的金额，同最大代号的金额做比率
         SET RE_PET = ROUND(NVL(RE_MONEY, 0) / v_Amt * 100, 2) --百分比
       WHERE tab_type = vi_Kind --资产负债表
         AND com_id = v_com_id
         AND STARTDATE = vi_Beg_Date ----起时间
         AND ENDDATE = vi_End_Date --止时间
         AND tab_symbol IN (SELECT tab_symbol
                              FROM DT_INV_CCBSGL
                             WHERE NVL(BS_ATION, 'N') = vi_Mark --资产负债损益表内容注记( A:资产,B:负债及股东权益,C:营业收入净值,D:本期纯益,E:其他)
                               AND tab_type = vi_Kind --资产负债表
                               AND com_id = v_com_id);
    
      DECLARE
        CURSOR PER IS
          SELECT a.tab_symbol, SUM(c.RE_PET) percent --百分比 和
            FROM DT_INV_CCBSGL a,
                 (SELECT ST_CONTENTS, tab_symbol --会计科目（报表代号），报表代号
                    FROM DT_INV_CCPBSGL
                   WHERE tab_symbol IN
                         (SELECT MAX(tab_symbol) tab_symbol
                            FROM DT_INV_CCPBSGL
                           WHERE pla_type = 'B' --计算类别（A:会计科目，B:报表代号）
                             AND com_id = v_com_id
                           GROUP BY SUBSTR(tab_symbol, 1, 3)) --substr(字符串,截取开始位置,截取长度) //返回截取的字
                     AND com_id = v_com_id) b,
                 dt_inv_result c
           WHERE c.com_id = v_com_id
             AND c.STARTDATE = vi_Beg_Date --起
             AND c.ENDDATE = vi_End_Date --止
             AND b.ST_CONTENTS = c.tab_symbol --报表代号
             AND a.com_id = c.com_id
             AND a.tab_symbol = b.tab_symbol --报表代号
             AND NVL(BS_ATION, 'N') = vi_Mark --资产负债损益表内容注记
             AND b.tab_symbol <> v_tab_symbol
           GROUP BY a.tab_symbol;
      BEGIN
        --循环赋值百分比
        FOR R IN PER LOOP
          UPDATE dt_inv_result
             SET RE_PET = R.PERCENT
           WHERE tab_type = vi_Kind
             AND com_id = v_com_id
             AND STARTDATE = vi_Beg_Date
             AND ENDDATE = vi_End_Date
             AND tab_symbol = r.tab_symbol;
        END LOOP;
        COMMIT;
      
        SELECT SUM(RE_PET)
          INTO v_perc
          FROM DT_INV_CCBSGL a,
               (SELECT MAX(tab_symbol) tab_symbol
                  FROM DT_INV_CCPBSGL
                 WHERE pla_type = 'B' --计算类别（A:会计科目，B:报表代号）
                   AND com_id = v_com_id
                 GROUP BY SUBSTR(tab_symbol, 1, 3)) b,
               dt_inv_result c
         WHERE c.tab_type = vi_Kind
           AND c.com_id = v_com_id
           AND c.STARTDATE = vi_Beg_Date
           AND c.ENDDATE = vi_End_Date
           AND a.tab_type = c.tab_type
           AND b.tab_symbol = c.tab_symbol
           AND a.com_id = c.com_id
           AND a.tab_symbol = b.tab_symbol
           AND NVL(BS_ATION, 'N') = vi_Mark
           AND c.tab_symbol <> v_tab_symbol;
        --如果百分比不等于100 则资产负载类最大的报表代号赋值给v_tab_symbol1
        IF v_Perc <> 100 THEN
          SELECT MAX(c.tab_symbol)
            INTO v_tab_symbol1
            FROM DT_INV_CCBSGL P, DT_INV_CCPBSGL b, dt_inv_result C
           WHERE NVL(p.BS_ATION, 'N') = vi_Mark
             AND p.tab_type = vi_Kind
             AND p.com_id = v_com_id
             AND p.tab_symbol <> v_tab_symbol
             AND p.tab_symbol = c.tab_symbol
             AND p.com_id = c.com_id
             AND c.tab_type = vi_Kind
             AND c.com_id = v_com_id
             AND c.STARTDATE = vi_Beg_Date
             AND c.ENDDATE = vi_End_Date
             AND c.com_id = b.com_id(+)
             AND c.tab_symbol = b.tab_symbol(+)
             AND NVL(b.pla_type, 'A') <> 'B' --计算类别（A:会计科目，B:报表代号）
             AND c.RE_MONEY <> 0;
        
          UPDATE dt_inv_result
             SET RE_PET = NVL(RE_PET, 0) + (100 - v_perc)
           WHERE tab_type = vi_Kind
             AND com_id = v_com_id
             AND STARTDATE = vi_Beg_Date
             AND ENDDATE = vi_End_Date
             AND tab_symbol = v_tab_symbol1;
        
          FOR R IN PER LOOP
            UPDATE dt_inv_result
               SET RE_PET = r.percent
             WHERE tab_type = vi_Kind
               AND com_id = v_com_id
               AND STARTDATE = vi_Beg_Date
               AND ENDDATE = vi_End_Date
               AND tab_symbol = r.tab_symbol;
          END LOOP;
        END IF;
      END;
    END IF;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      IF vi_Mark = 'A' THEN
        RAISE_APPLICATION_ERROR(-20002, v_tab_symbol);
      ELSE
        RAISE_APPLICATION_ERROR(-20002, 'HHHHHEEEEE');
      END IF;
    WHEN OTHERS THEN
      RAISE;
  END Write_Percent;

  PROCEDURE PRO_WRITETO_FLEXRST --将查询出来的科目和借贷金额和操作金额
   IS
  BEGIN
    IF v_Cal_Mode = 'B' THEN
      --操作是减  将操作的金额变成负数
      v_OpenAmt := v_OpenAmt * (-1);
    END IF;
  
    UPDATE dt_inv_result --修改操作（操作金额）
       SET RE_MONEY = NVL(RE_MONEY, 0) + v_OpenAmt
     WHERE com_id = v_com_id
       AND tab_type = vi_Kind
       AND tab_symbol = v_tab_symbol
       AND STARTDATE = vi_Beg_Date
       AND ENDDATE = vi_End_Date;
    IF SQL%NOTFOUND THEN
      --如果上面的插入操作（dml）没有匹配行执行
    
      vn_Number := 0; --默认值
      LOOP
        -----这个轮循是哪里来的，猜测：赋值的变量是集合，所以这里做轮循
        BEGIN
          INSERT INTO dt_inv_result --将结果插入（操作金额）
            (re_key,
             re_id,
             tab_type,
             STARTDATE,
             ENDDATE,
             com_id,
             tab_symbol,
             RE_MONEY,
             RE_PET)
          VALUES
            (dbms_random.string('x', 32),
             vi_work_id,
             vi_Kind,
             vi_Beg_Date,
             vi_End_Date,
             v_com_id,
             v_tab_symbol,
             v_OpenAmt,
             0);
          vn_Number := 1; --插入一条后改变变量，后面跳出
        EXCEPTION
          --出现异常重新执行
          WHEN OTHERS THEN
            raise_application_error(-20003,
                                    substrb(sqlerrm, 1, 300) || v_OpenAmt ||
                                    v_tab_symbol); --记录错误信息包括金额和报表代号
            IF SUBSTR(SQLERRM, 1, 9) = 'ORA-00001' THEN
              --如何操作异常时0001重新轮循
            
              vn_Number := 0;
            END IF;
        END;
        EXIT WHEN vn_Number = 1; --根据条件跳出轮循
      END LOOP;
    END IF;
  
    SELECT RE_ID --根据条件查询列印id
      INTO v_Rst_id
      FROM dt_inv_result
     WHERE com_id = v_com_id
       AND tab_type = vi_Kind
       AND tab_symbol = v_tab_symbol
       AND STARTDATE = vi_Beg_Date
       AND ENDDATE = vi_End_Date;
    ---子表借贷金额操作
    IF vi_Detail = 'Y' THEN
      --列印明细
      UPDATE dt_inv_resDETAILS --修改借贷金额
         SET MONEY_D = MONEY_D + v_D_Amt, MONEY_C = MONEY_C + v_C_Amt
       WHERE RE_ID = v_Rst_Id
         AND SUBJECTSNAME = v_Acc_No;
      IF SQL%NOTFOUND THEN
        --如果上面修改没有符合行，就新增
        INSERT INTO dt_inv_resDETAILS
          (rd_key, RD_ID, RE_ID, SUBJECTSNAME, MONEY_D, MONEY_C)
        VALUES
          (dbms_random.string('x', 32),
           dbms_random.string('x', 32),
           v_Rst_id,
           v_Acc_No,
           v_D_Amt,
           v_C_Amt);
      END IF;
    END IF;
  END PRO_WRITETO_FLEXRST;
BEGIN
  NULL;
  v_com_id  := vi_com_id;
  v_open_ym := FUN_GET_OPENYM(vi_com_id, vi_beg_date);
  IF vi_kind = 'A' THEN
    --抓取月结档中的损益值为资产负债表的损益
    BEGIN
      SELECT SUM(NVL(GLMONEY, 0))
        INTO VI_SY_AMT
        FROM DT_INV_MCO
       WHERE COMPANYID = VI_COM_ID
         AND YEARMONTH BETWEEN v_open_ym AND substrb(vi_end_date, 1, 6);
    EXCEPTION
      WHEN OTHERS THEN
        VI_SY_AMT := 0;
    END;
  
  END IF;
  DELETE FROM DT_INV_RESDETAILS --资产负债表科目明细档 根据条件删除数据（如果存在的话需要先删除）
   WHERE RE_ID IN (SELECT RE_ID
                     FROM dt_inv_result
                    WHERE com_id = v_com_id
                      AND tab_type = vi_Kind
                      AND STARTDATE = vi_Beg_Date
                      AND ENDDATE = vi_End_Date);
  DELETE FROM dt_inv_result --资产负债损益表印表结果档  根据条件删除数据（如果存在的话需要先删除）
   WHERE com_id = v_com_id
     AND tab_type = vi_Kind
     AND STARTDATE = vi_Beg_Date
     AND ENDDATE = vi_End_Date;
  COMMIT;
  OPEN vcur_Prnm; --根据类别查找报表代号集合
  FETCH vcur_Prnm
    INTO v_tab_symbol; --（变量1）   将代号集合放到变量中（存入结果集）
  WHILE vcur_Prnm%FOUND LOOP
    --轮循parent结果集
    v_Amt      := 0;
    v_pla_type := 'A';
  
    OPEN vcur_Prnd; --根据（变量1）、v_pla_type为a（会计科目）的查询三个结果，方便插入到下面三个变量中（查询计算类别为会计科目的三个结果）
    FETCH vcur_Prnd
      INTO v_pla_type, v_Pre_Accn, v_Cal_Mode;
    WHILE vcur_Prnd%FOUND LOOP
      --轮循child
    
      SELECT COUNT(*) --根据公司，时间 和v_Pre_Accn（会计科目）查询总数（查询科目编号为vcur_Prnd结果集中v_Pre_Accn的条数）
        INTO v_count
        FROM DT_INV_DMCO sm, dtcsubjects sd
       WHERE sm.SUBJECTSID = sd.SUBJECTSID
         and sm.companyid = sd.companyid
         AND sm.YEARMONTH between substrb(vi_beg_date, 1, 6) AND
             substrb(vi_end_date, 1, 6)
         AND (sd.SUBJECTSNUMBERS LIKE RTRIM(LTRIM(v_Pre_Accn)) || '%')
         AND sm.COMPANYID = v_com_id;
    
      IF v_count > 0 THEN
        OPEN vcur_Acc FOR --根据是否列印明细字段分组查询借、贷和操作金额 轮循调用PRO_WRITETO_FLEXRST临时存储过程存入到结果主、次表中
          SELECT DECODE(vi_Detail, 'Y', AC.SUBJECTSNUMBERS, ' '), --参数是y取科目
                 sum(decode(vi_kind, 'A', ACLDMONEY, ACDMONEY)) d_amt, --A:记账期末借方金额 else:记账本期借方金额--（借）
                 sum(decode(vi_kind, 'A', ACLCMONEY, ACCMONEY)) c_amt, --A:记账期末贷方金额 else:记账本期贷方金额--（贷）
                 SUM(DECODE(ac.SUBJECTSDIRECTION,
                            'D', --方向为借   结果
                            decode(vi_kind,
                                   'A',
                                   ACLDMONEY - ACLCMONEY,
                                   ACDMONEY - ACCMONEY), --方向为借（资产类==期末借方金额-期末贷方金额  ，否则不是资产类= 本期借方金额-本期贷方金额）
                            decode(vi_kind,
                                   'A',
                                   ACLCMONEY - ACLDMONEY,
                                   ACCMONEY - ACDMONEY))) --方向不为借（贷） （资产类=期末贷方金额 -期末借方金额，否则不是资产类=本期贷方金额-本期借方金额）
            FROM DT_INV_DMCO sm, dtcsubjecTs ac --月结，科目
           WHERE (sm.SUBJECTSID = ac.SUBJECTSID)
             and sm.companyid = ac.companyid
             AND ((YEARMONTH = substrb(vi_end_date, 1, 6) AND vi_kind = 'A') OR --年月=参数，并且资产类(A) 或者             --substr 按照字符截取，substrb按照字节截取，比如：咋了德玛，截取1到3 ，前者咋了德，后者咋
                 (YEARMONTH BETWEEN SUBSTRB(VI_BEG_DATE, 1, 6) AND --年月在参数日期间内，并且不是资产类（A）
                 SUBSTRB(VI_END_DATE, 1, 6) AND VI_KIND <> 'A'))
             AND (AC.SUBJECTSNUMBERS LIKE RTRIM(LTRIM(v_Pre_Accn)) || '%') --左右去空格
             AND sm.COMPANYID = v_com_id
           GROUP BY DECODE(vi_Detail, 'Y', AC.SUBJECTSNUMBERS, ' ');
        FETCH vcur_Acc
          INTO v_Acc_No, v_D_Amt, v_C_Amt, v_OpenAmt;
        LOOP
          EXIT WHEN vcur_Acc%NOTFOUND;
          IF vi_Unit = 'Y' THEN
            --如何需要计算千分位就计算
            v_D_Amt   := v_D_Amt / 1000;
            v_C_Amt   := v_C_Amt / 1000;
            v_OpenAmt := v_OpenAmt / 1000;
          END IF;
        
          PRO_WRITETO_FLEXRST;
          FETCH vcur_Acc
            INTO v_Acc_No, v_D_Amt, v_C_Amt, v_OpenAmt;
        END LOOP;
        CLOSE vcur_Acc;
      ELSE
        v_OpenAmt := 0;
        v_D_Amt   := 0;
        v_c_amt   := 0;
      END IF;
      FETCH vcur_Prnd
        INTO v_pla_type, v_Pre_Accn, v_Cal_Mode;
    END LOOP;
  
    CLOSE vcur_Prnd;
    FETCH vcur_Prnm
      INTO v_tab_symbol;
  END LOOP;
  CLOSE vcur_Prnm;
  IF vi_Kind = 'A' AND vi_sy_amt <> 0 THEN
    --资产负债类 vi_sy_amt不为0
    IF vi_Unit = 'Y' THEN
      v_Amt := vi_sy_amt / 1000;
    ELSE
      v_Amt := vi_sy_amt;
    END IF;
  
    OPEN vcur_Mark; --根据报表类别和公司查询报表代号
    FETCH vcur_Mark
      INTO v_tab_symbol;
    LOOP
      EXIT WHEN vcur_Mark%NOTFOUND; --没有数据退出
      UPDATE dt_inv_result --设定设定结果
         SET RE_MONEY = NVL(RE_MONEY, 0) + v_Amt ---实际加上的是vi_sy_amt钱数？？？？
       WHERE tab_type = vi_Kind
         AND com_id = v_com_id
         AND startdate = vi_Beg_Date
         AND enddate = vi_End_Date
         AND tab_symbol = v_tab_symbol;
    
      IF SQL%NOTFOUND THEN
        --没有执行dml操作
        vn_Number := 0;
        LOOP
          BEGIN
            INSERT INTO dt_inv_result
              (re_key,
               RE_ID,
               tab_type,
               startdate,
               enddate,
               com_id,
               tab_symbol,
               RE_MONEY,
               RE_PET)
            VALUES
              (dbms_random.string('x', 32),
               vi_work_id,
               vi_Kind,
               vi_Beg_Date,
               vi_End_Date,
               v_com_id,
               v_tab_symbol,
               v_Amt,
               0);
            vn_Number := 1;
          EXCEPTION
            WHEN OTHERS THEN
              IF SUBSTR(SQLERRM, 1, 9) = 'ORA-00001' THEN
                vn_Number := 0;
              END IF;
          END;
          EXIT WHEN vn_Number = 1;
        END LOOP;
      END IF;
      FETCH vcur_Mark
        INTO v_tab_symbol;
    END LOOP;
    CLOSE vcur_Mark;
  END IF;
  -----------------------------------------------------------------
  /**
  根据计算类别v_pla_type为（报表代号B）的参数查询B对应数据的会计科目和计算方式
  轮循结果表，计算发生的金额，汇总到变量v_Amt中。。
  最后将结果金额累加到结构表中，如果不存在就新增加
  
  */
  --------------------------------------------------------------------
  OPEN vcur_Prnm; --根据类别查找报表代号集合
  FETCH vcur_Prnm
    INTO v_tab_symbol; --（变量1）   将代号集合放到变量中（存入结果集）
  LOOP
    EXIT WHEN vcur_Prnm%NOTFOUND; --轮循parent结果集
    v_Amt      := 0;
    v_pla_type := 'B';
    OPEN vcur_Prnd; --根据（变量1）、v_pla_type为b（报表代号）的查询三个结果，方便插入到下面三个变量中（查询计算类别为会计科目的三个结果）
    FETCH vcur_Prnd
      INTO v_pla_type, v_Pre_Accn, v_Cal_Mode;
    LOOP
      EXIT WHEN vcur_Prnd%NOTFOUND;
    
      DECLARE
      BEGIN
        SELECT RE_MONEY --查询结果表中涉及到报表代号类别数据的金额，
           INTO v_OpenAmt
          FROM dt_inv_result
         WHERE tab_type = vi_Kind
           AND com_id = v_com_id
           AND startdate = vi_Beg_Date
           AND enddate = vi_End_Date
           AND tab_symbol = v_Pre_Accn;
          
     EXCEPTION
        --异常处理
        WHEN OTHERS THEN
          v_OpenAmt:=0;
      END;
      IF v_Cal_Mode = 'A' THEN
            --对反生的金额进行累加
            v_Amt := v_Amt + v_OpenAmt;
          ELSE
            v_Amt := v_Amt - v_OPenAmt;
          END IF;
      FETCH vcur_Prnd
        INTO v_pla_type, v_Pre_Accn, v_Cal_Mode;
    END LOOP;
    CLOSE vcur_Prnd;
    UPDATE dt_inv_result --将上面轮循的结果金额累加到结果表中
       SET RE_MONEY = NVL(RE_MONEY, 0) + v_Amt
     WHERE tab_type = vi_Kind
       AND com_id = v_com_id
       AND startdate = vi_Beg_Date
       AND enddate = vi_End_Date
       AND tab_symbol = v_tab_symbol;
    IF SQL%NOTFOUND THEN
      --如果上面修改数据为空，那么是第一次应该新增。
      vn_Number := 0;
      LOOP
        BEGIN
          INSERT INTO dt_inv_result
            (re_key,
             RE_ID,
             tab_type,
             startdate,
             enddate,
             com_id,
             tab_symbol,
             RE_MONEY,
             RE_PET)
          VALUES
            (dbms_random.string('x', 32),
             vi_work_id,
             vi_Kind,
             vi_Beg_Date,
             vi_End_Date,
             v_com_id,
             v_tab_symbol,
             v_Amt,
             0);
          vn_Number := 1;
        EXCEPTION
          --如果违反唯一约束，重新插入
          WHEN OTHERS THEN
            IF SUBSTR(SQLERRM, 1, 9) = 'ORA-00001' THEN
              vn_Number := 0;
            END IF;
        END;
        EXIT WHEN vn_Number = 1;
      END LOOP;
    END IF;
    FETCH vcur_Prnm
      INTO v_tab_symbol;
  END LOOP;
  CLOSE vcur_Prnm;

  IF vi_Kind = 'A' THEN
    Write_Percent('A');
    Write_Percent('B');
    IF v_Amt_chk <> v_Amt_chk1 THEN
      raise_application_error(-20003, 'helllo error');
    END IF;
  ELSIF vi_Kind = 'B' THEN
    SELECT tab_symbol
      INTO v_tab_symbol
      FROM DT_INV_CCBSGL
     WHERE tab_type = vi_Kind
       AND BS_ATION = 'C' --资产负债损益表内容注记( A:资产,B:负债及股东权益,C:营业收入净值,D:本期纯益,E:其他)
       AND com_id = v_com_id;
    SELECT RE_MONEY
      INTO v_Amt
      FROM dt_inv_result
     WHERE tab_type = vi_Kind
       AND com_id = v_com_id
       AND startdate = vi_Beg_Date
       AND enddate = vi_End_Date
       AND tab_symbol = v_tab_symbol;
    IF v_Amt <> 0 THEN
      UPDATE dt_inv_result
         SET RE_PET = NVL(RE_MONEY, 0) / v_Amt * 100
       WHERE tab_type = vi_Kind
         AND com_id = v_com_id
         AND startdate = vi_Beg_Date
         AND enddate = vi_End_Date;
    END IF;
  
    IF substrb(vi_beg_date, 7, 2) = '01' and
       to_char(last_day(to_date(vi_beg_date, 'yyyymmdd')), 'YYYYMMDD') =
       vi_end_date THEN
      -- 抓取本期损益的值更新月结档中的损益金额。
      begin
        SELECT tab_symbol
          INTO VI_SY_AMT
          FROM DT_INV_CCBSGL
         WHERE tab_type = vi_Kind
           AND BS_ATION = 'D' --资产负债损益表内容注记( A:资产,B:负债及股东权益,C:营业收入净值,D:本期纯益,E:其他)
           AND com_id = v_com_id;
      exception
        when others then
          vi_sy_amt := 0;
      end;
      UPDATE dt_inv_mco
         SET GLMONEY = VI_SY_AMT
       WHERE COMPANYID = VI_COM_ID
         AND YEARMONTH = SUBSTRB(VI_BEG_DATE, 1, 6);
    END IF;
  END IF;
  COMMIT;
  
EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20002,
                            DBMS_UTILITY.FORMAT_ERROR_BACKTRACE ||
                            DBMS_UTILITY.FORMAT_ERROR_STACK);
END PRO_BC_FLEX_P;


/

