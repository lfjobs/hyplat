create PROCEDURE SYS_PROCESS_ERRMSG(PROC_NAME  VARCHAR2, --过程信息
                                               EXE_MSG    CLOB, --执行信息
                                               ERR_MSG    VARCHAR2, --错误信息
                                               BEGIN_TIME TIMESTAMP, --过程开始执行TIMESTAMP
                                               V_LOG      CLOB,
                                               RESULT     OUT VARCHAR2) AS
  /*用于处理异常信息,方便后续扩展
  1.执行信息中添加ERR_MSG
  2.执行记录日志过程
  3.错误信息赋值给返回结果RESULT
  调用方式：
  SYS_PROCESS_ERRMSG(V_PROC_NAME, V_EXE_MSG,V_ERR_MSG,V_BEGIN_TIME,RESULT);
  */

  V_EXE_MSG CLOB := EXE_MSG;
BEGIN
  RESULT := 'OK';
  --如果错误信息长度为0,返回OK
  IF LENGTH(ERR_MSG) = 0 OR ERR_MSG IS NULL THEN
    RETURN;
  END IF;
  DBMS_LOB.APPEND(V_EXE_MSG, ERR_MSG || CHR(10));
  SYS_SAVELOG(PROC_NAME, 'I', V_EXE_MSG, BEGIN_TIME, V_LOG);
  ROLLBACK;
  RESULT := ERR_MSG;
EXCEPTION
  WHEN OTHERS THEN
    RESULT := '处理异常信息发生错误!';
END;
/

