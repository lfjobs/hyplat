create PROCEDURE GET_ASSIGNN_FSHB IS
  --粉丝红包派发
  VI_ACCOUNT T_ESHOP_CUSCOM.ACCOUNT%TYPE;
  VI_NUM     DT_WFJ_JIFEN.WFJ_JIFEN_SCORE%TYPE;
  VI_SUMNUM  DT_WFJ_JIFEN.WFJ_JIFEN_SCORE%TYPE;
  VI_COM_ID  DTCOMPANY.COMPANYID%TYPE;
  VI_COUNT   NUMBER;

  --V_COUNTNUM NUMBER;
  V_JFNUM NUMBER;

  V_FSHB_SNAME DT_HR_STAFF.STAFFNAME%TYPE;
  V_FSHB_SCODE DT_HR_STAFF.STAFFCODE%TYPE;
  V_FSHB_SID   DT_HR_STAFF.STAFFID%TYPE;
  V_FSHB_SCCID T_ESHOP_CUSCOM.SCCID%TYPE;

  V_SNAME DT_HR_STAFF.STAFFNAME%TYPE;
  V_SCODE DT_HR_STAFF.STAFFCODE%TYPE;
  V_SID   DT_HR_STAFF.STAFFID%TYPE;
  V_SCCID T_ESHOP_CUSCOM.SCCID%TYPE;

  V_FSHB_COM_NAME DTCOMPANY.COMPANYNAME%TYPE;
  V_FSHB_G_SN     DTCOMPANY.GROUPCOMPANYSN%TYPE;
  V_FSHB_COM_ID   DTCOMPANY.COMPANYID%TYPE;

  V_COM_NAME DTCOMPANY.COMPANYNAME%TYPE;
  V_G_SN     DTCOMPANY.GROUPCOMPANYSN%TYPE;
  V_COM_ID   DTCOMPANY.COMPANYID%TYPE;

  V_XJHB DTGOODSBILLS.GOODSNAME%TYPE;

  V_GOODSID   DTGOODSBILLS.GOODSID%TYPE;
  V_TYPE      DTGOODSBILLS.TYPEID%TYPE;
  V_GOODSNAME DTGOODSBILLS.GOODSNAME%TYPE;

  V_RK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  V_CK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  V_CK_JUM    DTCASHIERBILLS.JOURNALNUM%TYPE;
  V_NEW_CA_ID DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  V_NEW_GB_ID DTGOODSBILLS.GOODSBILLSID%TYPE;

  V_S_GUIZE_ID DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE;
  V_Z_GUIZE_ID DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE;

  V_Z_JF_ID      DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE;
  V_S_JF_ID      DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE;
  V_NEW_JF_ID    DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE;
  V_NEW_GUIZE_ID DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE;

  V_JIFEN_DETAIL_NAME DT_WFJ_JIFEN_DETAIL.JIFEN_DETAIL_NAME%TYPE;

  CURSOR VCUR_GET_FS IS
    SELECT T.ACCOUNT, T.SCCID
      FROM T_ESHOP_CUSCOM T,
           DT_WFJ_JIFEN J,
           (SELECT D.WFJ_JIFEN_ID DID,
                   SUM(NVL(DECODE(G.WFJ_GUIZE_ID,
                                  'WfjGuize20151120R5HZ2UPCV50000000006',
                                  D.JIFEN_DETAIL_SCORE),
                           0)) DD1
              FROM DT_WFJ_JIFEN_DETAIL D, DT_WFJ_GUIZE G
             WHERE D.WFJ_GUIZE_ID = G.WFJ_GUIZE_ID
               AND D.STATUS IS NULL
               AND D.WFJ_JIFEN_ID IN
                   (SELECT J.WFJ_JIFEN_ID
                      FROM DT_WFJ_JIFEN J
                     WHERE J.SCCID IN
                           (SELECT T.SCCID
                              FROM T_ESHOP_CUSCOM T
                             WHERE T.CUSTYPE = 7
                               and T.SUPPERSCCID IS NOT NULL
                               and t.STAFFID is not null
                               AND T.ACCOUNT IS NOT NULL))
             GROUP BY D.WFJ_JIFEN_ID) DD
     WHERE T.SCCID = J.SCCID
       AND DD.DD1 <= 0
       AND J.WFJ_JIFEN_ID = DD.DID
    union all
    SELECT ACCOUNT, SCCID
      FROM T_ESHOP_CUSCOM out
     where not exists
     (SELECT SCCID FROM DT_WFJ_JIFEN where out.SCCID = SCCID)
       and SUPPERSCCID IS NOT NULL
       and STAFFID is not null
       AND ACCOUNT IS NOT NULL;

BEGIN

  V_XJHB := '微分金金币';
  --V_PRO_XJHB   := '金币';
  VI_COM_ID := 'company201009046vxdyzy4wg0000000025';

  SELECT COUNT(*)
    INTO VI_COUNT
    FROM (SELECT T.ACCOUNT, T.SCCID
            FROM T_ESHOP_CUSCOM T,
                 DT_WFJ_JIFEN J,
                 (SELECT D.WFJ_JIFEN_ID DID,
                         SUM(NVL(DECODE(G.WFJ_GUIZE_ID,
                                        'WfjGuize20151120R5HZ2UPCV50000000006',
                                        D.JIFEN_DETAIL_SCORE),
                                 0)) DD1
                    FROM DT_WFJ_JIFEN_DETAIL D, DT_WFJ_GUIZE G
                   WHERE D.WFJ_GUIZE_ID = G.WFJ_GUIZE_ID
                     AND D.STATUS IS NULL
                     AND D.WFJ_JIFEN_ID IN
                         (SELECT J.WFJ_JIFEN_ID
                            FROM DT_WFJ_JIFEN J
                           WHERE J.SCCID IN
                                 (SELECT T.SCCID
                                    FROM T_ESHOP_CUSCOM T
                                   WHERE T.CUSTYPE = 7
                                     and T.SUPPERSCCID IS NOT NULL
                                     and t.STAFFID is not null
                                     AND T.ACCOUNT IS NOT NULL))
                   GROUP BY D.WFJ_JIFEN_ID) DD
           WHERE T.SCCID = J.SCCID
             AND DD.DD1 <= 0
             AND J.WFJ_JIFEN_ID = DD.DID
          union all
          SELECT ACCOUNT, SCCID
            FROM T_ESHOP_CUSCOM out
           where not exists
           (SELECT SCCID FROM DT_WFJ_JIFEN where out.SCCID = SCCID)
             and SUPPERSCCID IS NOT NULL
             and STAFFID is not null
             AND ACCOUNT IS NOT NULL);

  SELECT J.WFJ_JIFEN_SCORE, S.STAFFNAME, S.STAFFCODE, S.STAFFID, t.sccid
    INTO VI_SUMNUM, V_FSHB_SNAME, V_FSHB_SCODE, V_FSHB_SID, V_FSHB_SCCID
    FROM DT_WFJ_JIFEN J, T_ESHOP_CUSCOM T, DT_HR_STAFF S
   WHERE J.SCCID = T.SCCID
     and S.STAFFID = T.STAFFID
     AND T.ACCOUNT = 'fshb';

  --查询平台公司名称、组织机构ID
  SELECT T.COMPANYID, T.PSEUDO_COMPANY_NAME, C.GROUPCOMPANYSN
    INTO V_FSHB_COM_ID, V_FSHB_COM_NAME, V_FSHB_G_SN
    FROM T_ESHOP_CUSCOM T
    LEFT JOIN DTCOMPANY C
      ON T.COMPANYID = C.COMPANYID
   WHERE T.COMPANYID IS NOT NULL
     AND ROWNUM = 1
   START WITH T.SCCID = V_FSHB_SCCID
  CONNECT BY PRIOR T.SUPPERSCCID = T.SCCID;

  SELECT G.WFJ_GUIZE_ID
    INTO V_Z_GUIZE_ID
    FROM DT_WFJ_GUIZE G
   WHERE G.WFJ_GUIZE_NAME = '粉丝红包(支)'
     AND G.COMPANY_ID = VI_COM_ID;

  SELECT G.WFJ_GUIZE_ID
    INTO V_S_GUIZE_ID
    FROM DT_WFJ_GUIZE G
   WHERE G.WFJ_GUIZE_NAME = '粉丝红包(收)'
     AND G.COMPANY_ID = VI_COM_ID;

  IF VI_SUMNUM > 0 THEN
  
    select trunc(VI_SUMNUM / (VI_COUNT + 1), 5) into VI_NUM from dual;
  
    IF VI_NUM > 0.01 THEN
      OPEN VCUR_GET_FS;
      FETCH VCUR_GET_FS
        INTO VI_ACCOUNT, V_SCCID;
      LOOP
        EXIT WHEN VCUR_GET_FS%NOTFOUND;
      
        BEGIN
        
          SELECT S.STAFFNAME, S.STAFFCODE, S.STAFFID, T.SCCID
            INTO V_SNAME, V_SCODE, V_SID, V_SCCID
            FROM T_ESHOP_CUSCOM T, DT_HR_STAFF S
           WHERE S.STAFFID = T.STAFFID
             AND T.ACCOUNT = VI_ACCOUNT
             AND T.SCCID = V_SCCID;
        
          SELECT T.PSEUDO_COMPANY_NAME, C.GROUPCOMPANYSN, T.COMPANYID
            INTO V_COM_NAME, V_G_SN, V_COM_ID
            FROM T_ESHOP_CUSCOM T
            LEFT JOIN DTCOMPANY C
              ON T.COMPANYID = C.COMPANYID
           WHERE T.COMPANYID IS NOT NULL
             AND ROWNUM = 1
           START WITH T.SCCID = V_SCCID
          CONNECT BY PRIOR T.SUPPERSCCID = T.SCCID;
        
        EXCEPTION
          WHEN OTHERS THEN
            dbms_output.put_line(V_SCCID);               
          goto cw;          
        END;
      
        --支
        UPDATE DT_WFJ_JIFEN
           SET WFJ_JIFEN_SCORE = NVL(WFJ_JIFEN_SCORE, 0) - VI_NUM
         WHERE STAFF_ID = V_FSHB_SID
           AND SCCID = V_FSHB_SCCID;
      
        SELECT W.WFJ_JIFEN_SCORE, W.WFJ_JIFEN_ID
          INTO V_JFNUM, V_Z_JF_ID
          FROM DT_WFJ_JIFEN W
         WHERE STAFF_ID = V_FSHB_SID
           AND SCCID = V_FSHB_SCCID;
      
        IF V_JFNUM > 0 THEN
        
          --收
          UPDATE DT_WFJ_JIFEN
             SET WFJ_JIFEN_SCORE = NVL(WFJ_JIFEN_SCORE, 0) + VI_NUM
           WHERE STAFF_ID = V_SID
             AND SCCID = V_SCCID;
        
          IF SQL%NOTFOUND THEN
          
            V_S_JF_ID := FUN_GET_ID('wfjjifen');
          
            INSERT INTO DT_WFJ_JIFEN
              (WFJ_JIFEN_KEY,
               WFJ_JIFEN_ID,
               STAFF_ID,
               WFJ_JIFEN_SCORE,
               WFJ_JIFEN_STATE,
               COMPANY_ID,
               SCCID)
            VALUES
              (DBMS_RANDOM.STRING('X', 32),
               V_S_JF_ID,
               V_SID,
               VI_NUM,
               0,
               V_COM_ID,
               V_SCCID);
          
          ELSE
          
            SELECT WFJ_JIFEN_ID
              INTO V_S_JF_ID
              FROM DT_WFJ_JIFEN
             WHERE STAFF_ID = V_SID
               AND SCCID = V_SCCID;
          
          END IF;
        
          --入库单
          V_RK_CA_ID := FUN_GET_ID('cashierbills');
          INSERT INTO DTCASHIERBILLS
            (CASHIERBILLSKEY,
             CASHIERBILLSID,
             COMPANYID,
             BILLSTYPE,
             JOURNALNUM,
             STAFFID,
             STAFFNAME,
             STAFFCODE,
             CASHIERDATE,
             STATUS,
             COMPANYNAME,
             PROID,
             PROJECTNAME, --项目名称
             GROUPCOMPANYSN,
             INPUTID,
             INPUTNAME,
             APPSTYLE,
             PRICESUB,
             CCOMPANYID,
             CCOMPANYNAME,
             STATUSBILL)
          VALUES
            (DBMS_RANDOM.STRING('X', 32),
             V_RK_CA_ID,
             V_COM_ID,
             '金币入库单',
             FUN_GET_BILL_ID(),
             V_SID,
             V_SNAME, --会员名称
             V_SCODE, --会员编号
             SYSDATE,
             '15',
             V_COM_NAME, --公司名称
             '002',
             '粉丝红包(收)',
             V_G_SN, --集团组织机构ID
             V_SID,
             V_SNAME,
             '08',
             TO_CHAR(VI_NUM / 100,
                     'FM999999999999999999999999999999990.999999999'),
             V_FSHB_COM_ID,
             V_FSHB_COM_NAME,
             '04');
        
          --平台金币出库单
          V_CK_CA_ID := FUN_GET_ID('cashierbills');
          V_CK_JUM   := FUN_GET_BILL_ID();
          INSERT INTO DTCASHIERBILLS
            (CASHIERBILLSKEY,
             CASHIERBILLSID,
             COMPANYID,
             BILLSTYPE,
             JOURNALNUM,
             STAFFID,
             STAFFNAME,
             STAFFCODE,
             CASHIERDATE,
             STATUS,
             COMPANYNAME,
             PROID,
             PROJECTNAME, --项目名称
             GROUPCOMPANYSN,
             INPUTID,
             INPUTNAME,
             APPSTYLE,
             PRICESUB,
             CCOMPANYID,
             CCOMPANYNAME,
             CONTACTUSERID,
             CTUSERNAME,
             STATUSBILL)
          VALUES
            (DBMS_RANDOM.STRING('X', 32),
             V_CK_CA_ID,
             V_FSHB_COM_ID,
             '金币出库单',
             V_CK_JUM,
             V_FSHB_SID,
             V_FSHB_SNAME, --会员名称
             V_FSHB_SCODE, --会员编号
             SYSDATE,
             '16',
             V_FSHB_COM_NAME, --公司名称
             '002',
             '粉丝红包(支)',
             V_G_SN, --集团组织机构ID
             V_SID,
             V_SNAME,
             '08',
             TO_CHAR(VI_NUM / 100,
                     'FM999999999999999999999999999999990.999999999'),
             V_COM_ID,
             V_COM_NAME,
             V_SID,
             V_SNAME,
             '04');
        
          --平台\用户金币出库\入库产品表
          FOR I IN 1 .. 2 LOOP
            V_GOODSID   := NULL;
            V_TYPE      := NULL;
            V_GOODSNAME := V_XJHB;
          
            IF I = 1 THEN
              --入库
              V_NEW_CA_ID         := V_RK_CA_ID;
              V_JIFEN_DETAIL_NAME := '粉丝红包(收)';
              V_NEW_JF_ID         := V_S_JF_ID;
              V_NEW_GUIZE_ID      := V_S_GUIZE_ID;
            ELSE
              --出库
              V_NEW_CA_ID         := V_CK_CA_ID;
              V_JIFEN_DETAIL_NAME := '粉丝红包(支)';
              V_NEW_JF_ID         := V_Z_JF_ID;
              V_NEW_GUIZE_ID      := V_Z_GUIZE_ID;
            END IF;
          
            V_NEW_GB_ID := FUN_GET_ID('goodsbills');
          
            INSERT INTO DTGOODSBILLS
              (GOODSBILLSKEY,
               GOODSBILLSID,
               --COMPANYID,
               CASHIERBILLSID,
               PAYTYPE, --付款方式
               QUANTITY,
               PRICE,
               MONEY,
               DEPOTNAME, --库房名称
               IDENTIFYINGCODE, --00
               GOODSNAME,
               KCSTATUS, --15：已入库
               GOODSTATUS) --状态00正常 01维修02报废
            VALUES
              (DBMS_RANDOM.STRING('X', 32),
               V_NEW_GB_ID,
               --COM_ID,
               V_NEW_CA_ID,
               '08',
               TO_CHAR(VI_NUM,
                       'FM999999999999999999999999999999990.999999999'),
               '0.01',
               TO_CHAR(VI_NUM / 100,
                       'FM999999999999999999999999999999990.999999999'),
               '销售库',
               '00',
               V_XJHB,
               '15',
               '00');
          
            INSERT INTO DT_WFJ_JIFEN_DETAIL
              (JIFEN_DETAIL_KEY,
               JIFEN_DETAIL_ID,
               JIFEN_DETAIL_NAME,
               JIFEN_DETAIL_DATE,
               JIFEN_DETAIL_SCORE,
               JIFEN_DETAIL_STATE,
               WFJ_GUIZE_ID,
               WFJ_JIFEN_ID,
               WFJ_CASH_ID,
               WFJ_GOOD_ID)
            VALUES
              (DBMS_RANDOM.STRING('X', 32),
               FUN_GET_ID('wfjjifendetail'),
               V_JIFEN_DETAIL_NAME,
               SYSDATE,
               TO_CHAR(VI_NUM,
                       'FM999999999999999999999999999999990.999999999'),
               1,
               V_NEW_GUIZE_ID, --规则外键
               V_NEW_JF_ID,
               V_NEW_CA_ID, --金币入库单据ID
               V_NEW_GB_ID);
          
          END LOOP;
        
        END IF;
       <<cw>>
       null;
        FETCH VCUR_GET_FS
          INTO VI_ACCOUNT, V_SCCID;
      END LOOP;
    
      CLOSE VCUR_GET_FS;
    END IF;
  END IF;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('SQL CODE:' || SQLCODE || CHR(10) || SQLERRM ||
                         CHR(10) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE());
  
END GET_ASSIGNN_FSHB;
/

