create view VIEW_DIMISSIONLOGBOOKSUMMARY as
select
st.companyName,
code.codevalue as scoresortname,
st.staffname,
st.categoryname,
st.staffcategoryid,
st.staffcode ,
jt.logbookid,
jt.companyid,
jt.organizationid,
jt.staffid,
jt.inputdate,
jt.startdate,
jt.joblocation,
jt.enddate,
jt.scoresort,
jt.jobcontent,
jt.bisect,
jt.attachment,
jt.supervisor,
jt.staffingmanage,
jt.manager,
jt.status,
jt.logostatus,
jt.todaydate,
jt.logbookkey,
st.postname
from dtlogbook jt
join view_disc st
on jt.staffid = st.staffid and st.companyid = jt.companyid
left join dtccode code on  code.codeid = jt.scoresort and code.companyid = jt.companyid


/

