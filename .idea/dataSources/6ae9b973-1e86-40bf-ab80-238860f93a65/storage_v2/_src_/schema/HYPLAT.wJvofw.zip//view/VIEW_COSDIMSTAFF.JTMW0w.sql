create view VIEW_COSDIMSTAFF as
select d.dimissionstaffkey , d.dimissionstaffid , d.companyid ,
co.companyname
,d.dimissiondate ,d.dimissioncause ,
 d.issued ,d.dimissionStatus , t.staffid,t.banknum,t.staffcode,t.recordcode,t.staffname,
 t.usednmae,t.sex,t.birthday,t.nativeplace,t.nationality,t.nation,t.staffidentitycard,
 t.staffaddress,t.reference,t.referencecode,t.referenceorganization,t.verifytime,t.staffdesc,
 t.health,t.marriage,t.culturaldegree,t.politicsstatus,t.photo,t.address,t.staffstatus
 from  dtcosdimissionstaff d join dt_hr_staff t
 on t.staffid = d.staffid
left join dtcompany co on  co.companyid = d.companyid


/

