create PROCEDURE PRO_BUYquan(VI_COM_ID    VARCHAR2, --平台公司ID
                                         VI_JOU_NUM   VARCHAR2, --订单编号
                                         VI_STAFF_ID  VARCHAR2, --付款人ID
                                         VI_PRO_SCCID VARCHAR2, --付款人账号ID
                                         VI_MONEY     VARCHAR2, --购买金币金额数
                                         VI_APPSTYLE  VARCHAR2, --支付方式
                                         VI_MERSEQ_ID VARCHAR2 --第三方交易号
                                         ) IS
  --处理现金券促销品
  V_DDID      DTGOODSBILLS.GOODSBILLSID%TYPE; --订单物品ID
  V_CK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --出库单据ID
  V_RK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --入库单据ID
  V_NEW_CA_ID DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  V_NEW_GB_ID DTGOODSBILLS.GOODSBILLSID%TYPE; --物品单据ID
  V_CA_SK_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --收款单据ID
  --V_CA_ZK_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --支款单据ID
  V_ZK_JUM DTCASHIERBILLS.JOURNALNUM%TYPE; --支款单编号

  V_GOOD_BI_ID DTGOODSBILLS.GOODSBILLSID%TYPE; --购买产品单据ID
  V_GUIZE_ID   DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE; --积分规则ID

  V_CASH_ID DTCASHIERBILLS.CASHIERBILLSID%TYPE; --订单单据ID

  --当前会员信息
  V_COM_ID    T_ESHOP_CUSCOM.COMPANYID%TYPE; --当前会员公司ID
  V_COM_NAME  DTCOMPANY.COMPANYNAME%TYPE; --公司名称
  V_G_SN      DTCOMPANY.GROUPCOMPANYSN%TYPE; --集团组织机构
  V_CNAME     DTCOMPANY.COMPANYNAME%TYPE; --平台公司名称
  V_GSN       DTCOMPANY.GROUPCOMPANYSN%TYPE; --平台集团组织机构
  V_NEW_JF_ID DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE; --新生成金币表ID

  V_S_NAME    DT_HR_STAFF.STAFFNAME%TYPE; --操作人姓名
  V_S_CODE    DT_HR_STAFF.STAFFCODE%TYPE; --操作人编号
  V_S_ACCOUNT T_ESHOP_CUSCOM.ACCOUNT%TYPE; --操作人微分金账号账号

  --仓库信息
  V_DEPOT_ID     DTDEPOTMANAGE.DEPOTID%TYPE; --仓库ID
  V_DEPOT_NAME   DTDEPOTMANAGE.DEPOTNAME%TYPE; --仓库名称
  V_DEPOT_ITEMID DTDEPOTMANAGE.ITEMID%TYPE; --仓库类别
  V_STOCK_TYPE   DT_INV_STOCKINVT.Type%TYPE; --库存盘点明细类型 00：入库 01：出库

  V_COUNTNUM NUMBER(5); --条数

  VII_MONEY NUMBER(20, 2); --积分数

BEGIN

  VII_MONEY := ROUND(TO_NUMBER(VI_MONEY) * 100, 2); --积分数

  --查询购买人信息
  SELECT S.STAFFNAME, S.STAFFCODE
    INTO V_S_NAME, V_S_CODE
    FROM DT_HR_STAFF S
   WHERE S.STAFFID = VI_STAFF_ID;

  SELECT T.ACCOUNT
    INTO V_S_ACCOUNT
    FROM T_ESHOP_CUSCOM T
   WHERE T.SCCID = VI_PRO_SCCID;

  --查询平台公司名称、组织机构id
  SELECT C.COMPANYNAME, C.GROUPCOMPANYSN
    INTO V_CNAME, V_GSN
    FROM DTCOMPANY C
   WHERE C.COMPANYID = VI_COM_ID;
  -----------------------------------------------购买积分人员订单收支款单--------------------------------------

  IF VI_MERSEQ_ID IS NOT NULL AND VI_MONEY IS NOT NULL THEN

    SELECT COUNT(*)
      INTO V_COUNTNUM
      FROM DT_INV_INVT I
     WHERE GOODSNAME = '现金券'
       AND COMPANYID = VI_COM_ID
       AND I.INVENQUANTITY >= VII_MONEY
       AND WAREHOUSENAME = '销售库';

    IF V_COUNTNUM > 0 THEN

      --资金仓库信息
      SELECT D.DEPOTNAME, D.DEPOTID, D.ITEMID
        INTO V_DEPOT_NAME, V_DEPOT_ID, V_DEPOT_ITEMID
        FROM DTDEPOTMANAGE D
       WHERE D.COMPANYID = VI_COM_ID
         AND D.DEPOTPID = '003'
         AND D.DEPOTNAME = '资金仓库';



      



      -------------------------------------生成积分出入库单据----------------------------------------



      --查询会员公司名称
      IF V_COM_ID IS NOT NULL THEN
        SELECT C.COMPANYNAME, C.GROUPCOMPANYSN
          INTO V_COM_NAME, V_G_SN
          FROM DTCOMPANY C
         WHERE COMPANYID = V_COM_ID;

      ELSE

        SELECT T.COMPANYID, T.PSEUDO_COMPANY_NAME, C.GROUPCOMPANYSN
          INTO V_COM_ID, V_COM_NAME, V_G_SN
          FROM T_ESHOP_CUSCOM T
          LEFT JOIN DTCOMPANY C
            ON T.COMPANYID = C.COMPANYID
         WHERE T.COMPANYID IS NOT NULL
           AND ROWNUM = 1
         START WITH T.SCCID = VI_PRO_SCCID
        CONNECT BY PRIOR T.SUPPERSCCID = T.SCCID;

      END IF;

      --用户积分入库单
      V_RK_CA_ID := FUN_GET_ID('cashiertally');

      INSERT INTO DTCASHIERBILLS
        (CASHIERBILLSKEY,
         CASHIERBILLSID,
         COMPANYID,
         BILLSTYPE,
         JOURNALNUM,
         STAFFID,
         STAFFNAME,
         STAFFCODE,
         CASHIERDATE,
         STATUS,
         COMPANYNAME,
         PROID,
         PROJECTNAME, --项目名称
         GROUPCOMPANYSN,
         INPUTID,
         INPUTNAME,
         APPSTYLE,
         PRICESUB,
         CCOMPANYID,
         CCOMPANYNAME,
         STATUSBILL,
         JNUMORDER)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         V_RK_CA_ID,
         V_COM_ID,
         '现金券入库单',
         FUN_GET_BILL_ID(),
         VI_STAFF_ID,
         V_S_NAME, --会员名称
         V_S_CODE, --会员编号
         SYSDATE,
         '15', --已入库
         V_COM_NAME, --公司名称
         '007',
         '赠送现金券',
         V_G_SN, --集团组织机构ID
         VI_STAFF_ID,
         V_S_NAME,
         '14',
         TO_CHAR(ROUND(VI_MONEY, 2),
                 'FM999999999999999999999999999999990.999999999'),
         VI_COM_ID,
         '北京天太世统科技有限责任公司',
         '04',
         VI_JOU_NUM);

      --添加关系表数据
      INSERT INTO DTRELATEDBILL
        (RBKEY, RBID, CASHID, CASHFID)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         FUN_GET_ID('relatedbill'),
         V_CASH_ID,
         V_RK_CA_ID);

      --平台积分出库单
      V_CK_CA_ID := FUN_GET_ID('cashiertally');
      V_ZK_JUM   := FUN_GET_BILL_ID();

      INSERT INTO DTCASHIERBILLS
        (CASHIERBILLSKEY,
         CASHIERBILLSID,
         COMPANYID,
         BILLSTYPE,
         JOURNALNUM,
         STAFFID,
         STAFFNAME,
         STAFFCODE,
         CASHIERDATE,
         STATUS,
         COMPANYNAME,
         PROID,
         PROJECTNAME, --项目名称
         GROUPCOMPANYSN,
         INPUTID,
         INPUTNAME,
         APPSTYLE,
         PRICESUB,
         CCOMPANYID,
         CCOMPANYNAME,
         STATUSBILL,
         JNUMORDER)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         V_CK_CA_ID,
         VI_COM_ID,
         '现金券出库单',
         V_ZK_JUM,
         VI_STAFF_ID,
         V_S_NAME, --会员名称
         V_S_CODE, --会员编号
         SYSDATE,
         '16', --已出库
         V_CNAME, --公司名称
         '007',
         '赠送现金券',
         V_GSN, --集团组织机构ID
         VI_STAFF_ID,
         V_S_NAME,
         '14',
         TO_CHAR(ROUND(VI_MONEY, 2),
                 'fm999999999999999999999999999999990.999999999'),
         V_COM_ID,
         V_COM_NAME,
         '04',
         VI_JOU_NUM);

      --平台\用户积分出库\入库产品表
      FOR I IN 1 .. 2 LOOP

        IF I = 1 THEN

          V_DEPOT_NAME := '销售库';
          V_DEPOT_ID   := NULL;
          V_NEW_CA_ID  := V_RK_CA_ID;
          V_STOCK_TYPE := '00';

        ELSE

          SELECT D.DEPOTNAME, D.DEPOTID, D.ITEMID
            INTO V_DEPOT_NAME, V_DEPOT_ID, V_DEPOT_ITEMID
            FROM DTDEPOTMANAGE D
           WHERE D.COMPANYID = VI_COM_ID
             AND D.DEPOTPID = '001'
             AND D.DEPOTNAME = '销售库';

          V_NEW_CA_ID  := V_CK_CA_ID;
          V_STOCK_TYPE := '01';

        END IF;

        V_NEW_GB_ID := FUN_GET_ID('goodsbills');

        SELECT COUNT(*)
          INTO V_COUNTNUM
          FROM DT_PRODUCTPACKAGING A
         WHERE A.COMPANYID = VI_COM_ID
           AND A.GOODSNAME = '现金券';
        IF V_COUNTNUM > 0 THEN
          INSERT INTO DTGOODSBILLS
            (GOODSBILLSKEY,
             GOODSBILLSID,
             CASHIERBILLSID,
             SUBJECTSID,
             SUBJECTSNAME,
             COSTTYPE, --费用类别
             PAYTYPE, --付款方式
             WEIGHT,
             GOODSID,
             QUANTITY,
             PRICE,
             MONEY,
             DEPOTID, --库房ID
             DEPOTNAME, --库房名称
             GOODSVARIABLEID, --单位
             IDENTIFYINGCODE, --00
             BATCHNUMBER, --批号
             GOODSNOMBER, --物品在账单中的排列序号
             GOODSNUM,
             GOODSNAME,
             TYPEID,
             STANDARD,
             KCSTATUS, --15：已入库
             GOODSTATUS, --状态00正常 01维修02报废
             PPID)
            SELECT DBMS_RANDOM.STRING('X', 32),
                   V_NEW_GB_ID,
                   V_NEW_CA_ID,
                   A.SUBJECTID,
                   A.SUBJECTNAME,
                   '', --费用类别
                   VI_APPSTYLE,
                   A.WEIGHT,
                   A.GOODSID,
                   TO_CHAR(VII_MONEY,
                           'fm999999999999999999999999999999990.999999999'),
                   '0.01',
                   TO_CHAR(ROUND(VI_MONEY, 2),
                           'fm999999999999999999999999999999990.999999999'),
                   V_DEPOT_ID,
                   V_DEPOT_NAME,
                   A.VARIABLEID,
                   '00',
                   '',
                   '1',
                   A.GOODSNUM,
                   A.GOODSNAME,
                   A.TYPE,
                   A.STANDARD,
                   '15',
                   '00',
                   A.PPID
              FROM DT_PRODUCTPACKAGING A
             WHERE A.COMPANYID = VI_COM_ID
               AND A.GOODSNAME = '现金券';

        ELSE
          INSERT INTO DTGOODSBILLS
            (GOODSBILLSKEY,
             GOODSBILLSID,
             CASHIERBILLSID,
             PAYTYPE, --付款方式
             QUANTITY,
             PRICE,
             MONEY,
             DEPOTNAME, --库房名称
             IDENTIFYINGCODE, --00
             GOODSNAME,
             KCSTATUS, --15：已入库
             GOODSTATUS) --状态00正常 01维修02报废
          VALUES
            (DBMS_RANDOM.STRING('X', 32),
             V_NEW_GB_ID,
             V_NEW_CA_ID,
             VI_APPSTYLE,
             TO_CHAR(VII_MONEY,
                     'fm999999999999999999999999999999990.999999999'),
             '0.01',
             TO_CHAR(ROUND(VI_MONEY, 2),
                     'fm999999999999999999999999999999990.999999999'),
             '销售库',
             '00',
             '现金券',
             '15',
             '00');

        END IF;

        if i = 2 then

          --平台积分库存盘点表

          INSERT INTO DT_INV_STOCKINVT
            (STOCKINVKEY,
             STOCKINVID,
             COMPANYID,
             GROUPCOMPANYSN,
             GOODSID,
             GOODSTYPE,
             GOODSNAME,
             INVENQUANTITY,
             TYPE,
             STAFFID,
             SUMMONEY,
             STAFFNAME,
             WAREHOUSE,
             WAREHOUSENAME,
             GOODSBILLSID)
            SELECT DBMS_RANDOM.STRING('X', 32),
                   FUN_GET_ID('stockinv'),
                   VI_COM_ID,
                   VI_COM_ID,
                   A.GOODSID,
                   A.TYPE,
                   A.GOODSNAME,
                   TO_CHAR(VII_MONEY,
                           'fm999999999999999999999999999999990.999999999'),
                   V_STOCK_TYPE,
                   VI_STAFF_ID,
                   TO_CHAR(ROUND(VI_MONEY, 2),
                           'fm999999999999999999999999999999990.999999999'),
                   V_S_NAME,
                   V_DEPOT_ID,
                   V_DEPOT_NAME,
                   V_NEW_GB_ID
              FROM DT_PRODUCTPACKAGING A
             WHERE A.COMPANYID = VI_COM_ID
               AND A.GOODSNAME = '现金券';
        end if;

      END LOOP;

      --进销存单据表
      INSERT INTO DT_INV_FB
        (FINANCIALBILLKEY,
         FINANCIALBILLID,
         GROUPCOMPANYSN,
         COMPANYID,
         BILLSTATUS,
         BILLSTYPE,
         JOURNALNUM,
         BILLSDATE,
         BILLSTAFFID,
         BILLSTAFFNAME,
         DEPOTID,
         DEPOTNAME,
         CASHIERBILLSID)
        SELECT DBMS_RANDOM.STRING('X', 32),
               FUN_GET_ID('FINANCIAL'),
               V_GSN,
               VI_COM_ID,
               '22',
               '现金券出库单',
               V_ZK_JUM,
               SYSDATE,
               A.INPUTID,
               A.INPUTNAME,
               V_DEPOT_ID,
               V_DEPOT_NAME,
               V_CK_CA_ID
          FROM DTCASHIERBILLS A
         WHERE A.CASHIERBILLSID = V_DDID;

      --添加关系表数据
      INSERT INTO DTRELATEDBILL
        (RBKEY, RBID, CASHID, CASHFID)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         FUN_GET_ID('relatedbill'),
         V_CASH_ID,
         V_CK_CA_ID);

      --添加关系表数据
      INSERT INTO DTRELATEDBILL
        (RBKEY, RBID, CASHID, CASHFID)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         FUN_GET_ID('relatedbill'),
         V_CK_CA_ID,
         V_RK_CA_ID);

      ----------------------------用户积分存储值改变------------------------------------

      SELECT G.WFJ_GUIZE_ID
        INTO V_GUIZE_ID
        FROM DT_WFJ_GUIZE G
       WHERE G.WFJ_GUIZE_NAME = '积分充值';

      --往会员积分表以及积分收支明细表里存值

      UPDATE DT_WFJ_XJQUAN
         SET XJQSCORE = ROUND(XJQSCORE + VII_MONEY, 2)
       WHERE SCCID = VI_PRO_SCCID;

      IF SQL%NOTFOUND THEN

        V_NEW_JF_ID := FUN_GET_ID('XJQUAN');
        INSERT INTO DT_WFJ_XJQUAN
          (xjqkey, xjqid, sccid, xjqscore)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           V_NEW_JF_ID,
           VI_PRO_SCCID,
           VII_MONEY);

      else

        SELECT xjqid
          INTO V_NEW_JF_ID
          FROM DT_WFJ_XJQUAN
         WHERE SCCID = VI_PRO_SCCID;

      END IF;

      --积分收支明细

      INSERT INTO DT_WFJ_XJQUAN_DETAIL
        (XJQDETAILKEY,
         XJQDETAILID,
         XJQDETAILNAME,
         XJQDETAILSCORE,
         XJQDETAILDATE,
         WFJGUIZEID,
         XJQID,
         WFJCASHID,
         WFJGOODID,
         PPID)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         FUN_GET_ID('XJQUANDETAIL'),
         '积分充值',
         VII_MONEY,
         SYSDATE,
         V_GUIZE_ID, --规则外键
         V_NEW_JF_ID,
         V_RK_CA_ID, --积分入库单据ID
         V_GOOD_BI_ID,
         '');

      ------------------------------平台积分库存改变-----------------------------------------

      --平台积分库存表
      UPDATE DT_INV_INVT
         SET INVENQUANTITY = TO_CHAR(TO_NUMBER(NVL(INVENQUANTITY, 0)) -
                                     VII_MONEY,
                                     'FM999999999999999999999999999999990.999999999'),
             SUMPRICE      = TO_CHAR(TO_NUMBER(NVL(SUMPRICE, 0)) - VI_MONEY,
                                     'FM999999999999999999999999999999990.999999999')
       WHERE GOODSNAME = '现金券'
         AND COMPANYID = VI_COM_ID
         AND WAREHOUSENAME = '销售库';

      COMMIT;

    END IF;

  END IF;
END PRO_BUYquan;
/

