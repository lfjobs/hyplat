create PROCEDURE          "PRO_TOL_INVVOU_YY" (VC_GROUPCN   IN VARCHAR2,
                                              VC_COMPANYID IN VARCHAR2,
                                              VC_YM        IN CHAR) IS
  vc_ym_s       char(6); --起时间
  vc_ym_e       char(6); --止时间
  v_amt         number(16, 2); --期间内的损益金额之和
  v_amt_d       number(16, 2);
  v_amt_c       number(16, 2);
  vc_subjectsid varchar2(50); --累积盈亏科目id
  vc_codeid     dtcompany.codeid%type; --币别（vc_codeid与数据库里面的dtcompany表的codeid字段的属性匹配）
BEGIN
  --ADD_MONTHS函数在输入日期上加上指定的几个月返回一个新的日期。如果给出一负数，返回值日期之前几个月日期。
  Select to_char(add_months(TO_DATE(vc_ym, 'YYYYMM'), -1), 'yyyymm')
    INTO vc_ym_e
    FROM dual;
  Begin
    SELECT STARTDATE
      Into vc_ym_s
      FROM DT_INV_FISPERIOD
     WHERE enddate = vc_ym_e
       AND companyid = vc_companyid;
  EXCEPTION
    When Others Then
      raise_application_error(-20002,
                              '请先确认当前公司是否有设定会计年度资料');
  END;

  BEGIN
    SELECT subjectsid, codeid
      INTO vc_subjectsid, vc_codeid
      FROM DTCOMPANY
     WHERE COMPANYID = VC_COMPANYID;
  EXCEPTION
    WHEN others THEN
      RAISE_APPLICATION_ERROR(-20002,
                              '当前公司别没有设定累积盈亏科目，请先设定！');
  End;

  BEGIN
    SELECT SUM(glmoney)
      INTO v_amt
      FROM DT_INV_MCO
     WHERE COMPANYID = VC_COMPANYID
       AND YEARMONTH BETWEEN vc_ym_s AND vc_ym_e;
  EXCEPTION
    When OTHERS then
      raise_application_error(-20002,
                              '请确认在该年月以前是否已进行或已经列印损益表！');
  END;
  --删除当前年结资料
  DELETE FROM DT_INV_DYCO
   WHERE COMPANYID = vc_companyid
     AND dyco_year = vc_ym;
  --删除下一个会计年度
  DELETE FROM DT_INV_FISPERIOD
   WHERE STARTDATE = vc_ym
     AND companyid = vc_companyid;

  INSERT INTO DT_INV_DYCO
    (DYCOID,
     DYCOKEY,
     GROUPCSN,
     COMPANYID,
     DYCO_YEAR,
     SUBJECTSID,
     SUBJECTSCODE,
     SUBJECTSNAME,
     CURRENCYID,
     CURRENCYNAME,
     ORGID,
     CLIENTID,
     RESERVED1,
     RESERVED2,
     SBDMONEY,
     SBCMONEY,
     SCDMONEY,
     SCCMONEY,
     SCLDMONEY,
     SCLCMONEY,
     ABDMONEY,
     ABCMONEY,
     ACDMONEY,
     ACCMONEY,
     ACLDMONEY,
     ACLCMONEY)
    SELECT dbms_random.string('x', 32),
           dbms_random.string('x', 32),
           GROUPCSN,
           A.COMPANYID,
           vc_ym,
           A.SUBJECTSID,
           a.subjectscode,
           A.SUBJECTSNAME,
           A.CURRENCYID,
           A.CURRENCYNAME,
           ORG_ID,
           CLIENTID,
           RESERVED1,
           RESERVED2,
           SUM(DECODE(YEARMONTH, vc_ym_s, SBDMONEY, 0)),
           SUM(DECODE(YEARMONTH, vc_ym_s, SBCMONEY, 0)),
           SUM(SCDMONEY),
           SUM(SCCMONEY),
           SUM(DECODE(YEARMONTH, vc_ym_e, SCLDMONEY, 0)),
           SUM(DECODE(YEARMONTH, vc_ym_e, SCLCMONEY, 0)),
           SUM(DECODE(YEARMONTH, vc_ym_s, ABDMONEY, 0)),
           SUM(DECODE(YEARMONTH, vc_ym_s, ABCMONEY, 0)),
           SUM(ACDMONEY),
           SUM(ACCMONEY),
           SUM(DECODE(YEARMONTH, vc_ym_e, ACLDMONEY, 0)),
           SUM(DECODE(YEARMONTH, vc_ym_e, ACLCMONEY, 0))
      FROM DT_INV_DMCO A, DTCSUBJECTS B
     WHERE GROUPCSN = VC_GROUPCN
       AND A.COMPANYID = VC_COMPANYID
       AND A.SUBJECTSID = B.SUBJECTSID
       AND A.COMPANYID = B.COMPANYID
       AND B.subjectsaccounts = 'Y'
       AND YEARMONTH BETWEEN vc_ym_s AND vc_ym_e
     GROUP BY GROUPCSN,
              A.COMPANYID,
              YEARMONTH,
              A.SUBJECTSID,
              A.SUBJECTSNAME,
              A.SUBJECTSCODE,
              A.CURRENCYID,
              A.CURRENCYNAME,
              ORG_ID,
              CLIENTID,
              RESERVED1,
              RESERVED2;

  IF v_amt > 0 THEN
    v_amt_d := 0;
    v_amt_c := v_amt;
  ELSE
    v_amt_d := abs(v_amt); --abs函数返回数值的绝对值
    v_amt_c := 0;
  End If;
  Begin
    UPDATE DT_INV_DYCO
       SET SCDMONEY  = SCDMONEY + v_amt_d,
           SCCMONEY  = SCCMONEY + v_amt_c,
           SCLDMONEY = SCLDMONEY + v_amt_d,
           SCLCMONEY = SCLCMONEY + v_amt_c,
           ACDMONEY  = ACDMONEY + v_amt_d,
           ACCMONEY  = ACCMONEY + v_amt_c,
           ACLDMONEY = ACLDMONEY + v_amt_d,
           ACLCMONEY = ACLCMONEY + v_amt_c
     WHERE companyid = vc_companyid
       And DYCO_YEAR = vc_ym
       And SUBJECTSID = vc_SUBJECTSID
       AND CURRENCYID = vc_codeid
       AND ORGID = ' '
       AND CLIENTID = ' '
       AND RESERVED1 = ' '
       AND RESERVED2 = ' '
       and rownum = 1;
    If SQL%NOTFOUND THEN
      INSERT INTO DT_INV_DYCO
        (DYCOID,
         DYCOKEY,
         GROUPCSN,
         COMPANYID,
         DYCO_YEAR,
         SUBJECTSID,         
         SUBJECTSNAME,
         CURRENCYID,
         CURRENCYNAME,
         ORGID,
         CLIENTID,
         RESERVED1,
         RESERVED2,
         SBDMONEY,
         SBCMONEY,
         SCDMONEY,
         SCCMONEY,
         SCLDMONEY,
         SCLCMONEY,
         ABDMONEY,
         ABCMONEY,
         ACDMONEY,
         ACCMONEY,
         ACLDMONEY,
         ACLCMONEY)
      VALUES
        (dbms_random.string('x', 32),
         dbms_random.string('x', 32),
         VC_GROUPCN,
         VC_COMPANYID,
         VC_YM,
         vc_subjectsid,
         ' ',
         vc_codeid,
         ' ',
         ' ',
         ' ',
         ' ',
         ' ',
         0,
         0,
         v_amt_d,
         v_amt_c,
         v_amt_d,
         v_amt_c,
         0,
         0,
         v_amt_d,
         v_amt_c,
         v_amt_d,
         v_amt_c);
    END IF;
  END;

  SELECT TO_CHAR(ADD_MONTHS(TO_DATE(VC_YM, 'YYYYMM'), 11), 'YYYYMM')
    INTO VC_YM_E
    FROM DUAL;

  INSERT INTO DT_INV_FISPERIOD
    (FPKEY,
     FPID,
     COMPANYID,
     COMPANYNAME,
     GROUPCOMPANYID,
     YEAR,
     STARTDATE,
     ENDDATE,
     CREATORID,
     CREATORNAME,
     UPDATORID,
     UPDATORNAME,
     CREATEDATE,
     UPDATEDATE)
    SELECT dbms_random.string('x', 32),
           dbms_random.string('x', 32),
           VC_COMPANYID,
           COMPANYNAME,
           VC_GROUPCN,
           substr(VC_YM_E, 1, 4),
           VC_YM,
           VC_YM_E,
           ' ',
           ' ',
           ' ',
           ' ',
           to_char(sysdate, 'yyyymmddhh24miss'),
           ' '
      FROM DT_INV_FISPERIOD
      where COMPANYID=VC_COMPANYID 
      and rownum = 1 
      order by year desc;

  COMMIT;
END;


/

