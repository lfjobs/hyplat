create view UTBOUNDORDERVO as
select c.cashierbillskey,
       c.cashierbillsid,
       c.staffID,
       c.staffName,
       c.cashierDate,
       c.journalnum,
       c.statusbill,
       c.billstype,
       c.companyid,
       c.organizationid,
       c.status,
       c.contactuserid,
       c.ctusername,
       c.reference,
       c.jnumorder,
       c.fiveclear,
       g.goodsbillsid,
       g.inventoryID,
       g.stockinvID,
       g.goodsnum,
       g.goodsname,
       g.standard,
       g.quantity,
       g.price,
       g.money,
       g.goodsid,
       g.typeid,
       g.ppid,
       g.profitmargin,
       g.profitamount,
       g.pretium,
       g.category,
       f.financialbillid,
       f.depotname,
       f.depotid,
       f.drdepotName,
       f.drdepotID,
       f.staffsid,
       f.staffsname,
       f.examinegoodsdate,
       f.purchasedate,
       f.subjectname,
       f.subjectid,
       f.logisticstype,
       g.proInspectionID
       from dtcashierbills c
       left join dt_inv_fb f
       on c.cashierbillsid=f.cashierbillsid
       left join dtgoodsbills g
       on c.cashierbillsid=g.cashierbillsid


/

