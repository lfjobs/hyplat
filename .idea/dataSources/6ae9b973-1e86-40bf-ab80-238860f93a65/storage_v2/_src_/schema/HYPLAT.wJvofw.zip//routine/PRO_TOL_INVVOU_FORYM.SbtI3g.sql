create PROCEDURE          "PRO_TOL_INVVOU_FORYM" (VC_GROUPCSN  IN VARCHAR2,
                                                 VC_COMPANYID IN VARCHAR2,
                                                 VC_YM        IN CHAR) IS
  v_Str    VARCHAR2(10000);
  VC_YM_ON CHAR(6);
  TYPE CUR IS REF CURSOR;
  VCUR CUR;
--%rowtype表示该类型为行数据类型，存储的是一行数据，一行数据里可以有多列，类似于表里的一行数据，也可以是游标里的一行数据
  I    DT_INV_DMCO%rowtype; --I存储的是DT_INV_DMCO表的一行数据
BEGIN
  --删除月结资料
  DELETE FROM DT_INV_DMCO
   WHERE COMPANYID = vc_companyid
     AND YEARMONTH = VC_YM;
  --先把凭证档中的资料汇总至月结档中
  INSERT INTO DT_INV_DMCO
    (DMCOKEY,
     DMCOID,
     GROUPCSN,
     COMPANYID,
     YEARMONTH,
     SUBJECTSID,
     SUBJECTSNAME,
     SUBJECTSCODE,
     CURRENCYID,
     CURRENCYNAME,
     ORG_ID,
     CLIENTID,
     RESERVED1,
     RESERVED2,
     SBDMONEY,
     SBCMONEY,
     SCDMONEY,
     SCCMONEY,
     SCLDMONEY,
     SCLCMONEY,
     ABDMONEY,
     ABCMONEY,
     ACDMONEY,
     ACCMONEY,
     ACLDMONEY,
     ACLCMONEY)
    SELECT dbms_random.string('x', 32),
           dbms_random.string('x', 32),
           VC_GROUPCSN,
           VC_COMPANYID,
           SUBSTRB(A.VOUCHERDATE, 1, 6),
           SUBJECTSID,
           SUBJECTSNAME,
           SUBJECTSCODE,
           CURRENCYID,
           CURRENCYNAME,
           ORG_ID,
           CLIENTID,
           RESERVED1,
           RESERVED2,
           0,
           0,
           SUM(DECODE(B.DIRECTION, 'D', STANDARDMONEY, 0)),
           SUM(DECODE(B.DIRECTION, 'C', STANDARDMONEY, 0)),
           SUM(DECODE(B.DIRECTION, 'D', STANDARDMONEY, 0)),
           SUM(DECODE(B.DIRECTION, 'C', STANDARDMONEY, 0)),
           0,
           0,
           SUM(DECODE(B.DIRECTION, 'D', ACCOUNTINGMONEY, 0)),
           SUM(DECODE(B.DIRECTION, 'C', ACCOUNTINGMONEY, 0)),
           SUM(DECODE(B.DIRECTION, 'D', ACCOUNTINGMONEY, 0)),
           SUM(DECODE(B.DIRECTION, 'C', ACCOUNTINGMONEY, 0))
      FROM DT_INV_VOUCHER A, DT_INV_VOUCHERS B
     WHERE A.VOUCHERID = B.VOUCHERID
       AND A.COMPANYID = VC_COMPANYID
       AND A.VOUCHERDATE LIKE VC_YM || '%'
     GROUP BY 0,
              VC_GROUPCSN,
              VC_COMPANYID,
              SUBSTRB(A.VOUCHERDATE, 1, 6),
              SUBJECTSID,
              SUBJECTSNAME,
              subjectscode,
              CURRENCYID,
              CURRENCYNAME,
              ORG_ID,
              CLIENTID,
              RESERVED1,
              RESERVED2;

  SELECT TO_CHAR(ADD_MONTHS(to_date(VC_YM, 'yyyymm'), -1), 'YYYYMM')
    INTO vc_ym_on
    FROM dual;

  IF FUN_GET_OPENYM(vc_companyid,vc_ym) <> vc_ym THEN
    --SUBSTRB(VC_YM, 5, 2) <> '01'    
    v_Str := 'SELECT GROUPCSN,COMPANYID,SUBJECTSID,SUBJECTSNAME,CURRENCYID,
     CURRENCYNAME,ORG_ID,CLIENTID,RESERVED1,RESERVED2,
     SCLDMONEY,SCLCMONEY,ACLDMONEY,ACLCMONEY
     FROM DT_INV_DMCO
    WHERE COMPANYID = ''' || VC_COMPANYID || '''
      AND YEARMONTH = ''' || VC_YM_ON || '''';
  ELSIF FUN_GET_OPENYM(vc_companyid,vc_ym) = vc_ym THEN
    --SUBSTRB(VC_YM, 5, 2) = '01'
    v_Str := 'SELECT GROUPCSN,COMPANYID,SUBJECTSID,SUBJECTSNAME,CURRENCYID,
     CURRENCYNAME,ORGID ORG_ID,CLIENTID,RESERVED1,RESERVED2,
     SCLDMONEY,SCLCMONEY,ACLDMONEY,ACLCMONEY
     FROM DT_INV_DYCO
    WHERE COMPANYID = ''' || VC_COMPANYID || '''
      AND DYCO_YEAR = ''' || VC_YM || '''';
  END IF;
  DBMS_OUTPUT.PUT_LINE(v_Str);
  OPEN vCur FOR v_Str;
  LOOP
    FETCH vCur
      INTO I.GROUPCSN,
           I.COMPANYID,
           I.SUBJECTSID,
           I.SUBJECTSNAME,
           I.CURRENCYID,
           I.CURRENCYNAME,
           I.ORG_ID,
           I.CLIENTID,
           I.RESERVED1,
           I.RESERVED2,
           I.SCLDMONEY,
           I.SCLCMONEY,
           I.ACLDMONEY,
           I.ACLCMONEY;
    EXIT WHEN vCur%NOTFOUND;
    --FOR I IN VCUR_GET_BEGINNING1 LOOP
    UPDATE DT_INV_DMCO
       SET SBDMONEY  = I.SCLDMONEY,
           SBCMONEY  = I.SCLCMONEY,
           SCLDMONEY = I.SCLDMONEY + SCDMONEY,
           SCLCMONEY = I.SCLCMONEY + SCCMONEY,
           ABDMONEY  = I.ACLDMONEY,
           ABCMONEY  = I.ACLCMONEY,
           ACLDMONEY = I.ACLDMONEY + ACDMONEY,
           ACLCMONEY = I.ACLCMONEY + ACCMONEY
     WHERE COMPANYID = I.COMPANYID
       AND GROUPCSN = I.GROUPCSN
       AND YEARMONTH = VC_YM
       AND SUBJECTSID = I.SUBJECTSID
       AND CURRENCYID = I.CURRENCYID
       AND CURRENCYNAME = I.CURRENCYNAME
       AND ORG_ID = I.ORG_ID
       AND CLIENTID = I.CLIENTID
       AND RESERVED1 = I.RESERVED1
       AND RESERVED2 = I.RESERVED2;
    IF SQL%NOTFOUND THEN
      INSERT INTO DT_INV_DMCO
        (DMCOID,
         DMCOKEY,
         GROUPCSN,
         COMPANYID,
         YEARMONTH,
         SUBJECTSID,
         subjectscode,
         SUBJECTSNAME,
         CURRENCYID,
         CURRENCYNAME,
         ORG_ID,
         CLIENTID,
         RESERVED1,
         RESERVED2,
         SBDMONEY,
         SBCMONEY,
         SCDMONEY,
         SCCMONEY,
         SCLDMONEY,
         SCLCMONEY,
         ABDMONEY,
         ABCMONEY,
         ACDMONEY,
         ACCMONEY,
         ACLDMONEY,
         ACLCMONEY)
      VALUES
        (dbms_random.string('x', 32),
           dbms_random.string('x', 32),
         I.GROUPCSN,
         I.COMPANYID,
         VC_YM,
         I.SUBJECTSID,
         I.subjectscode,
         I.SUBJECTSNAME,
         I.CURRENCYID,
         I.CURRENCYNAME,
         I.ORG_ID,
         I.CLIENTID,
         I.RESERVED1,
         I.RESERVED2,
         I.SCLDMONEY,
         I.SCLCMONEY,
         0,
         0,
         I.SCLDMONEY,
         I.SCLCMONEY,
         I.ACLDMONEY,
         I.ACLCMONEY,
         0,
         0,
         I.ACLDMONEY,
         I.ACLCMONEY);
    END IF;
  END LOOP;
  CLOSE vCur;

END;


/

