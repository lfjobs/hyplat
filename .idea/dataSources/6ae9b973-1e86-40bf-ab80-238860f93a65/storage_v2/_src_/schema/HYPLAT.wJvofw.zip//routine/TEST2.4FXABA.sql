create PROCEDURE "TEST2" IS

  pid DT_WFJ_BONUSPOINTS.BONUSPOINTSID%TYPE; --当前会员ID

  JIFEN_SCORE DT_WFJ_BONUSPOINTS.BONUSPOINTSCORE%TYPE; --当前会员金币量

  CURSOR c1 IS
    select d.a, b.bonuspointscore, b.bonuspointsid
      from (select sum(nvl(decode(wg.wfj_guize_calc,
                                  'A',
                                  wbd.bonuspointsdetailscore,
                                  'M',
                                  '-' || wbd.bonuspointsdetailscore),
                           0)) a,
                   wbd.bonuspointsid
              from dt_wfj_bonuspoints_detail wbd, dt_wfj_guize wg
             where wbd.wfjguizeid = wg.wfj_guize_id
             group by wbd.bonuspointsid) d,
           dt_wfj_bonuspoints b,
           t_eshop_cuscom t
     where d.bonuspointsid = b.bonuspointsid
       and b.sccid = t.sccid
          --and T.ACCOUNT = 'fshb'
       and d.a <> b.bonuspointscore
       and t.custype = '7'
     order by d.a;

BEGIN

  for v_pos in c1 loop
  
    JIFEN_SCORE := v_pos.a;
  
    pid := v_pos.bonuspointsid;
  
    update dt_wfj_bonuspoints b
       set b.bonuspointscore = JIFEN_SCORE
     where b.bonuspointsid = pid;
  
  end loop;

END test2;
/

