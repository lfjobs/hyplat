create view DT_INV_VOUCHERSVO as
select voucherskey,
  vouchersid,
  voucherid,
  subjectsid,
  cas_id,
  goodsid,
  subjectsname,
  reasonthing,
  goodsbillsid,
  direction,
  currencyname,
  currencyid,
  vouchersnum,
  exchangerate,
  mdannotation,
  standardmoney,
  accountingmoney,
  quantity,
  clientid,
  reserved1,
  reserved2,
  groupcsn
  from DT_INV_VOUCHERS


/

