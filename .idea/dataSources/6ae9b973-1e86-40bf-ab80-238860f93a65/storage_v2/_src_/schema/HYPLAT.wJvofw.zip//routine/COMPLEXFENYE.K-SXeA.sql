create PROCEDURE          "COMPLEXFENYE" (count_sql IN VARCHAR2,--表名
                                  select_sql IN VARCHAR2,--要查询的列
                                  PAGESIZE IN NUMBER, --每页显示记录数
                                  PAGENOW IN NUMBER, --页数
                                  MYROWS OUT NUMBER, --总记录数
                                  MYPAGECOUNT OUT NUMBER, --总页数
                                  P_CURSOR OUT TESTPACKAGE.TEST_CURSOR) IS --返回的记录集
--定义部分
--定义sql语句字符串
V_SQL VARCHAR2(4000);
--定义两个整数
V_BEGIN NUMBER := (PAGENOW - 1) * PAGESIZE + 1;
V_END NUMBER := PAGENOW * PAGESIZE;
BEGIN
--计算myrows和myPageCount
--组织一个sql语句
V_SQL := count_sql;
--执行sql,并把返回的值，赋给myrows；
EXECUTE ImMEDIATE V_SQL INTO MYROWS; --它解析并马上执行动态的SQL语句或非运行时创建的PL/SQL块.动态创建和执行SQL语句性能超前，
                                     --EXECUTE IMMEDIATE的目标在于减小企业费用并获得较高的性能，较之以前它相当容易编码.
                                     --尽管DBMS_SQL仍然可用，但是推荐使用EXECUTE IMMEDIATE,因为它获的收益在包之上。
--计算myPageCount
--if myrows%Pagesize=0 then 这样写是错的
IF MOD(MYROWS, PAGESIZE) = 0 THEN
  MYPAGECOUNT := MYROWS/PAGESIZE;
ELSE
  MYPAGECOUNT := MYROWS/PAGESIZE + 1;
END IF;
--执行部分
V_SQL := 'select * from (select dtable001.*, rownum rn from ('|| select_sql ||') dtable001 ) where rn between ' || V_BEGIN || ' and ' || V_END;
--把游标和sql关联
OPEN P_CURSOR FOR V_SQL;
--关闭游标
--CLOSE P_CURSOR; --暂时不知道什么时候关闭游标。。
END;


/

