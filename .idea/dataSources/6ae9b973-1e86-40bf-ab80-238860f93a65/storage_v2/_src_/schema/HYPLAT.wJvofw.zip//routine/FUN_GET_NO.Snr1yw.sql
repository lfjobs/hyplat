create FUNCTION          "FUN_GET_NO" (parm_cmyId in varchar2,parm_goodsId in varchar2) return number is
  tmp_no number;
begin
  tmp_no:=0;
   select t.goodsnumber into tmp_no from dtserialnumber t where t.companyid=parm_cmyId
                and t.goodsid=parm_goodsId and rownum<2;
  return(tmp_no);
end fun_get_no;


/

