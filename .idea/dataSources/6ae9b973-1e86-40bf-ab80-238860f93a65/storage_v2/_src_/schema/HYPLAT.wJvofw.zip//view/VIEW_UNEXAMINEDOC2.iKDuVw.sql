create view VIEW_UNEXAMINEDOC2 as
select d.key,
d.docId,
d.title,
d.theme,
d.doctype,
d.emergencytype,
d.startvalidity,
d.endvalidity,
d.partya,
d.partyb,
d.partyaname,
d.partybname,
d.partyastaff,
d.partybstaff,
d.staffidentitycarda,
d.staffidentitycardb,
d.partyastaffnames,
d.partybstaffnames,
d.updatetime,
 d.Docnum as docnum,
t.assignee_,
d.frommember,
ss.staffname fromname,
d.module,
e.activityname_,
d.deptidofsubscriber,
d.drafterid,
s.staffname as draftername,
d.organizationid,
d.companyid,
d.status,
d.companyidofsubscriber
from jbpm4_task t,
jbpm4_variable v,
jbpm4_execution e,
dt_oa_document d,dt_hr_staff s,dt_hr_staff ss
where t.execution_=e.dbid_
and e.dbid_=v.execution_
and v.string_value_=d.docId
and v.key_='docId' and s.staffid = d.drafterid
and ss.staffid=d.frommember
/

