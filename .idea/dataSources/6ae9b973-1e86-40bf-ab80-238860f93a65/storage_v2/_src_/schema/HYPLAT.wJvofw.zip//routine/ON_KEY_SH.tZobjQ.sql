create procedure on_Key_sh(cashierBills_ID varchar2 --订单编号
                                      ) IS
  new_ca_id    DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  depot_ID     varchar2(50);
  depot_Name   varchar2(50);
  good_id      varchar2(50);
  inventory_ID varchar2(50);
  pro_sh_count number;

  money_jisuan number;

  cursor var_get_goods is
    select * from dtgoodsbills where cashierbillsid = cashierBills_ID;

begin

  select count(*)
    into pro_sh_count
    from dtcashierbills c
   where c.cashierbillsid = cashierBills_ID
     and c.fkstatus = '02';

  if pro_sh_count > 0 then
    select count(*)
      into pro_sh_count
      from dtcashierbills ccc
     where ccc.billstype = '销售出库单'
       and ccc.jnumorder =
           (select cc.journalnum
              from dtcashierbills cc
             where cc.cashierbillsid = cashierBills_ID);
  
    IF PRO_SH_COUNT <= 0 THEN
    
      SELECT COUNT(*)
        INTO PRO_SH_COUNT
        FROM DT_DELIVERY D
       WHERE D.CASHIERBILLSID = CASHIERBILLS_ID;
    
    END IF;
  
    IF PRO_SH_COUNT > 0 THEN
    
      NEW_CA_ID := FUN_GET_ID('cashierTally'); --获取单据Id
      --添加收货单单据
      INSERT INTO DTCONSIGNEESHEET
        (CSKEY,
         CSID,
         ORDERCODE,
         CASHIERBILLSID,
         CONSIGNECODE,
         COMPANYID,
         COMPANYNAME,
         ORDERDATE,
         USERID,
         USERNAME,
         USERACCOUNT,
         VIPTYPE,
         CONSIGNEENAME,
         CONSIGNEETEL,
         POSTCODE,
         CONSIGNEEADDRESS,
         CONSIGNNEDATE,
         SENDERNAME,
         SENDERTEL,
         SENDDATE,
         SENDADDRESS,
         STATE)
        SELECT DBMS_RANDOM.STRING('x', 32),
               FUN_GET_ID('ConsigneeSheet'),
               C.JOURNALNUM,
               C.CASHIERBILLSID,
               FUN_GET_BILL_ID(),
               C.COMPANYID,
               C.COMPANYNAME,
               SYSDATE,
               S.STAFFID,
               S.STAFFNAME,
               E.ACCOUNT,
               E.CUSTYPE,
               OS.RECEIVENAME,
               OS.RECEIVETEL,
               OS.RECEIVECODE,
               OS.RECEIVEADDRESS,
               SYSDATE,
               OS.SENDNAME,
               OS.SENDTEL,
               C.CASHIERDATE,
               OS.SENDADDRESS,
               '00'
          FROM DTCASHIERBILLS C
          LEFT JOIN DT_ORDER_BILL_ADD OS
            ON C.CASHIERBILLSID = OS.OA_BILL_ID
          LEFT JOIN T_ESHOP_CUSCOM E
            ON E.SCCID = OS.OA_SCCID
          LEFT JOIN DT_HR_STAFF S
            ON E.STAFFID = S.STAFFID
         WHERE C.CASHIERBILLSID = CASHIERBILLS_ID
           AND C.FKSTATUS = '02';
    
      SELECT COUNT(*)
        INTO PRO_SH_COUNT
        FROM DTCASHIERBILLS CCC
       WHERE CCC.BILLSTYPE = '物流入库单'
         AND CCC.JNUMORDER =
             (SELECT CC.JOURNALNUM
                FROM DTCASHIERBILLS CC
               WHERE CC.CASHIERBILLSID = CASHIERBILLS_ID);
    
      /*IF PRO_SH_COUNT <= 0 THEN
        SELECT COUNT(*)
          INTO PRO_SH_COUNT
          FROM DT_SEND_BILL SEND
         WHERE SEND.STATUS = '02'
           AND SEND.CASHIERBILLSID = CASHIERBILLS_ID;
      END IF;*/
    
      --判断时候后物流入库单 有则是普通发货，没有则是虚拟发货
      if pro_sh_count > 0 then
      
        --添加一条对应的物流出库单
        insert into dtcashierbills
          (cashierbillskey,
           cashierbillsid,
           companyid,
           contactuserid,
           billstype,
           journalnum,
           staffid,
           cashierdate,
           status,
           companyname,
           ctusername,
           staffname,
           reference,
           staffidentitycard,
           referencecode,
           referenceorganization,
           staffaddress,
           groupcompanysn,
           inputid,
           inputname,
           remark,
           wlcomname,
           jnumorder)
          select dbms_random.string('x', 32),
                 new_ca_id,
                 c.companyid,
                 c.contactuserid,
                 '物流出库单',
                 FUN_GET_BILL_ID(),
                 c.staffid,
                 sysdate,
                 '16',
                 c.companyname,
                 c.ctusername,
                 c.staffname,
                 c.reference,
                 c.staffidentitycard,
                 c.referencecode,
                 c.referenceorganization,
                 c.staffaddress,
                 c.groupcompanysn,
                 c.inputid,
                 c.inputname,
                 c.remark,
                 c.wlcomname,
                 c.journalnum
            from dtcashierbills c
           where c.cashierbillsid = cashierBills_ID
             and c.fkstatus = '02';
      
        --添加一条进销存单据
        select depotID, depotName
          into depot_ID, depot_Name
          from dtDepotManage
         where companyID = 'company201009046vxdyzy4wg0000000025'
           and depotPID = '001'
           and depotName = '物流库'
           and depotState = '00';
      
        INSERT INTO dt_inv_fb
          (financialbillkey,
           financialbillid,
           companyid,
           billstatus,
           billstype,
           journalnum,
           billsdate,
           billstaffid,
           billstaffname,
           cashierbillsid,
           depotID,
           depotName,
           drdepotID,
           drdepotName)
          SELECT dbms_random.string('x', 32),
                 fun_get_id('financial'),
                 'company201009046vxdyzy4wg0000000025',
                 '16',
                 status,
                 journalnum,
                 sysdate,
                 a.inputid,
                 a.inputname,
                 new_ca_id,
                 depot_ID,
                 depot_Name,
                 a.staffId,
                 a.staffName
            FROM dtcashierbills a
           WHERE a.companyid = 'company201009046vxdyzy4wg0000000025'
             and a.cashierbillsid = cashierBills_ID
             and a.fkstatus = '02';
      
        --添加物品单据
        for goods in var_get_goods loop
          good_id := fun_get_id('GoodsBills');
          if INSTR(goods.money, '-', 1) = 0 then
          
            money_jisuan := ROUND(TO_NUMBER(goods.money), 2);
          else
            money_jisuan := ROUND(TO_NUMBER(substr(goods.money,
                                                   0,
                                                   INSTR(goods.money, '-', 1) - 1)),
                                  2);
          
          end if;
          select inventoryId
            into inventory_ID
            from dt_inv_invt i
           where i.goodsid = goods.goodsid
             and i.productId = goods.ppid
             and i.warehouse = depot_ID;
        
          insert into dtgoodsbills
            (goodsBillsKey,
             goodsBillsID,
             companyID,
             inventoryID,
             cashierBillsID,
             goodsID,
             typeID,
             goodsNum,
             goodsName,
             standard,
             price,
             quantity,
             money,
             depotID,
             depotName,
             logistics)
          values
            (dbms_random.string('x', 32),
             good_id,
             goods.companyID,
             inventory_ID,
             new_ca_id,
             goods.goodsID,
             goods.typeID,
             goods.goodsNum,
             goods.goodsName,
             goods.standard,
             goods.price,
             goods.quantity,
             money_jisuan,
             goods.depotID,
             goods.depotName,
             goods.logistics);
        
          --添加库存盘点
          insert into dt_inv_stockinvt
            (stockinvKey,
             stockinvID,
             companyID,
             goodsBillsId,
             goodsID,
             goodsType,
             goodsName,
             invenQuantity,
             summoney,
             intime,
             type,
             warehouse,
             warehouseName)
          values
            (dbms_random.string('x', 32),
             fun_get_id('stockInv'),
             goods.companyid,
             goods.goodsbillsid,
             goods.goodsid,
             goods.typeid,
             goods.goodsname,
             goods.quantity,
             money_jisuan,
             sysdate,
             '01',
             goods.depotID,
             goods.depotName);
        
          --修改库存表数量和总金额
        
          update dt_inv_invt i
             set i.invenQuantity = i.invenQuantity - goods.quantity,
                 i.sumPrice      = i.sumPrice - money_jisuan
           where i.goodsid = goods.goodsid
             and i.warehouse = depot_ID
             and i.companyid = 'company201009046vxdyzy4wg0000000025';
        
          --修改物品序号中的状态、关联的单据
          /*update dtgoodsnum n
             set n.status = '07', n.goodsBillsID = good_id
           where n.goodsid = goods.goodsid
             and n.companyid = 'company201009046vxdyzy4wg0000000025'
             and n.goodsbillsid = goods.goodsbillsid
             and n.cashierbillsid = inventory_ID;*/
        end loop;
      end if;
      update dtcashierbills c
         set c.fkstatus = '03'
       where c.cashierbillsid = cashierbills_ID
         and c.fkstatus = '02';
    
      update dt_order_bill_add o
         set o.shdate = sysdate
       where o.oa_bill_id = cashierbills_ID;
    
      commit;
    end if;
  end if;
end on_key_sh;
/

