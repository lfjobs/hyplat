create view VIEW_UNEXAMINEDOC as
select d.key,
d.docId,
d.title,
d.theme,
d.doctype,
d.emergencytype,
d.startvalidity,
d.endvalidity,
d.partya,
d.partyb,
d.partyaname,
d.partybname,
d.partyastaff,
d.partybstaff,
d.staffidentitycarda,
d.staffidentitycardb,
d.partyastaffnames,
d.partybstaffnames,
d.updatetime,
com.companyidentifier || d.Docnum as docnum,
t.assignee_,
d.frommember,
ss.staffname fromname,
d.module,
e.activityname_,
d.deptidofsubscriber,
d.drafterid,
s.staffname as draftername,
d.organizationid,
org.organizationname as deptNameOfDraft,
d.companyid,com.companyname as companyName,
d.status,
d.companyidofsubscriber
from jbpm4_task t inner join  jbpm4_execution e on t.execution_=e.dbid_ inner join jbpm4_variable v on e.dbid_=v.execution_

inner join dt_oa_document d on v.string_value_=d.docId inner join dt_hr_staff s on  s.staffid = d.drafterid left join dt_hr_staff ss on ss.staffid=d.frommember left join dtCOrganization org on org.organizationid = d.organizationid left join dtCompany com on  com.companyid = d.companyid
/

