create PROCEDURE          "DELETE_DOCUMENTS_CASH" IS
  var_goodsBillsID      varchar2(50);
  var_QUANTITY          varchar2(20);

  cursor var_get_goods is
   select g.*
     from dtcashierbills cr
     left join dtgoodsbills g on cr.cashierbillsid = g.cashierbillsid
    where cr.trade_no in
          ('0020160331132521', '0020160331132457', '0020160331132442',
           '0020160331132407', '0020160331132353', '0020160331132345',
           '0020160331132328', '0020160331132316', '0020160331132311',
           '0020160331132247', '0020160329151436', '0020160329151418',
           '0020160329151222', '0020160329151116', '0020160329150701',
           '0020160329150230', '0020160329144105', '0020160329124759',
           '0020160328130911', '0020160328102945', '0020160328102359',
           '0020160328102009', '0020160328101922', '0020160326171911',
           '0020160326170648', '0020160414155557', '0020160414152221',
           '0020160414151857', '0020160414150621', '0020160414145547',
           '0020160414145203', '0020160414145148', '0020160414145044',
           '0020160414144414', '0020160414144404', '0020160414144353',
           '0020160414144339', '0020160414130744', '0020160401180109',
           '0020160401134634')
      and cr.projectname = '供应商成本'
      and (cr.billstype = '支款单' or cr.billstype = '收款单')
      and g.goodsname != '手续费';
      
     cursor var_get_cashier is
   select cr.cashierbillsid
     from dtcashierbills cr
    where cr.trade_no in
          ('0020160331132521', '0020160331132457', '0020160331132442',
           '0020160331132407', '0020160331132353', '0020160331132345',
           '0020160331132328', '0020160331132316', '0020160331132311',
           '0020160331132247', '0020160329151436', '0020160329151418',
           '0020160329151222', '0020160329151116', '0020160329150701',
           '0020160329150230', '0020160329144105', '0020160329124759',
           '0020160328130911', '0020160328102945', '0020160328102359',
           '0020160328102009', '0020160328101922', '0020160326171911',
           '0020160326170648', '0020160414155557', '0020160414152221',
           '0020160414151857', '0020160414150621', '0020160414145547',
           '0020160414145203', '0020160414145148', '0020160414145044',
           '0020160414144414', '0020160414144404', '0020160414144353',
           '0020160414144339', '0020160414130744', '0020160401180109',
           '0020160401134634')
      and cr.projectname = '供应商成本'
      and (cr.billstype = '支款单' or cr.billstype = '收款单');

begin
 for goods in var_get_goods loop
     var_goodsBillsID:=goods.goodsbillsid;
     var_QUANTITY:=goods.money;
    delete dt_inv_stockinvt where goodsbillsID=var_goodsBillsID and type='01';
    UPDATE DT_INV_INVT
       SET INVENQUANTITY = INVENQUANTITY + var_QUANTITY,
           SUMPRICE      = SUMPRICE + var_QUANTITY
     WHERE GOODSNAME = '银行存款'
       AND COMPANYID = 'company201009046vxdyzy4wg0000000025'
       AND SOURCE = '销售盈利'
       AND WAREHOUSE =
           (SELECT DEPOTID
              FROM DTDEPOTMANAGE
             WHERE COMPANYID = 'company201009046vxdyzy4wg0000000025'
               AND DEPOTPID = '003'
               AND DEPOTNAME = '资金仓库');
  end loop;
  for c in var_get_cashier loop
  delete dtcashierbills where cashierbillsid=c.cashierbillsid;
  delete dtgoodsbills where cashierbillsid=c.cashierbillsid;
  end loop;
commit;
end Delete_documents_cash;


/

