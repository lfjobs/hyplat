create view VIEW_APP as
select
(select co.companyName from Dtcompany co where co.companyid = jt.companyid)companyName,
st.staffname,
st.staffcode ,jt."APPRAISALKEY",jt."APPRAISALID",jt."PAYSCALEID",jt."COMPANYID",jt."STAFFID",jt."CHECKPERSON",jt."WORKDATESATURATION",jt."APPRAISALDATE",jt."RESPONSIBILITY1",jt."RESPONSIBILITY2",jt."RESPONSIBILITY3",jt."ACHIEVEMENTS1",jt."ACHIEVEMENTS2",jt."ACHIEVEMENTS3",jt."TASK1",jt."TASK2",jt."TASK3",jt."ABILITY1",jt."ABILITY2",jt."ABILITY3",jt."MANNER1",jt."MANNER2",jt."MANNER3",jt."STATUS"
 from dt_hr_staff st,
dt_hr_staff_appraisal jt
where jt.staffid = st.staffid
and exists
(select s.staffid from view_sc s where jt.companyid = s.companyid and jt.staffid = s.staffid)
order by jt.companyID ,JT.APPRAISALDATE ,ST.STAFFID DESC


/

