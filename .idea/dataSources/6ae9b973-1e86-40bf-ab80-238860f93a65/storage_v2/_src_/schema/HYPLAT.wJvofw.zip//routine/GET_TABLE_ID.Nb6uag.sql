create FUNCTION          "GET_TABLE_ID" (
         type in varchar2, --类型  1:根据实体类名称取得SID
         tableName in varchar2
      ) return varchar2 --定义返回的数据类型
  is
  random varchar2(1000);
  sel varchar2(10);
  TYPE T_PASSKEY IS Varray(32) of varchar(1);
  PASSKEY T_PASSKEY := T_PASSKEY('2','3','4','5','6','7','8','9','Q','W','E','R','T','Y','U','I','P',
                    'A','S','D','F','G','H','J','K','Z','X','C','V','B','N','M');
  begin
    if type='1' then
       for i in 1..10 loop
           random:=random||PASSKEY(to_number(get_Generate_Su('2','1','32')));
       end loop;
       select to_char(sysdate,'yyyymmdd') into sel from dual;
       random:=tableName||sel||random||get_Generate_Su('3','0','10');
       return random;
    end if;
  end;


/

