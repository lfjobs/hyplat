create FUNCTION          "FUN_GET_BILL_ID" 

  RETURN varchar2 AS
  vc_id  varchar2(50);
  vc_yms char(6);
BEGIN
  vc_id :=TO_CHAR (SYSDATE,'yyyymmddhhmiss')||trunc(dbms_random.value(0,10000));
  RETURN vc_id;
END;


/

