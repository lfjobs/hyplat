create PROCEDURE "TEST1" IS

  v_supid VARCHAR2(50);
  v_accid VARCHAR2(50);

  CURSOR VCUR_GET_accon IS
    select ta.supperaccid from t_eshop_accon ta;
BEGIN

  --delete t_eshop_accon;
  insert into t_eshop_accon
    (acckey,
     accid,
     sccid,
     staffid,
     custype,
     companyid,
     pseudo_company_name,
     state,
     teccdate,
     supperaccid)
    select sys_guid(),
           FUN_GET_ID('accid'),
           t.sccid,
           t.staffid,
           t.custype,
           t.companyid,
           t.pseudo_company_name,
           t.state,
           t.teccdate,
           t.suppersccid
      from t_eshop_cuscom t;

  OPEN VCUR_GET_accon;

  FETCH VCUR_GET_accon
    INTO v_supid;
  LOOP
    EXIT WHEN VCUR_GET_accon%NOTFOUND;
  
    if v_supid is not null then
    
      select ta.accid
        into v_accid
        from t_eshop_accon ta
       where ta.sccid = v_supid;
    
      update t_eshop_accon
         set supperaccid = v_accid
       where supperaccid = v_supid;
    end if;
  
    FETCH VCUR_GET_accon
      INTO v_supid;
  
  END LOOP;

  CLOSE VCUR_GET_accon;

END TEST1;
/

