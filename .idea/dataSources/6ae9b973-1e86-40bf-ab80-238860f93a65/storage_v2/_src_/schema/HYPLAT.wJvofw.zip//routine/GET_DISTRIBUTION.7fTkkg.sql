create PROCEDURE GET_DISTRIBUTION(VI_COM_ID1   VARCHAR2, --公司ID
                                             VI_CASH_ID   VARCHAR2, --单据ID
                                             VI_STAFF_ID  VARCHAR2, --操作人ID
                                             VI_MONEY     VARCHAR2, --供应商成本
                                             PRO_CASH_JUM OUT VARCHAR --库存金币不够的单据ID
                                             ) IS
  --分配金币（供应商成本、各个会员的佣金、处理赠品VIP客户）
  DDID      DTGOODSBILLS.GOODSBILLSID%TYPE; --订单物品ID
  CK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --出库单据ID
  RK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --入库单据ID
  NEW_CA_ID DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  NEW_GB_ID DTGOODSBILLS.GOODSBILLSID%TYPE; --物品单据ID
  CK_JUM    DTCASHIERBILLS.JOURNALNUM%TYPE; --出库单编号
  SUM_MONEY DTCASHIERBILLS.PRICESUB%TYPE; --订单总金额

  G_PPID     DTGOODSBILLS.PPID%TYPE; --产品ID
  G_NAME     DTGOODSBILLS.GOODSNAME%TYPE; --产品名称
  GOOD_QUAN  DTGOODSBILLS.QUANTITY%TYPE; --购买物品数量
  COST_PRICE DT_PRO_SETUP.RE_PRICE%TYPE; --零售价
  JB_PRICE   DT_PRO_SETUP.EF_PRICE%TYPE; --出厂价
  GOOD_BI_ID DTGOODSBILLS.GOODSBILLSID%TYPE; --购买产品单据ID
  GUIZE_ID   DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE; --积分规则ID

  --会员类别
  WFJ_NUM   T_ESHOP_CUSCOM.CUSTYPE%TYPE; --分金币会员类别序号
  JOU_NUM   DTCASHIERBILLS.JOURNALNUM%TYPE; --订单号
  PRO_MB_ID DT_MEMBER_BACKUP.MB_ID%TYPE; --订单中可以分配会员

  --当前会员信息
  PRO_STAFF_ID T_ESHOP_CUSCOM.STAFFID%TYPE; --当前会员ID
  PRO_SCCID    t_eshop_cuscom.sccid%type; --当前会员账号id
  COM_ID       T_ESHOP_CUSCOM.COMPANYID%TYPE; --当前会员公司ID
  COM_NAME     DTCOMPANY.COMPANYNAME%TYPE; --公司名称
  G_SN         DTCOMPANY.GROUPCOMPANYSN%TYPE; --集团组织机构
  JIFEN_SCORE  DT_WFJ_JIFEN_DETAIL.JIFEN_DETAIL_SCORE%TYPE; --当前会员金币量
  NEW_JF_ID    DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE; --新生成金币表ID
  S_NAME1      DT_HR_STAFF.STAFFNAME%TYPE; --当前会员姓名
  S_CODE1      DT_HR_STAFF.STAFFCODE%TYPE; --当前会员编号

  S_NAME DT_HR_STAFF.STAFFNAME%TYPE; --操作人姓名
  S_CODE DT_HR_STAFF.STAFFCODE%TYPE; --操作人编号

  --仓库信息
  DEPOT_ID     DTDEPOTMANAGE.DEPOTID%TYPE; --仓库ID
  DEPOT_NAME   DTDEPOTMANAGE.DEPOTNAME%TYPE; --仓库名称
  DEPOT_ITEMID DTDEPOTMANAGE.ITEMID%TYPE; --仓库类别
  KCL          DT_INV_INVT.INVENQUANTITY%TYPE; --金币库存量

  COUNTNUM   NUMBER(5); --条数
  BFB_NUM    VARCHAR2(5); --佣金比例
  SCORE      DT_WFJ_JIFEN_DETAIL.JIFEN_DETAIL_SCORE%TYPE; --按照比例计算出的数值
  SUM2_MONEY DT_WFJ_JIFEN_DETAIL.JIFEN_DETAIL_SCORE%TYPE; --计算传值

  good_money dtgoodsbills.money%type; --物品总金额

  VI_COM_ID VARCHAR2(50); --公司ID

  jiangpin VARCHAR2(50);

  CURSOR VCUR_GET_GOODS IS
    SELECT G.PPID,
           G.QUANTITY,
           G.GOODSBILLSID,
           G.GOODSNAME,
           g.premiums,
           G.COSTMONEY,
           G.PRICE,
           g.money
      FROM DTCASHIERBILLS CB, DTGOODSBILLS G
     WHERE CB.CASHIERBILLSID = G.CASHIERBILLSID
       AND CB.CASHIERBILLSID = VI_CASH_ID
       AND CB.FKSTATUS = '03'
       AND CB.STATUSBILL = '04'
       and cb.status != '99';

  CURSOR VCUR_GET_USER IS
    SELECT T.STAFF_ID, T.COM_ID, T.M_TYPE, T.MB_ID, T.JB_BL, T.M_ID
      FROM DT_MEMBER_BACKUP T
     WHERE T.CASH_ID = VI_CASH_ID
       and t.status is null
     ORDER BY T.M_TYPE DESC;

BEGIN
  SELECT COUNT(*)
    INTO COUNTNUM
    FROM DTCASHIERBILLS C
   WHERE C.CASHIERBILLSID = VI_CASH_ID
     AND C.FKSTATUS = '03'
     and c.status != '99';
  IF COUNTNUM > 0 THEN
  
    VI_COM_ID := 'company201009046vxdyzy4wg0000000025';
    --查询当前操作人信息
    SELECT S.STAFFNAME, S.STAFFCODE
      INTO S_NAME, S_CODE
      FROM DT_HR_STAFF S
     WHERE S.STAFFID = VI_STAFF_ID;
  
    SELECT CB.JOURNALNUM,
           C.COMPANYID, --供货商ID
           C.COMPANYNAME, --供货商名称
           C.GROUPCOMPANYSN, --供货商集团标识
           T.STAFFID,
           T.SCCID,
           S.STAFFCODE,
           S.STAFFNAME,
           CB.PRICESUB
      INTO JOU_NUM,
           COM_ID,
           COM_NAME,
           G_SN,
           PRO_STAFF_ID,
           PRO_SCCID,
           S_CODE1,
           S_NAME1,
           SUM_MONEY
      FROM DTCASHIERBILLS CB, DTCOMPANY C, T_ESHOP_CUSCOM T, DT_HR_STAFF S
     WHERE CB.COMPANYID = T.COMPANYID
       AND S.STAFFID = T.STAFFID
       AND CB.COMPANYID = C.COMPANYID
       AND CB.CASHIERBILLSID = VI_CASH_ID;
  
    --判断库存里金币是否够
    SELECT COUNT(*)
      INTO COUNTNUM
      FROM DT_INV_INVT I
     WHERE GOODSNAME = '微分金金币'
       AND COMPANYID = VI_COM_ID
       AND I.INVENQUANTITY >= SUM_MONEY
       AND SOURCE = '用户兑换';
  
    IF COUNTNUM <= 0 THEN
      SELECT COUNT(*)
        INTO COUNTNUM
        FROM DT_INV_INVT I
       WHERE GOODSNAME = '微分金金币'
         AND COMPANYID = VI_COM_ID
         AND I.INVENQUANTITY >= SUM_MONEY
         AND SOURCE = '批量生产';
    END IF;
  
    IF COUNTNUM <= 0 THEN
      PRO_CASH_JUM := JOU_NUM;
      GOTO HERE;
    END IF;
  
    select count(*)
      into COUNTNUM
      from dtcashierbills c
     where c.jnumorder = JOU_NUM
       and c.billstype = '收款单'
       and c.status != '99';
    if COUNTNUM = 1 then
    
      SELECT count(*)
        into COUNTNUM
        FROM DT_MEMBER_BACKUP T
       WHERE T.CASH_ID = VI_CASH_ID
         and t.status is null
         and T.JB_BL is null;
    
      if COUNTNUM <= 0 then
        SELECT count(*)
          into COUNTNUM
          FROM DT_MEMBER_BACKUP T
         WHERE T.CASH_ID = VI_CASH_ID
           and t.status is null;
        if COUNTNUM <= 8 then
          -----------------------------------------------供应商金币入库平台金币出库--------------------------------------
          IF VI_MONEY is not null THEN
            --供应商金币入库单
            RK_CA_ID := FUN_GET_ID('cashierTally');
            INSERT INTO DTCASHIERBILLS
              (CASHIERBILLSKEY,
               CASHIERBILLSID,
               COMPANYID,
               BILLSTYPE,
               JOURNALNUM,
               STAFFID,
               STAFFNAME,
               STAFFCODE,
               CASHIERDATE,
               STATUS,
               COMPANYNAME,
               PROID,
               PROJECTNAME, --项目名称
               GROUPCOMPANYSN,
               INPUTID,
               INPUTNAME,
               APPSTYLE,
               PRICESUB,
               CCOMPANYID,
               CCOMPANYNAME,
               STATUSBILL,
               JNUMORDER)
            VALUES
              (DBMS_RANDOM.STRING('x', 32),
               RK_CA_ID,
               COM_ID,
               '金币入库单',
               FUN_GET_BILL_ID(),
               PRO_STAFF_ID,
               S_NAME1, --会员名称
               S_CODE1, --会员编号
               SYSDATE,
               '15',
               COM_NAME, --公司名称
               '002',
               '供应商成本金币分配',
               G_SN, --集团组织机构ID
               VI_STAFF_ID,
               S_NAME,
               '08',
               TO_CHAR(VI_MONEY / 100,
                       'fm999999999999999999999999999999990.999999999'),
               'company201009046vxdyzy4wg0000000025',
               '北京天太世统科技有限责任公司',
               '04',
               JOU_NUM);
          
            --添加关系表数据
            INSERT INTO DTRELATEDBILL
              (RBKEY, RBID, CASHID, CASHFID)
            VALUES
              (DBMS_RANDOM.STRING('x', 32),
               FUN_GET_ID('relatedbill'),
               VI_CASH_ID,
               RK_CA_ID);
          
            --平台金币出库单
            CK_CA_ID := FUN_GET_ID('cashierTally');
            CK_JUM   := FUN_GET_BILL_ID();
            INSERT INTO DTCASHIERBILLS
              (CASHIERBILLSKEY,
               CASHIERBILLSID,
               COMPANYID,
               BILLSTYPE,
               JOURNALNUM,
               STAFFID,
               STAFFNAME,
               STAFFCODE,
               CASHIERDATE,
               STATUS,
               COMPANYNAME,
               PROID,
               PROJECTNAME, --项目名称
               GROUPCOMPANYSN,
               INPUTID,
               INPUTNAME,
               APPSTYLE,
               PRICESUB,
               CCOMPANYID,
               CCOMPANYNAME,
               CONTACTUSERID,
               CTUSERNAME,
               STATUSBILL,
               JNUMORDER)
            VALUES
              (DBMS_RANDOM.STRING('x', 32),
               CK_CA_ID,
               'company201009046vxdyzy4wg0000000025',
               '金币出库单',
               CK_JUM,
               VI_STAFF_ID,
               S_NAME, --会员名称
               S_CODE, --会员编号
               SYSDATE,
               '16',
               '北京天太世统科技有限责任公司', --公司名称
               '002',
               '供应商成本金币分配',
               'groupcompany20120523G3VR9PXHZD0000000021', --集团组织机构id
               VI_STAFF_ID,
               S_NAME,
               '08',
               TO_CHAR(VI_MONEY / 100,
                       'fm999999999999999999999999999999990.999999999'),
               COM_ID,
               COM_NAME,
               PRO_STAFF_ID,
               S_NAME1,
               '04',
               JOU_NUM);
          
            --平台\用户金币出库\入库产品表
            FOR I IN 1 .. 2 LOOP
              IF I = 1 THEN
                --入库
                DEPOT_NAME := '销售库';
                DEPOT_ID   := NULL;
                NEW_CA_ID  := RK_CA_ID;
              ELSE
                --出库
                SELECT D.DEPOTNAME, D.DEPOTID, D.ITEMID
                  INTO DEPOT_NAME, DEPOT_ID, DEPOT_ITEMID
                  FROM DTDEPOTMANAGE D
                 WHERE D.COMPANYID = VI_COM_ID
                   AND D.DEPOTPID = '001'
                   AND D.DEPOTNAME = '销售库';
              
                NEW_CA_ID := CK_CA_ID;
              END IF;
            
              NEW_GB_ID := FUN_GET_ID('goodsbills');
              SELECT COUNT(*)
                INTO COUNTNUM
                FROM DT_PRODUCTPACKAGING A
               WHERE A.COMPANYID = 'company201009046vxdyzy4wg0000000025'
                 AND A.GOODSNAME = '微分金金币';
            
              IF I = 2 THEN
                --平台金币库存盘点表
                IF COUNTNUM > 0 THEN
                  INSERT INTO DT_INV_STOCKINVT
                    (STOCKINVKEY,
                     STOCKINVID,
                     COMPANYID,
                     GROUPCOMPANYSN,
                     GOODSID,
                     GOODSTYPE,
                     GOODSNAME,
                     INVENQUANTITY,
                     TYPE,
                     STAFFID,
                     STAFFNAME,
                     WAREHOUSE,
                     WAREHOUSENAME,
                     GOODSBILLSID)
                    SELECT DBMS_RANDOM.STRING('x', 32),
                           FUN_GET_ID('stockInv'),
                           VI_COM_ID,
                           'groupcompany20120523G3VR9PXHZD0000000021',
                           A.GOODSID,
                           A.TYPE,
                           A.GOODSNAME,
                           TO_CHAR(VI_MONEY,
                                   'fm999999999999999999999999999999990.999999999'),
                           '01',
                           VI_STAFF_ID,
                           S_NAME,
                           DEPOT_ID,
                           DEPOT_NAME,
                           NEW_GB_ID
                      FROM DT_PRODUCTPACKAGING A
                     WHERE A.COMPANYID =
                           'company201009046vxdyzy4wg0000000025'
                       AND A.GOODSNAME = '微分金金币';
                
                ELSE
                  INSERT INTO DT_INV_STOCKINVT
                    (STOCKINVKEY,
                     STOCKINVID,
                     COMPANYID,
                     GROUPCOMPANYSN,
                     GOODSNAME,
                     INVENQUANTITY,
                     TYPE,
                     STAFFID,
                     STAFFNAME,
                     WAREHOUSE,
                     WAREHOUSENAME,
                     GOODSBILLSID)
                  VALUES
                    (DBMS_RANDOM.STRING('x', 32),
                     FUN_GET_ID('stockInv'),
                     VI_COM_ID,
                     'groupcompany20120523G3VR9PXHZD0000000021',
                     '微分金金币',
                     TO_CHAR(VI_MONEY,
                             'fm999999999999999999999999999999990.999999999'),
                     '01',
                     VI_STAFF_ID,
                     S_NAME,
                     DEPOT_ID,
                     DEPOT_NAME,
                     NEW_GB_ID);
                END IF;
              
              END IF;
            
              IF COUNTNUM > 0 THEN
                INSERT INTO DTGOODSBILLS
                  (GOODSBILLSKEY,
                   GOODSBILLSID,
                   --COMPANYID,
                   CASHIERBILLSID,
                   SUBJECTSID,
                   SUBJECTSNAME,
                   COSTTYPE, --费用类别
                   PAYTYPE, --付款方式
                   WEIGHT,
                   GOODSID,
                   QUANTITY,
                   PRICE,
                   MONEY,
                   DEPOTID, --库房ID
                   DEPOTNAME, --库房名称
                   GOODSVARIABLEID, --单位
                   IDENTIFYINGCODE, --00
                   BATCHNUMBER, --批号
                   GOODSNOMBER, --物品在账单中的排列序号
                   GOODSNUM,
                   GOODSNAME,
                   TYPEID,
                   STANDARD,
                   KCSTATUS, --16：已出库
                   GOODSTATUS, --状态00正常 01维修02报废
                   PPID)
                  SELECT DBMS_RANDOM.STRING('x', 32),
                         NEW_GB_ID,
                         --COMPANYID,
                         NEW_CA_ID,
                         A.SUBJECTID,
                         A.SUBJECTNAME,
                         '', --费用类别
                         '08',
                         A.WEIGHT,
                         A.GOODSID,
                         TO_CHAR(VI_MONEY,
                                 'fm999999999999999999999999999999990.999999999'),
                         '0.01',
                         TO_CHAR(VI_MONEY / 100,
                                 'fm999999999999999999999999999999990.999999999'),
                         DEPOT_ID,
                         DEPOT_NAME,
                         A.VARIABLEID,
                         '00',
                         '',
                         '1',
                         A.GOODSNUM,
                         A.GOODSNAME,
                         A.TYPE,
                         A.STANDARD,
                         '15',
                         '00',
                         A.PPID
                    FROM DT_PRODUCTPACKAGING A
                   WHERE A.COMPANYID =
                         'company201009046vxdyzy4wg0000000025'
                     and A.GOODSNAME = '微分金金币';
              
              ELSE
                INSERT INTO DTGOODSBILLS
                  (GOODSBILLSKEY,
                   GOODSBILLSID,
                   --COMPANYID,
                   CASHIERBILLSID,
                   PAYTYPE, --付款方式
                   QUANTITY,
                   PRICE,
                   MONEY,
                   DEPOTNAME, --库房名称
                   IDENTIFYINGCODE, --00
                   GOODSNAME,
                   KCSTATUS, --15：已入库
                   GOODSTATUS) --状态00正常 01维修02报废
                VALUES
                  (DBMS_RANDOM.STRING('x', 32),
                   NEW_GB_ID,
                   --com_id,
                   NEW_CA_ID,
                   '08',
                   TO_CHAR(VI_MONEY,
                           'fm999999999999999999999999999999990.999999999'),
                   '0.01',
                   TO_CHAR(VI_MONEY / 100,
                           'fm999999999999999999999999999999990.999999999'),
                   '销售库',
                   '00',
                   '微分金金币',
                   '15',
                   '00');
              END IF;
            
            END LOOP;
            --进销存单据表
            INSERT INTO DT_INV_FB
              (FINANCIALBILLKEY,
               FINANCIALBILLID,
               GROUPCOMPANYSN,
               COMPANYID,
               BILLSTATUS,
               BILLSTYPE,
               JOURNALNUM,
               BILLSDATE,
               BILLSTAFFID,
               BILLSTAFFNAME,
               DEPOTID,
               DEPOTNAME,
               CASHIERBILLSID)
            VALUES
              (DBMS_RANDOM.STRING('x', 32),
               FUN_GET_ID('financial'),
               'groupcompany20120523G3VR9PXHZD0000000021',
               'company201009046vxdyzy4wg0000000025',
               '22',
               '金币出库单',
               CK_JUM,
               SYSDATE,
               '',
               '系统生成',
               DEPOT_ID,
               DEPOT_NAME,
               CK_CA_ID);
          
            --添加关系表数据
            INSERT INTO DTRELATEDBILL
              (RBKEY, RBID, CASHID, CASHFID)
            VALUES
              (DBMS_RANDOM.STRING('x', 32),
               FUN_GET_ID('relatedbill'),
               VI_CASH_ID,
               CK_CA_ID);
          
            --添加关系表数据
            INSERT INTO DTRELATEDBILL
              (RBKEY, RBID, CASHID, CASHFID)
            VALUES
              (DBMS_RANDOM.STRING('x', 32),
               FUN_GET_ID('relatedbill'),
               CK_CA_ID,
               RK_CA_ID);
          
            ----------------------------------------------------用户金币存储值改变------------------------------------
          
            SELECT G.WFJ_GUIZE_ID
              INTO GUIZE_ID
              FROM DT_WFJ_GUIZE G
             WHERE G.WFJ_GUIZE_NAME = '供应商成本';
          
            --往会员金币表以及金币收支明细表里存值
            SELECT COUNT(*)
              INTO COUNTNUM
              FROM DT_WFJ_JIFEN
             WHERE STAFF_ID = PRO_STAFF_ID
               AND SCCID = PRO_SCCID;
          
            IF COUNTNUM > 0 THEN
              SELECT WFJ_JIFEN_SCORE, WFJ_JIFEN_ID
                INTO JIFEN_SCORE, NEW_JF_ID
                FROM DT_WFJ_JIFEN
               WHERE STAFF_ID = PRO_STAFF_ID
                 AND SCCID = PRO_SCCID;
            
              UPDATE DT_WFJ_JIFEN
                 SET WFJ_JIFEN_SCORE = JIFEN_SCORE + VI_MONEY
               WHERE STAFF_ID = PRO_STAFF_ID
                 AND SCCID = PRO_SCCID;
            
            ELSE
              NEW_JF_ID := FUN_GET_ID('WfjJifen');
              INSERT INTO DT_WFJ_JIFEN
                (WFJ_JIFEN_KEY,
                 WFJ_JIFEN_ID,
                 STAFF_ID,
                 WFJ_JIFEN_SCORE,
                 WFJ_JIFEN_STATE,
                 COMPANY_ID,
                 SCCID)
              VALUES
                (DBMS_RANDOM.STRING('x', 32),
                 NEW_JF_ID,
                 PRO_STAFF_ID,
                 VI_MONEY,
                 0,
                 COM_ID,
                 PRO_SCCID);
            END IF;
            -------------------------------------------------平台金币库存改变-----------------------------------------
          
            --平台金币库存表
            SELECT COUNT(*)
              INTO COUNTNUM
              FROM DT_INV_INVT I
             WHERE GOODSNAME = '微分金金币'
               AND COMPANYID = VI_COM_ID
               AND SOURCE = '用户兑换';
          
            IF COUNTNUM > 0 THEN
              SELECT I.INVENQUANTITY
                INTO KCL
                FROM DT_INV_INVT I
               WHERE GOODSNAME = '微分金金币'
                 AND COMPANYID = VI_COM_ID
                 AND SOURCE = '用户兑换';
            
              UPDATE DT_INV_INVT
                 SET INVENQUANTITY = TO_CHAR(TO_NUMBER(KCL) - VI_MONEY,
                                             'fm999999999999999999999999999999990.999999999'),
                     SUMPRICE      = TO_CHAR(TO_NUMBER(KCL) - VI_MONEY / 100,
                                             'fm999999999999999999999999999999990.999999999')
               WHERE GOODSNAME = '微分金金币'
                 AND COMPANYID = VI_COM_ID
                 AND SOURCE = '用户兑换';
            ELSE
            
              SELECT COUNT(*)
                INTO COUNTNUM
                FROM DT_INV_INVT I
               WHERE GOODSNAME = '微分金金币'
                 AND COMPANYID = VI_COM_ID
                 AND SOURCE = '批量生产';
            
              IF COUNTNUM > 0 THEN
                SELECT I.INVENQUANTITY
                  INTO KCL
                  FROM DT_INV_INVT I
                 WHERE GOODSNAME = '微分金金币'
                   AND COMPANYID = VI_COM_ID
                   AND SOURCE = '批量生产';
              
                UPDATE DT_INV_INVT
                   SET INVENQUANTITY = TO_CHAR(TO_NUMBER(KCL) - VI_MONEY,
                                               'fm999999999999999999999999999999990.999999999'),
                       SUMPRICE      = TO_CHAR(TO_NUMBER(KCL) -
                                               VI_MONEY / 100,
                                               'fm999999999999999999999999999999990.999999999')
                 WHERE GOODSNAME = '微分金金币'
                   AND COMPANYID = VI_COM_ID
                   AND SOURCE = '批量生产';
              END IF;
            END IF;
          
            OPEN VCUR_GET_GOODS;
            FETCH VCUR_GET_GOODS
              INTO G_PPID,
                   GOOD_QUAN,
                   GOOD_BI_ID,
                   G_NAME,
                   jiangpin,
                   JB_PRICE,
                   COST_PRICE,
                   good_money;
            LOOP
              EXIT WHEN VCUR_GET_GOODS%NOTFOUND;
              if jiangpin = '1' then
                cb_premiums(VI_COM_ID,
                            VI_CASH_ID,
                            VI_STAFF_ID,
                            JB_PRICE * 100);
              else
                SCORE := ROUND(TO_NUMBER(GOOD_QUAN) * TO_NUMBER(JB_PRICE) * 100,
                               2);
              
                --金币收支明细
                INSERT INTO DT_WFJ_JIFEN_DETAIL
                  (JIFEN_DETAIL_KEY,
                   JIFEN_DETAIL_ID,
                   JIFEN_DETAIL_NAME,
                   JIFEN_DETAIL_DATE,
                   JIFEN_DETAIL_SCORE,
                   JIFEN_DETAIL_STATE,
                   WFJ_GUIZE_ID,
                   WFJ_JIFEN_ID,
                   WFJ_CASH_ID,
                   WFJ_GOOD_ID)
                VALUES
                  (DBMS_RANDOM.STRING('x', 32),
                   FUN_GET_ID('WfjJifenDetail'),
                   G_NAME || '-供应商成本',
                   SYSDATE,
                   TO_CHAR(SCORE,
                           'fm999999999999999999999999999999990.999999999'),
                   1,
                   GUIZE_ID, --规则外键
                   NEW_JF_ID,
                   RK_CA_ID, --金币入库单据ID
                   GOOD_BI_ID);
              end if;
              FETCH VCUR_GET_GOODS
                INTO G_PPID,
                     GOOD_QUAN,
                     GOOD_BI_ID,
                     G_NAME,
                     jiangpin,
                     JB_PRICE,
                     COST_PRICE,
                     good_money;
            END LOOP;
            CLOSE VCUR_GET_GOODS;
            COMMIT;
          END IF;
          -----------------------------------------------供应商--金币入库平台金币出库---------结束--------------------------------------
          -----------------------------------------------佣金分配--金币入库平台金币出库-------开始--------------------------------------
          /*
          BEGIN
            SELECT I.INVENQUANTITY
              INTO KCL
              FROM DT_INV_INVT I
             WHERE GOODSNAME = '微分金金币'
               AND COMPANYID = VI_COM_ID;
          EXCEPTION
            WHEN OTHERS THEN
              RAISE_APPLICATION_ERROR(-20002,
                                      '请先确认当前公司是否有足够的微分金金币可以出库');
          END;*/
          --佣金会员类别及分配比例
          OPEN VCUR_GET_USER;
          FETCH VCUR_GET_USER
            INTO PRO_STAFF_ID,
                 COM_ID,
                 WFJ_NUM,
                 PRO_MB_ID,
                 BFB_NUM,
                 PRO_SCCID;
          WHILE VCUR_GET_USER%FOUND LOOP
            SUM2_MONEY := 0;
            --查询会员个人信息
            SELECT S.STAFFCODE, S.STAFFNAME
              INTO S_CODE1, S_NAME1
              FROM DT_HR_STAFF S
             WHERE S.STAFFID = PRO_STAFF_ID;
          
            --查询会员公司名称
            IF COM_ID IS NOT NULL THEN
              SELECT C.COMPANYNAME, C.GROUPCOMPANYSN
                INTO COM_NAME, G_SN
                FROM DTCOMPANY C
               WHERE COMPANYID = COM_ID;
            ELSE
              COM_NAME := ' ';
              G_SN     := ' ';
              COM_ID   := ' ';
            END IF;
          
            --金币入库单id
            RK_CA_ID := FUN_GET_ID('cashierTally');
            --金币出库单ID
            CK_CA_ID := FUN_GET_ID('cashierTally');
            --金币出库单凭证号
            CK_JUM := FUN_GET_BILL_ID();
          
            --循环订单产品
            OPEN VCUR_GET_GOODS;
            FETCH VCUR_GET_GOODS
              INTO G_PPID,
                   GOOD_QUAN,
                   GOOD_BI_ID,
                   G_NAME,
                   jiangpin,
                   JB_PRICE,
                   COST_PRICE,
                   good_money;
          
            LOOP
              EXIT WHEN VCUR_GET_GOODS%NOTFOUND;
              if TO_NUMBER(COST_PRICE) > TO_NUMBER(JB_PRICE) then
                --添加会员分金币数
              
                /* SELECT COUNT(*)
                  INTO COUNTNUM
                  FROM DT_PRO_SETUP S
                 WHERE S.PPID = G_PPID
                   AND S.COM_ID = VI_COM_PID
                   AND S.FCOM_ID IS NULL;
                
                IF COUNTNUM <= 0 THEN
                  SELECT COUNT(*)
                    INTO COUNTNUM
                    FROM DT_PRO_SETUP S
                   WHERE S.PPID = G_PPID
                     AND S.COM_ID = VI_COM_PID
                     AND S.FCOM_ID = COM_ID;
                  IF COUNTNUM <= 0 THEN
                    SELECT COUNT(*)
                      INTO COUNTNUM
                      FROM DT_PRO_SETUP S
                     WHERE S.PPID = G_PPID
                       AND S.COM_ID = COM_ID
                       AND S.FCOM_ID IS NULL;
                    IF COUNTNUM <= 0 THEN
                      BEGIN
                        SELECT S.SUID, S.BROKERAGE
                          INTO PRO_SUID, JB_PRICE
                          FROM DT_PRO_SETUP S
                         WHERE S.PPID = G_PPID
                           AND S.COM_ID = COM_ID
                           AND S.FCOM_ID IS NULL;
                      EXCEPTION
                        WHEN OTHERS THEN
                          RAISE_APPLICATION_ERROR(-20002,
                                                  '请先确认当前要分配金币的产品是否已经设计佣金');
                      END;
                    ELSE
                      SELECT S.SUID, S.BROKERAGE
                        INTO PRO_SUID, JB_PRICE
                        FROM DT_PRO_SETUP S
                       WHERE S.PPID = G_PPID
                         AND S.COM_ID = COM_ID
                         AND S.FCOM_ID IS NULL;
                    END IF;
                  ELSE
                    SELECT S.SUID, S.BROKERAGE
                      INTO PRO_SUID, JB_PRICE
                      FROM DT_PRO_SETUP S
                     WHERE S.PPID = G_PPID
                       AND S.COM_ID = VI_COM_PID
                       AND S.FCOM_ID = COM_ID;
                  END IF;
                ELSE
                  SELECT S.SUID, S.BROKERAGE
                    INTO PRO_SUID, JB_PRICE
                    FROM DT_PRO_SETUP S
                   WHERE S.PPID = G_PPID
                     AND S.COM_ID = COM_ID
                     AND S.FCOM_ID IS NULL;
                END IF;*/
              
                --平台\用户金币出库\入库产品表
                SCORE := 0;
                if INSTR(good_money, '-', 1) = 0 then
                
                  SCORE := ROUND(TO_NUMBER(GOOD_QUAN) *
                                 (TO_NUMBER(COST_PRICE) -
                                  TO_NUMBER(JB_PRICE)) *
                                 (TO_NUMBER(REPLACE(BFB_NUM, '%', ''))),
                                 2);
                else
                  SCORE := ROUND(((TO_NUMBER(GOOD_QUAN) *
                                 (TO_NUMBER(COST_PRICE) -
                                 TO_NUMBER(JB_PRICE))) - 3) *
                                 (TO_NUMBER(REPLACE(BFB_NUM, '%', ''))),
                                 2);
                
                end if;
              
                SUM2_MONEY := ROUND(score / 100, 2) + SUM2_MONEY;
              
                UPDATE DT_MEMBER_BACKUP M
                   SET M.JB_NUM = TO_CHAR(SCORE + NVL(M.JB_NUM, 0),
                                          'fm999999999999999999999999999999990.999999999')
                 WHERE M.MB_ID = PRO_MB_ID;
              
                FOR I IN 1 .. 2 LOOP
                  IF I = 1 THEN
                    DEPOT_NAME := '销售库';
                    DEPOT_ID   := NULL;
                    NEW_CA_ID  := RK_CA_ID;
                  ELSE
                    SELECT D.DEPOTNAME, D.DEPOTID, D.ITEMID
                      INTO DEPOT_NAME, DEPOT_ID, DEPOT_ITEMID
                      FROM DTDEPOTMANAGE D
                     WHERE D.COMPANYID = VI_COM_ID
                       AND D.DEPOTPID = '001'
                       AND D.DEPOTNAME = '销售库';
                  
                    NEW_CA_ID := CK_CA_ID;
                  END IF;
                
                  NEW_GB_ID := FUN_GET_ID('goodsbills');
                  SELECT COUNT(*)
                    INTO COUNTNUM
                    FROM DT_PRODUCTPACKAGING A
                   WHERE A.COMPANYID =
                         'company201009046vxdyzy4wg0000000025'
                     AND A.GOODSNAME = '微分金金币';
                  IF COUNTNUM > 0 THEN
                    INSERT INTO DTGOODSBILLS
                      (GOODSBILLSKEY,
                       GOODSBILLSID,
                       --COMPANYID,
                       CASHIERBILLSID,
                       SUBJECTSID,
                       SUBJECTSNAME,
                       COSTTYPE, --费用类别
                       PAYTYPE, --付款方式
                       WEIGHT,
                       GOODSID,
                       QUANTITY,
                       PRICE,
                       MONEY,
                       DEPOTID, --库房ID
                       DEPOTNAME, --库房名称
                       GOODSVARIABLEID, --单位
                       IDENTIFYINGCODE, --00
                       BATCHNUMBER, --批号
                       GOODSNOMBER, --物品在账单中的排列序号
                       GOODSNUM,
                       GOODSNAME,
                       TYPEID,
                       STANDARD,
                       KCSTATUS, --16：已出库
                       GOODSTATUS, --状态00正常 01维修02报废
                       PPID)
                      SELECT DBMS_RANDOM.STRING('x', 32),
                             NEW_GB_ID,
                             --companyid,
                             NEW_CA_ID,
                             A.SUBJECTID,
                             A.SUBJECTNAME,
                             '', --费用类别
                             '08',
                             A.WEIGHT,
                             A.GOODSID,
                             TO_CHAR(SCORE,
                                     'fm999999999999999999999999999999990.999999999'),
                             '0.01',
                             TO_CHAR(SCORE / 100,
                                     'fm999999999999999999999999999999990.999999999'),
                             DEPOT_ID,
                             DEPOT_NAME,
                             A.VARIABLEID,
                             '00',
                             '',
                             '1',
                             A.GOODSNUM,
                             A.GOODSNAME,
                             A.TYPE,
                             A.STANDARD,
                             '15',
                             '00',
                             A.PPID
                        FROM DT_PRODUCTPACKAGING A
                       WHERE A.COMPANYID =
                             'company201009046vxdyzy4wg0000000025'
                         AND A.GOODSNAME = '微分金金币';
                  
                  ELSE
                    INSERT INTO DTGOODSBILLS
                      (GOODSBILLSKEY,
                       GOODSBILLSID,
                       --COMPANYID,
                       CASHIERBILLSID,
                       PAYTYPE, --付款方式
                       QUANTITY,
                       PRICE,
                       MONEY,
                       DEPOTNAME, --库房名称
                       IDENTIFYINGCODE, --00
                       GOODSNAME,
                       KCSTATUS, --15：已入库
                       GOODSTATUS) --状态00正常 01维修02报废
                    VALUES
                      (DBMS_RANDOM.STRING('x', 32),
                       NEW_GB_ID,
                       --com_id,
                       NEW_CA_ID,
                       '08',
                       TO_CHAR(SCORE,
                               'fm999999999999999999999999999999990.999999999'),
                       '0.01',
                       TO_CHAR(SCORE / 100,
                               'fm999999999999999999999999999999990.999999999'),
                       '销售库',
                       '00',
                       '微分金金币',
                       '15',
                       '00');
                  END IF;
                
                END LOOP;
              
                --进销存单据表
                INSERT INTO DT_INV_FB
                  (FINANCIALBILLKEY,
                   FINANCIALBILLID,
                   GROUPCOMPANYSN,
                   COMPANYID,
                   --ORGANIZATIONID,
                   --DEPARTMENTID,
                   BILLSTATUS,
                   BILLSTYPE,
                   JOURNALNUM,
                   BILLSDATE,
                   BILLSTAFFID,
                   BILLSTAFFNAME,
                   DEPOTID,
                   DEPOTNAME,
                   CASHIERBILLSID)
                  SELECT DBMS_RANDOM.STRING('x', 32),
                         FUN_GET_ID('financial'),
                         'groupcompany20120523G3VR9PXHZD0000000021',
                         'company201009046vxdyzy4wg0000000025',
                         --a.organizationid,
                         --a.departmentid,
                         '22',
                         '金币出库单',
                         CK_JUM,
                         SYSDATE,
                         A.INPUTID,
                         A.INPUTNAME,
                         DEPOT_ID,
                         DEPOT_NAME,
                         CK_CA_ID
                    FROM DTCASHIERBILLS A
                   WHERE A.CASHIERBILLSID = DDID;
              
                --添加关系表数据
                INSERT INTO DTRELATEDBILL
                  (RBKEY, RBID, CASHID, CASHFID)
                VALUES
                  (DBMS_RANDOM.STRING('x', 32),
                   FUN_GET_ID('relatedbill'),
                   VI_CASH_ID,
                   CK_CA_ID);
              
                --添加关系表数据
                INSERT INTO DTRELATEDBILL
                  (RBKEY, RBID, CASHID, CASHFID)
                VALUES
                  (DBMS_RANDOM.STRING('x', 32),
                   FUN_GET_ID('relatedbill'),
                   CK_CA_ID,
                   RK_CA_ID);
              
                ----------------------------------------------------用户金币存储值改变------------------------------------
              
                SELECT G.WFJ_GUIZE_ID
                  INTO GUIZE_ID
                  FROM DT_WFJ_GUIZE G
                 WHERE G.WFJ_GUIZE_NAME = '购买送金币';
              
                --往会员金币表以及金币收支明细表里存值
                SELECT COUNT(*)
                  INTO COUNTNUM
                  FROM DT_WFJ_JIFEN
                 WHERE STAFF_ID = PRO_STAFF_ID
                   AND SCCID = PRO_SCCID;
                IF COUNTNUM > 0 THEN
                  SELECT WFJ_JIFEN_SCORE, WFJ_JIFEN_ID
                    INTO JIFEN_SCORE, NEW_JF_ID
                    FROM DT_WFJ_JIFEN
                   WHERE STAFF_ID = PRO_STAFF_ID
                     AND SCCID = PRO_SCCID;
                
                  UPDATE DT_WFJ_JIFEN
                     SET WFJ_JIFEN_SCORE = JIFEN_SCORE + SCORE
                   WHERE STAFF_ID = PRO_STAFF_ID
                     AND SCCID = PRO_SCCID;
                
                ELSE
                  NEW_JF_ID := FUN_GET_ID('WfjJifen');
                  INSERT INTO DT_WFJ_JIFEN
                    (WFJ_JIFEN_KEY,
                     WFJ_JIFEN_ID,
                     STAFF_ID,
                     WFJ_JIFEN_SCORE,
                     WFJ_JIFEN_STATE,
                     COMPANY_ID,
                     SCCID)
                  VALUES
                    (DBMS_RANDOM.STRING('x', 32),
                     NEW_JF_ID,
                     PRO_STAFF_ID,
                     SCORE,
                     0,
                     COM_ID,
                     PRO_SCCID);
                END IF;
              
                --金币收支明细
                INSERT INTO DT_WFJ_JIFEN_DETAIL
                  (JIFEN_DETAIL_KEY,
                   JIFEN_DETAIL_ID,
                   JIFEN_DETAIL_NAME,
                   JIFEN_DETAIL_DATE,
                   JIFEN_DETAIL_SCORE,
                   JIFEN_DETAIL_STATE,
                   WFJ_GUIZE_ID,
                   WFJ_JIFEN_ID,
                   WFJ_CASH_ID,
                   WFJ_GOOD_ID)
                VALUES
                  (DBMS_RANDOM.STRING('x', 32),
                   FUN_GET_ID('WfjJifenDetail'),
                   G_NAME || '-产品佣金分配',
                   SYSDATE,
                   SCORE,
                   1,
                   GUIZE_ID, --规则外键
                   NEW_JF_ID,
                   RK_CA_ID, --金币入库单据ID
                   GOOD_BI_ID);
                -------------------------------------------------平台金币库存改变-----------------------------------------
              
                --平台金币库存表
                SELECT COUNT(*)
                  INTO COUNTNUM
                  FROM DT_INV_INVT I
                 WHERE GOODSNAME = '微分金金币'
                   AND COMPANYID = VI_COM_ID
                   AND SOURCE = '用户兑换';
              
                IF COUNTNUM > 0 THEN
                  SELECT I.INVENQUANTITY
                    INTO KCL
                    FROM DT_INV_INVT I
                   WHERE GOODSNAME = '微分金金币'
                     AND COMPANYID = VI_COM_ID
                     AND SOURCE = '用户兑换';
                
                  UPDATE DT_INV_INVT
                     SET INVENQUANTITY = TO_CHAR(TO_NUMBER(KCL) - SCORE,
                                                 'fm999999999999999999999999999999990.999999999'),
                         SUMPRICE      = TO_CHAR(TO_NUMBER(KCL) - SCORE,
                                                 'fm999999999999999999999999999999990.999999999')
                   WHERE GOODSNAME = '微分金金币'
                     AND COMPANYID = VI_COM_ID
                     AND SOURCE = '用户兑换';
                ELSE
                
                  SELECT COUNT(*)
                    INTO COUNTNUM
                    FROM DT_INV_INVT I
                   WHERE GOODSNAME = '微分金金币'
                     AND COMPANYID = VI_COM_ID
                     AND SOURCE = '批量生产';
                
                  IF COUNTNUM > 0 THEN
                    SELECT I.INVENQUANTITY
                      INTO KCL
                      FROM DT_INV_INVT I
                     WHERE GOODSNAME = '微分金金币'
                       AND COMPANYID = VI_COM_ID
                       AND SOURCE = '批量生产';
                  
                    UPDATE DT_INV_INVT
                       SET INVENQUANTITY = TO_CHAR(TO_NUMBER(KCL) - SCORE,
                                                   'fm999999999999999999999999999999990.999999999'),
                           SUMPRICE      = TO_CHAR(TO_NUMBER(KCL) - SCORE,
                                                   'fm999999999999999999999999999999990.999999999')
                     WHERE GOODSNAME = '微分金金币'
                       AND COMPANYID = VI_COM_ID
                       AND SOURCE = '批量生产';
                  END IF;
                END IF;
                --平台金币库存盘点表
                SELECT COUNT(*)
                  INTO COUNTNUM
                  FROM DT_PRODUCTPACKAGING A
                 WHERE A.COMPANYID = 'company201009046vxdyzy4wg0000000025'
                   and A.GOODSNAME = '微分金金币';
                IF COUNTNUM > 0 THEN
                  INSERT INTO DT_INV_STOCKINVT
                    (STOCKINVKEY,
                     STOCKINVID,
                     COMPANYID,
                     GROUPCOMPANYSN,
                     GOODSID,
                     GOODSTYPE,
                     GOODSNAME,
                     INVENQUANTITY,
                     TYPE,
                     STAFFID,
                     STAFFNAME,
                     WAREHOUSE,
                     WAREHOUSENAME,
                     GOODSBILLSID)
                    SELECT DBMS_RANDOM.STRING('x', 32),
                           FUN_GET_ID('stockInv'),
                           VI_COM_ID,
                           'groupcompany20120523G3VR9PXHZD0000000021',
                           A.GOODSID,
                           A.TYPE,
                           A.GOODSNAME,
                           TO_CHAR(SCORE,
                                   'fm999999999999999999999999999999990.999999999'),
                           '01',
                           VI_STAFF_ID,
                           S_NAME,
                           DEPOT_ID,
                           DEPOT_NAME,
                           NEW_GB_ID
                      FROM DT_PRODUCTPACKAGING A
                     WHERE A.COMPANYID =
                           'company201009046vxdyzy4wg0000000025'
                       AND A.GOODSNAME = '微分金金币';
                
                ELSE
                  INSERT INTO DT_INV_STOCKINVT
                    (STOCKINVKEY,
                     STOCKINVID,
                     COMPANYID,
                     GROUPCOMPANYSN,
                     GOODSNAME,
                     INVENQUANTITY,
                     TYPE,
                     STAFFID,
                     STAFFNAME,
                     WAREHOUSE,
                     WAREHOUSENAME,
                     GOODSBILLSID)
                  VALUES
                    (DBMS_RANDOM.STRING('x', 32),
                     FUN_GET_ID('stockInv'),
                     VI_COM_ID,
                     'groupcompany20120523G3VR9PXHZD0000000021',
                     '微分金金币',
                     TO_CHAR(SCORE,
                             'fm999999999999999999999999999999990.999999999'),
                     '01',
                     VI_STAFF_ID,
                     S_NAME,
                     DEPOT_ID,
                     DEPOT_NAME,
                     NEW_GB_ID);
                END IF;
              
              end if;
            
              FETCH VCUR_GET_GOODS
                INTO DDID,
                     GOOD_QUAN,
                     GOOD_BI_ID,
                     G_NAME,
                     jiangpin,
                     JB_PRICE,
                     COST_PRICE,
                     good_money;
            END LOOP;
            CLOSE VCUR_GET_GOODS;
            if SUM2_MONEY > 0 then
              --用户金币入库单
              INSERT INTO DTCASHIERBILLS
                (CASHIERBILLSKEY,
                 CASHIERBILLSID,
                 COMPANYID,
                 BILLSTYPE,
                 JOURNALNUM,
                 STAFFID,
                 STAFFNAME,
                 STAFFCODE,
                 CASHIERDATE,
                 STATUS,
                 COMPANYNAME,
                 PROID,
                 PROJECTNAME, --项目名称
                 GROUPCOMPANYSN,
                 INPUTID,
                 INPUTNAME,
                 APPSTYLE,
                 PRICESUB,
                 CCOMPANYID,
                 CCOMPANYNAME,
                 STATUSBILL,
                 JNUMORDER)
              VALUES
                (DBMS_RANDOM.STRING('x', 32),
                 RK_CA_ID,
                 COM_ID,
                 '金币入库单',
                 FUN_GET_BILL_ID(),
                 PRO_STAFF_ID,
                 S_NAME1, --会员名称
                 S_CODE1, --会员编号
                 SYSDATE,
                 '15',
                 COM_NAME, --公司名称
                 '002',
                 '金币分配',
                 G_SN, --集团组织机构ID
                 VI_STAFF_ID,
                 S_NAME,
                 '08',
                 TO_CHAR(SUM2_MONEY,
                         'fm999999999999999999999999999999990.999999999'),
                 'company201009046vxdyzy4wg0000000025',
                 '北京天太世统科技有限责任公司',
                 '04',
                 JOU_NUM);
            
              --添加关系表数据
              INSERT INTO DTRELATEDBILL
                (RBKEY, RBID, CASHID, CASHFID)
              VALUES
                (DBMS_RANDOM.STRING('x', 32),
                 FUN_GET_ID('relatedbill'),
                 VI_CASH_ID,
                 RK_CA_ID);
            
              --平台金币出库单
            
              INSERT INTO DTCASHIERBILLS
                (CASHIERBILLSKEY,
                 CASHIERBILLSID,
                 COMPANYID,
                 BILLSTYPE,
                 JOURNALNUM,
                 STAFFID,
                 STAFFNAME,
                 STAFFCODE,
                 CASHIERDATE,
                 STATUS,
                 COMPANYNAME,
                 PROID,
                 PROJECTNAME, --项目名称
                 GROUPCOMPANYSN,
                 INPUTID,
                 INPUTNAME,
                 APPSTYLE,
                 PRICESUB,
                 CCOMPANYID,
                 CCOMPANYNAME,
                 STATUSBILL,
                 JNUMORDER)
              VALUES
                (DBMS_RANDOM.STRING('x', 32),
                 CK_CA_ID,
                 'company201009046vxdyzy4wg0000000025',
                 '金币出库单',
                 CK_JUM,
                 VI_STAFF_ID,
                 S_NAME, --会员名称
                 S_CODE, --会员编号
                 SYSDATE,
                 '16',
                 '北京天太世统科技有限责任公司', --公司名称
                 '002',
                 '金币分配',
                 'groupcompany20120523G3VR9PXHZD0000000021', --集团组织机构id
                 VI_STAFF_ID,
                 S_NAME1,
                 '08',
                 TO_CHAR(SUM2_MONEY,
                         'fm999999999999999999999999999999990.999999999'),
                 COM_ID,
                 COM_NAME,
                 '04',
                 JOU_NUM);
            end if;
            FETCH VCUR_GET_USER
              INTO PRO_STAFF_ID,
                   COM_ID,
                   WFJ_NUM,
                   PRO_MB_ID,
                   BFB_NUM,
                   PRO_SCCID;
          
          END LOOP;
          CLOSE VCUR_GET_USER;
        
          UPDATE DTCASHIERBILLS C
             SET C.FKSTATUS = '04'
           WHERE C.STATUSBILL = '04'
             AND C.BILLSTYPE = '项目收入预算单'
             AND C.FKSTATUS = '03'
             AND C.CASHIERBILLSID = VI_CASH_ID;
        
          COMMIT;
        end if;
      end if;
    end if;
  END IF;
  <<here>>
  null;
  -----------------------------------------------佣金分配--金币入库平台金币出库---------结束--------------------------------------
END GET_DISTRIBUTION;
/

