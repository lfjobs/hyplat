create view VIEW_ARCHIVE
            (HISTORYKEY, HISTORYID, INUSER, INUSERNAME, INTIME, LOCATIONID, LOCATIONNAME, OUTUSERNAME, OUTTIME, STATE,
             ARCHIVESID, ARCHIVECODE, RENEWALDATE, COMPANYID, BARCODE, CHIPID, NAME, SECURITYLEVEL, OBSOLETESTATUS,
             ATTACH, STARTVALIDITY, ENDVALIDITY, STAFFID, MEMBER, CATEMODULE, CATEGROYID, PARENT, CATEGROYNAME)
as
select h.historykey,h.historyid,h.inuser,inu.staffname inusername,h.intime,v.locationid,v.locationname,
h.outuser outusername,h.outtime,h.state,a.archivesid,a.archivecode,a.renewaldate,a.companyid,a.barcode,a.chipid,a.name,a.securitylevel,a.obsoletestatus,a.attach,
a.startvalidity,a.endvalidity,a.staffid,s.staffname member,c.catemodule,c.archiveid categroyid,c.parent,c.name categroyname
from dt_archives_archiveshistory h left join dt_archives_inventorylocation v  on h.location = v.locationkey join dt_archives_archives a on h.archivesid = a.archiveskey join dt_archives_cataloguearchives c  on a.category = c.archivekey  join dt_hr_staff inu on
h.inuser = inu.staffid left join dt_hr_staff out on h.outuser = out.staffid left join dt_hr_staff s  on a.staffid = s.staffid
order by h.intime desc


/

