create PROCEDURE PRO_BUYJINBI(VI_COM_ID VARCHAR2, --公司ID
                                         
                                         --VI_COM_PID  DTCOMPANY.COMPANYPID%TYPE, --父公司ID
                                         --VI_CASH_ID  VARCHAR2, --单据ID
                                         JOU_NUM     VARCHAR2, --订单编号
                                         VI_STAFF_ID VARCHAR2, --付款人ID
                                         PRO_SCCID   VARCHAR2, --付款人账号ID
                                         VI_MONEY    VARCHAR2, --购买金币金额数
                                         VI_APPSTYLE VARCHAR2, --支付方式
                                         MERSEQ_ID   VARCHAR2 --第三方交易号
                                         ) IS
  --金币充值
  DDID      DTGOODSBILLS.GOODSBILLSID%TYPE; --订单物品ID
  CK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --出库单据ID
  RK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --入库单据ID
  NEW_CA_ID DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  NEW_GB_ID DTGOODSBILLS.GOODSBILLSID%TYPE; --物品单据ID
  CA_SK_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --收款单据ID
  CA_ZK_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE; --支款单据ID
  ZK_JUM    DTCASHIERBILLS.JOURNALNUM%TYPE; --支款单编号

  GOOD_BI_ID DTGOODSBILLS.GOODSBILLSID%TYPE; --购买产品单据ID
  GUIZE_ID   DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE; --积分规则ID

  VI_CASH_ID DTCASHIERBILLS.CASHIERBILLSID%TYPE; --订单单据ID

  --当前会员信息
  COM_ID      T_ESHOP_CUSCOM.COMPANYID%TYPE; --当前会员公司ID
  COM_NAME    DTCOMPANY.COMPANYNAME%TYPE; --公司名称
  G_SN        DTCOMPANY.GROUPCOMPANYSN%TYPE; --集团组织机构
  JIFEN_SCORE DT_WFJ_JIFEN_DETAIL.JIFEN_DETAIL_SCORE%TYPE; --当前会员金币量
  NEW_JF_ID   DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE; --新生成金币表ID

  S_NAME    DT_HR_STAFF.STAFFNAME%TYPE; --操作人姓名
  S_CODE    DT_HR_STAFF.STAFFCODE%TYPE; --操作人编号
  S_ACCOUNT T_ESHOP_CUSCOM.ACCOUNT%TYPE; --操作人微分金账号账号

  BILL_ID    DTCASHIERBILLS.CASHIERBILLSID%TYPE; --单据ID
  BILL_TYPE  DTCASHIERBILLS.BILLSTYPE%TYPE; --单据类别
  BILL_STUTA DTCASHIERBILLS.STATUS%TYPE; --单据状态

  --仓库信息
  DEPOT_ID     DTDEPOTMANAGE.DEPOTID%TYPE; --仓库ID
  DEPOT_NAME   DTDEPOTMANAGE.DEPOTNAME%TYPE; --仓库名称
  DEPOT_ITEMID DTDEPOTMANAGE.ITEMID%TYPE; --仓库类别
  KCL          DT_INV_INVT.INVENQUANTITY%TYPE; --金币库存量
  STOCK_TYPE   DT_INV_STOCKINVT.Type%TYPE; --库存盘点明细类型 00：入库 01：出库

  COUNTNUM NUMBER(5); --条数

  VII_MONEY NUMBER(20, 2); --金币数

BEGIN
  VII_MONEY := ROUND(TO_NUMBER(VI_MONEY) * 100, 2); --金币数

  --查询购买人信息
  SELECT S.STAFFNAME, S.STAFFCODE
    INTO S_NAME, S_CODE
    FROM DT_HR_STAFF S
   WHERE S.STAFFID = VI_STAFF_ID;

  SELECT T.ACCOUNT
    INTO S_ACCOUNT
    FROM T_ESHOP_CUSCOM T
   WHERE T.SCCID = PRO_SCCID;

  -----------------------------------------------购买金币人员订单收支款单--------------------------------------

  IF MERSEQ_ID IS NOT NULL AND VI_MONEY IS NOT NULL THEN
  
    SELECT D.DEPOTNAME, D.DEPOTID, D.ITEMID
      INTO DEPOT_NAME, DEPOT_ID, DEPOT_ITEMID
      FROM DTDEPOTMANAGE D
     WHERE D.COMPANYID = VI_COM_ID
       AND D.DEPOTPID = '003'
       AND D.DEPOTNAME = '资金仓库';
  
    INSERT INTO DTPAYCASHIERBILL
      (GNKEY, PCBID, PAYJOURNALNUM, ORIJOURNALNUM, TRADE_NO)
    VALUES
      (DBMS_RANDOM.STRING('X', 32),
       FUN_GET_ID('pcbid'),
       JOU_NUM,
       JOU_NUM,
       MERSEQ_ID);
  
    --订单
    VI_CASH_ID := FUN_GET_ID('cashiertally');
    INSERT INTO DTCASHIERBILLS
      (CASHIERBILLSKEY,
       CASHIERBILLSID,
       COMPANYID,
       BILLSTYPE,
       JOURNALNUM,
       STAFFID,
       STAFFNAME,
       STAFFCODE,
       CASHIERDATE,
       STATUS,
       FKSTATUS,
       WFSTATUS1,
       WFSTATUS4,
       COMPANYNAME,
       PROID,
       PROJECTNAME, --项目名称
       GROUPCOMPANYSN,
       INPUTID,
       INPUTNAME,
       APPSTYLE,
       PRICESUB,
       CONTACTUSERID,
       CTUSERNAME,
       STATUSBILL,
       TRADE_NO, --第三方交易号
       JNUMORDER)
    VALUES
      (DBMS_RANDOM.STRING('X', 32),
       VI_CASH_ID,
       'company201009046vxdyzy4wg0000000025',
       '项目收入预算单',
       JOU_NUM,
       '', --购买人ID
       '系统生成', --购买人名称
       '', --购买人编号
       SYSDATE,
       '15',
       '04',
       '00',
       VI_APPSTYLE,
       '北京天太世统科技有限责任公司', --公司名称
       '004',
       '购买金币',
       'groupcompany20120523g3vr9pxhzd0000000021', --集团组织机构ID
       VI_STAFF_ID, --制单人ID
       S_NAME, --制单人名称
       VI_APPSTYLE,
       VI_MONEY,
       VI_STAFF_ID,
       S_NAME,
       '04',
       MERSEQ_ID,
       JOU_NUM);
  
    INSERT INTO DT_ORDER_BILL_ADD
      (OA_KEY,
       OA_ID,
       OA_COM_ID,
       OA_STAFF_ID,
       OA_BILL_ID,
       OA_BILL_JOUNUM,
       RECEIVENAME,
       RECEIVETEL,
       OA_GYS_ID,
       OA_SCCID)
    VALUES
      (DBMS_RANDOM.STRING('X', 32),
       FUN_GET_ID('DtOrderBillAdd'),
       'company201009046vxdyzy4wg0000000025',
       VI_STAFF_ID,
       VI_CASH_ID,
       JOU_NUM,
       S_NAME,
       S_ACCOUNT,
       'company201009046vxdyzy4wg0000000025', --购买人名称
       PRO_SCCID);
  
    GOOD_BI_ID := FUN_GET_ID('goodsbills');
    INSERT INTO DTGOODSBILLS
      (GOODSBILLSKEY,
       GOODSBILLSID,
       CASHIERBILLSID,
       SUBJECTSID,
       SUBJECTSNAME,
       COSTTYPE, --费用类别
       PAYTYPE, --付款方式
       WEIGHT,
       GOODSID,
       QUANTITY,
       PRICE,
       MONEY,
       DEPOTID, --库房ID
       DEPOTNAME, --库房名称
       GOODSVARIABLEID, --单位
       IDENTIFYINGCODE, --00
       BATCHNUMBER, --批号
       GOODSNOMBER, --物品在账单中的排列序号
       GOODSNUM,
       GOODSNAME,
       TYPEID,
       STANDARD,
       KCSTATUS, --16：已出库
       GOODSTATUS, --状态00正常 01维修02报废
       PPID)
      SELECT DBMS_RANDOM.STRING('X', 32),
             GOOD_BI_ID,
             VI_CASH_ID,
             A.SUBJECTID,
             A.SUBJECTNAME,
             '', --费用类别
             VI_APPSTYLE,
             A.WEIGHT,
             A.GOODSID,
             TO_CHAR(VII_MONEY,
                     'fm999999999999999999999999999999990.999999999'),
             '0.01',
             TO_CHAR(ROUND(VI_MONEY, 2),
                     'fm999999999999999999999999999999990.999999999'),
             DEPOT_ID,
             DEPOT_NAME,
             A.VARIABLEID,
             '00',
             '',
             '1',
             A.GOODSNUM,
             A.GOODSNAME,
             A.TYPE,
             A.STANDARD,
             '15',
             '00',
             A.PPID
        FROM DT_PRODUCTPACKAGING A
       WHERE A.COMPANYID = 'company201009046vxdyzy4wg0000000025'
         AND A.GOODSNAME = '微分金金币';
  
    --收款单（平台收入）
    CA_SK_ID := FUN_GET_ID('cashiertally');
    INSERT INTO DTCASHIERBILLS
      (CASHIERBILLSKEY,
       CASHIERBILLSID,
       COMPANYID,
       BILLSTYPE,
       JOURNALNUM,
       STAFFID,
       STAFFNAME,
       STAFFCODE,
       CASHIERDATE,
       STATUS,
       FKSTATUS,
       WFSTATUS1,
       WFSTATUS4,
       COMPANYNAME,
       PROID,
       PROJECTNAME, --项目名称
       GROUPCOMPANYSN,
       INPUTID,
       INPUTNAME,
       APPSTYLE,
       PRICESUB,
       CCOMPANYID,
       CCOMPANYNAME,
       STATUSBILL,
       TRADE_NO, --第三方交易号
       JNUMORDER)
    VALUES
      (DBMS_RANDOM.STRING('X', 32),
       CA_SK_ID,
       'company201009046vxdyzy4wg0000000025',
       '收款单',
       FUN_GET_BILL_ID(),
       '',
       '系统生成', --会员名称
       '', --会员编号
       SYSDATE,
       '15',
       '04',
       '00',
       VI_APPSTYLE,
       '北京天太世统科技有限责任公司', --公司名称
       '004',
       '购买金币',
       'groupcompany20120523g3vr9pxhzd0000000021', --集团组织机构ID
       '',
       '系统生成',
       VI_APPSTYLE,
       VI_MONEY,
       '',
       '',
       '04',
       MERSEQ_ID,
       JOU_NUM);
  
    NEW_GB_ID := FUN_GET_ID('goodsbills');
    INSERT INTO DTGOODSBILLS
      (GOODSBILLSKEY,
       GOODSBILLSID,
       --COMPANYID,
       CASHIERBILLSID,
       SUBJECTSID,
       SUBJECTSNAME,
       COSTTYPE, --费用类别
       PAYTYPE, --付款方式
       WEIGHT,
       GOODSID,
       QUANTITY,
       PRICE,
       MONEY,
       DEPOTID, --库房ID
       DEPOTNAME, --库房名称
       GOODSVARIABLEID, --单位
       IDENTIFYINGCODE, --00
       BATCHNUMBER, --批号
       GOODSNOMBER, --物品在账单中的排列序号
       GOODSNUM,
       GOODSNAME,
       TYPEID,
       STANDARD,
       KCSTATUS, --16：已出库
       GOODSTATUS, --状态00正常 01维修02报废
       PPID)
      SELECT DBMS_RANDOM.STRING('X', 32),
             NEW_GB_ID,
             --COMPANYID,
             CA_SK_ID,
             A.SUBJECTID,
             A.SUBJECTNAME,
             '', --费用类别
             VI_APPSTYLE,
             A.WEIGHT,
             A.GOODSID,
             TO_CHAR(VII_MONEY,
                     'fm999999999999999999999999999999990.999999999'),
             '0.01',
             TO_CHAR(ROUND(VI_MONEY, 2),
                     'fm999999999999999999999999999999990.999999999'),
             DEPOT_ID,
             DEPOT_NAME,
             A.VARIABLEID,
             '00',
             '',
             '1',
             A.GOODSNUM,
             A.GOODSNAME,
             A.TYPE,
             A.STANDARD,
             '15',
             '00',
             A.PPID
        FROM DT_PRODUCTPACKAGING A
       WHERE A.COMPANYID = 'company201009046vxdyzy4wg0000000025'
         AND A.GOODSNAME = '微分金金币';
  
    --转账表
    INSERT INTO DTCASHAPPLYBILLS
      (CASHAPPLYBILLSKEY,
       CASHAPPLYBILLSID,
       JOURNALNUM,
       APPROPRIATIONMONEY, --付款金额
       APPROPRIATIONDATE, --付款时间
       APPROPRIATESTATUS, --付款状态 00：未付款  01：已付款  02：暂不付款
       APPROPRIATIONNUM, --付款账号
       PROJECTNAME, --项目名称
       CASHIERBILLSID,
       APPROPRIATIONCOMPANYID, --付款方ID
       APPROPRIATIONCOMPANYNAME, --付款方NAME
       RECEIVABLESID, --收款方ID
       RECEIVABLESNAME, --收款方NAME
       RECROPRIATIONNUM, --收款账号
       APPSTYLE) --付款方式
    VALUES
      (DBMS_RANDOM.STRING('X', 32),
       FUN_GET_ID('cashapply'),
       ZK_JUM, --支款单JOURNALNUM
       VI_MONEY,
       SYSDATE,
       '01',
       '', --付款账号
       '购买金币',
       CA_ZK_ID,
       COM_ID,
       COM_NAME,
       VI_COM_ID,
       '北京天太世统科技有限责任公司',
       '',
       VI_APPSTYLE);
  
    --------------------------------------------------------生成金币出入库单据----------------------------------------
  
    --收支款单产品保存 2
    --进销存单据表
    INSERT INTO DT_INV_FB
      (FINANCIALBILLKEY,
       FINANCIALBILLID,
       GROUPCOMPANYSN,
       COMPANYID,
       ORGANIZATIONID,
       DEPARTMENTID,
       BILLSTATUS,
       BILLSTYPE,
       JOURNALNUM,
       BILLSDATE,
       BILLSTAFFID,
       BILLSTAFFNAME,
       DEPOTID,
       DEPOTNAME,
       CASHIERBILLSID)
      SELECT DBMS_RANDOM.STRING('X', 32),
             FUN_GET_ID('financial'),
             A.GROUPCOMPANYSN,
             A.COMPANYID,
             A.ORGANIZATIONID,
             A.DEPARTMENTID,
             BILL_STUTA,
             BILL_TYPE,
             ZK_JUM,
             SYSDATE,
             A.INPUTID,
             A.INPUTNAME,
             DEPOT_ID,
             DEPOT_NAME,
             BILL_ID
        FROM DTCASHIERBILLS A
       WHERE A.CASHIERBILLSID = DDID;
  
    SELECT COUNT(*)
      INTO COUNTNUM
      FROM DT_PRODUCTPACKAGING A
     WHERE A.COMPANYID = 'company201009046vxdyzy4wg0000000025'
       AND A.GOODSNAME = '银行存款';
    IF COUNTNUM > 0 THEN
      --平台现金库存盘点表
      INSERT INTO DT_INV_STOCKINVT
        (STOCKINVKEY,
         STOCKINVID,
         COMPANYID,
         GROUPCOMPANYSN,
         GOODSID,
         GOODSTYPE,
         GOODSNAME,
         INVENQUANTITY,
         TYPE,
         STAFFID,
         STAFFNAME,
         WAREHOUSE,
         WAREHOUSENAME,
         GOODSBILLSID,
         intime)
        SELECT DBMS_RANDOM.STRING('X', 32),
               FUN_GET_ID('STOCKINV'),
               VI_COM_ID,
               '',
               A.GOODSID,
               A.TYPE,
               A.GOODSNAME,
               VI_MONEY,
               '01',
               VI_STAFF_ID,
               S_NAME,
               DEPOT_ID,
               DEPOT_NAME,
               NEW_GB_ID,
               sysdate
          FROM DT_PRODUCTPACKAGING A
         WHERE A.COMPANYID = 'company201009046vxdyzy4wg0000000025'
           AND A.GOODSNAME = '银行存款';
    
    ELSE
      INSERT INTO DT_INV_STOCKINVT
        (STOCKINVKEY,
         STOCKINVID,
         COMPANYID,
         GROUPCOMPANYSN,
         GOODSNAME,
         INVENQUANTITY,
         TYPE,
         STAFFID,
         STAFFNAME,
         WAREHOUSE,
         WAREHOUSENAME,
         GOODSBILLSID,
         intime)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         FUN_GET_ID('stockinv'),
         VI_COM_ID,
         '',
         '银行存款',
         VI_MONEY,
         '01',
         VI_STAFF_ID,
         S_NAME,
         DEPOT_ID,
         DEPOT_NAME,
         NEW_GB_ID,
         sysdate);
    END IF;
  
    SELECT COUNT(*)
      INTO COUNTNUM
      FROM DT_INV_INVT I
     WHERE GOODSNAME = '银行存款'
       AND WAREHOUSE = DEPOT_ID
       AND COMPANYID = VI_COM_ID
       AND SOURCE = '销售盈利';
    IF COUNTNUM > 0 THEN
      SELECT I.INVENQUANTITY
        INTO KCL
        FROM DT_INV_INVT I
       WHERE GOODSNAME = '银行存款'
         AND WAREHOUSE = DEPOT_ID
         AND COMPANYID = VI_COM_ID
         AND SOURCE = '销售盈利';
      --平台现金库存表
      UPDATE DT_INV_INVT
         SET INVENQUANTITY = KCL + VI_MONEY, SUMPRICE = KCL + VI_MONEY
       WHERE GOODSNAME = '银行存款'
         AND WAREHOUSE = DEPOT_ID
         AND COMPANYID = VI_COM_ID
         AND SOURCE = '销售盈利';
    ELSE
      SELECT COUNT(*)
        INTO COUNTNUM
        FROM DT_INV_INVT I
       WHERE GOODSNAME = '银行存款'
         AND WAREHOUSE = DEPOT_ID
         AND COMPANYID = VI_COM_ID
         AND SOURCE = '上级拨款';
    
      IF COUNTNUM > 0 THEN
        SELECT I.INVENQUANTITY
          INTO KCL
          FROM DT_INV_INVT I
         WHERE GOODSNAME = '银行存款'
           AND WAREHOUSE = DEPOT_ID
           AND COMPANYID = VI_COM_ID
           AND SOURCE = '上级拨款';
        --平台现金库存表
        UPDATE DT_INV_INVT
           SET INVENQUANTITY = KCL + VI_MONEY, SUMPRICE = KCL + VI_MONEY
         WHERE GOODSNAME = '银行存款'
           AND WAREHOUSE = DEPOT_ID
           AND COMPANYID = VI_COM_ID
           AND SOURCE = '上级拨款';
      ELSE
        INSERT INTO DT_INV_INVT
          (INVENTORYKEY,
           INVENTORYID,
           COMPANYID,
           GROUPCOMPANYSN,
           WAREHOUSE,
           GOODSNAME,
           UNIT,
           UNITPRICE,
           INVENQUANTITY,
           SUMPRICE,
           SOURCE)
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           FUN_GET_ID('inventory'),
           VI_COM_ID,
           '',
           DEPOT_ID,
           '银行存款',
           '元',
           '1',
           VI_MONEY,
           VI_MONEY,
           '销售盈利');
      END IF;
    END IF;
  
    COMMIT;
  
    --收支款单产品保存结束
  
    --查询会员公司名称
    IF COM_ID IS NOT NULL THEN
      SELECT C.COMPANYNAME, C.GROUPCOMPANYSN
        INTO COM_NAME, G_SN
        FROM DTCOMPANY C
       WHERE COMPANYID = COM_ID;
    ELSE
      COM_NAME := ' ';
      G_SN     := ' ';
      COM_ID   := ' ';
    END IF;
  
    --用户金币入库单
    RK_CA_ID := FUN_GET_ID('cashiertally');
    INSERT INTO DTCASHIERBILLS
      (CASHIERBILLSKEY,
       CASHIERBILLSID,
       COMPANYID,
       BILLSTYPE,
       JOURNALNUM,
       STAFFID,
       STAFFNAME,
       STAFFCODE,
       CASHIERDATE,
       STATUS,
       COMPANYNAME,
       PROID,
       PROJECTNAME, --项目名称
       GROUPCOMPANYSN,
       INPUTID,
       INPUTNAME,
       APPSTYLE,
       PRICESUB,
       CCOMPANYID,
       CCOMPANYNAME,
       STATUSBILL,
       JNUMORDER)
    VALUES
      (DBMS_RANDOM.STRING('X', 32),
       RK_CA_ID,
       COM_ID,
       '金币入库单',
       FUN_GET_BILL_ID(),
       VI_STAFF_ID,
       S_NAME, --会员名称
       S_CODE, --会员编号
       SYSDATE,
       '15',
       COM_NAME, --公司名称
       '002',
       '金币分配',
       G_SN, --集团组织机构ID
       VI_STAFF_ID,
       S_NAME,
       '08',
       TO_CHAR(ROUND(VII_MONEY / 100, 2),
               'FM999999999999999999999999999999990.999999999'),
       VI_COM_ID,
       '北京天太世统科技有限责任公司',
       '04',
       JOU_NUM);
  
    --添加关系表数据
    INSERT INTO DTRELATEDBILL
      (RBKEY, RBID, CASHID, CASHFID)
    VALUES
      (DBMS_RANDOM.STRING('X', 32),
       FUN_GET_ID('relatedbill'),
       VI_CASH_ID,
       RK_CA_ID);
  
    --平台金币出库单
    CK_CA_ID := FUN_GET_ID('cashiertally');
    ZK_JUM   := FUN_GET_BILL_ID();
    INSERT INTO DTCASHIERBILLS
      (CASHIERBILLSKEY,
       CASHIERBILLSID,
       COMPANYID,
       BILLSTYPE,
       JOURNALNUM,
       STAFFID,
       STAFFNAME,
       STAFFCODE,
       CASHIERDATE,
       STATUS,
       COMPANYNAME,
       PROID,
       PROJECTNAME, --项目名称
       GROUPCOMPANYSN,
       INPUTID,
       INPUTNAME,
       APPSTYLE,
       PRICESUB,
       CCOMPANYID,
       CCOMPANYNAME,
       STATUSBILL,
       JNUMORDER)
    VALUES
      (DBMS_RANDOM.STRING('X', 32),
       CK_CA_ID,
       'company201009046vxdyzy4wg0000000025',
       '金币出库单',
       ZK_JUM,
       VI_STAFF_ID,
       S_NAME, --会员名称
       S_CODE, --会员编号
       SYSDATE,
       '16',
       '北京天太世统科技有限责任公司', --公司名称
       '002',
       '金币分配',
       'groupcompany20120523g3vr9pxhzd0000000021', --集团组织机构ID
       VI_STAFF_ID,
       S_NAME,
       '08',
       TO_CHAR(ROUND(VII_MONEY / 100, 2),
               'fm999999999999999999999999999999990.999999999'),
       COM_ID,
       COM_NAME,
       '04',
       JOU_NUM);
  
    --平台\用户金币出库\入库产品表
    FOR I IN 1 .. 2 LOOP
      IF I = 1 THEN
        DEPOT_NAME := '销售库';
        DEPOT_ID   := NULL;
        NEW_CA_ID  := RK_CA_ID;
        STOCK_TYPE := '00';
      ELSE
        SELECT D.DEPOTNAME, D.DEPOTID, D.ITEMID
          INTO DEPOT_NAME, DEPOT_ID, DEPOT_ITEMID
          FROM DTDEPOTMANAGE D
         WHERE D.COMPANYID = VI_COM_ID
           AND D.DEPOTPID = '001'
           AND D.DEPOTNAME = '销售库';
      
        NEW_CA_ID  := CK_CA_ID;
        STOCK_TYPE := '01';
      END IF;
    
      NEW_GB_ID := FUN_GET_ID('goodsbills');
      SELECT COUNT(*)
        INTO COUNTNUM
        FROM DT_PRODUCTPACKAGING A
       WHERE A.COMPANYID = 'company201009046vxdyzy4wg0000000025'
         AND A.GOODSNAME = '微分金金币';
      IF COUNTNUM > 0 THEN
        INSERT INTO DTGOODSBILLS
          (GOODSBILLSKEY,
           GOODSBILLSID,
           --COMPANYID,
           CASHIERBILLSID,
           SUBJECTSID,
           SUBJECTSNAME,
           COSTTYPE, --费用类别
           PAYTYPE, --付款方式
           WEIGHT,
           GOODSID,
           QUANTITY,
           PRICE,
           MONEY,
           DEPOTID, --库房ID
           DEPOTNAME, --库房名称
           GOODSVARIABLEID, --单位
           IDENTIFYINGCODE, --00
           BATCHNUMBER, --批号
           GOODSNOMBER, --物品在账单中的排列序号
           GOODSNUM,
           GOODSNAME,
           TYPEID,
           STANDARD,
           KCSTATUS, --16：已出库
           GOODSTATUS, --状态00正常 01维修02报废
           PPID)
          SELECT DBMS_RANDOM.STRING('X', 32),
                 NEW_GB_ID,
                 --COMPANYID,
                 NEW_CA_ID,
                 A.SUBJECTID,
                 A.SUBJECTNAME,
                 '', --费用类别
                 VI_APPSTYLE,
                 A.WEIGHT,
                 A.GOODSID,
                 TO_CHAR(VII_MONEY,
                         'fm999999999999999999999999999999990.999999999'),
                 '0.01',
                 TO_CHAR(ROUND(VII_MONEY / 100, 2),
                         'fm999999999999999999999999999999990.999999999'),
                 DEPOT_ID,
                 DEPOT_NAME,
                 A.VARIABLEID,
                 '00',
                 '',
                 '1',
                 A.GOODSNUM,
                 A.GOODSNAME,
                 A.TYPE,
                 A.STANDARD,
                 '15',
                 '00',
                 A.PPID
            FROM DT_PRODUCTPACKAGING A
           WHERE A.COMPANYID = 'company201009046vxdyzy4wg0000000025'
             AND A.GOODSNAME = '微分金金币';
      
      ELSE
        INSERT INTO DTGOODSBILLS
          (GOODSBILLSKEY,
           GOODSBILLSID,
           --COMPANYID,
           CASHIERBILLSID,
           PAYTYPE, --付款方式
           QUANTITY,
           PRICE,
           MONEY,
           DEPOTNAME, --库房名称
           IDENTIFYINGCODE, --00
           GOODSNAME,
           KCSTATUS, --15：已入库
           GOODSTATUS) --状态00正常 01维修02报废
        VALUES
          (DBMS_RANDOM.STRING('X', 32),
           NEW_GB_ID,
           --COM_ID,
           NEW_CA_ID,
           VI_APPSTYLE,
           TO_CHAR(VII_MONEY,
                   'fm999999999999999999999999999999990.999999999'),
           '0.01',
           TO_CHAR(ROUND(VII_MONEY / 100, 2),
                   'fm999999999999999999999999999999990.999999999'),
           '销售库',
           '00',
           '微分金金币',
           '15',
           '00');
      
      END IF;
    
      if i = 2 then
        --平台金币库存盘点表
        INSERT INTO DT_INV_STOCKINVT
          (STOCKINVKEY,
           STOCKINVID,
           COMPANYID,
           GROUPCOMPANYSN,
           GOODSID,
           GOODSTYPE,
           GOODSNAME,
           INVENQUANTITY,
           TYPE,
           STAFFID,
           SUMMONEY,
           STAFFNAME,
           WAREHOUSE,
           WAREHOUSENAME,
           GOODSBILLSID,
           intime)
          SELECT DBMS_RANDOM.STRING('X', 32),
                 FUN_GET_ID('stockinv'),
                 VI_COM_ID,
                 'groupcompany20120523g3vr9pxhzd0000000021',
                 A.GOODSID,
                 A.TYPE,
                 A.GOODSNAME,
                 TO_CHAR(VII_MONEY,
                         'fm999999999999999999999999999999990.999999999'),
                 STOCK_TYPE,
                 VI_STAFF_ID,
                 TO_CHAR(ROUND(VII_MONEY / 100, 2),
                         'fm999999999999999999999999999999990.999999999'),
                 S_NAME,
                 DEPOT_ID,
                 DEPOT_NAME,
                 NEW_GB_ID,
                 sysdate
            FROM DT_PRODUCTPACKAGING A
           WHERE A.COMPANYID = 'company201009046vxdyzy4wg0000000025'
             AND A.GOODSNAME = '微分金金币';
      end if;
    
    END LOOP;
  
    --进销存单据表
    INSERT INTO DT_INV_FB
      (FINANCIALBILLKEY,
       FINANCIALBILLID,
       GROUPCOMPANYSN,
       COMPANYID,
       --ORGANIZATIONID,
       --DEPARTMENTID,
       BILLSTATUS,
       BILLSTYPE,
       JOURNALNUM,
       BILLSDATE,
       BILLSTAFFID,
       BILLSTAFFNAME,
       DEPOTID,
       DEPOTNAME,
       CASHIERBILLSID)
      SELECT DBMS_RANDOM.STRING('X', 32),
             FUN_GET_ID('FINANCIAL'),
             'groupcompany20120523g3vr9pxhzd0000000021',
             'company201009046vxdyzy4wg0000000025',
             --A.ORGANIZATIONID,
             --A.DEPARTMENTID,
             '22',
             '金币出库单',
             ZK_JUM,
             SYSDATE,
             A.INPUTID,
             A.INPUTNAME,
             DEPOT_ID,
             DEPOT_NAME,
             CK_CA_ID
        FROM DTCASHIERBILLS A
       WHERE A.CASHIERBILLSID = DDID;
  
    --添加关系表数据
    INSERT INTO DTRELATEDBILL
      (RBKEY, RBID, CASHID, CASHFID)
    VALUES
      (DBMS_RANDOM.STRING('X', 32),
       FUN_GET_ID('relatedbill'),
       VI_CASH_ID,
       CK_CA_ID);
  
    --添加关系表数据
    INSERT INTO DTRELATEDBILL
      (RBKEY, RBID, CASHID, CASHFID)
    VALUES
      (DBMS_RANDOM.STRING('X', 32),
       FUN_GET_ID('relatedbill'),
       CK_CA_ID,
       RK_CA_ID);
  
    ----------------------------------------------------用户金币存储值改变------------------------------------
  
    SELECT G.WFJ_GUIZE_ID
      INTO GUIZE_ID
      FROM DT_WFJ_GUIZE G
     WHERE G.WFJ_GUIZE_NAME = '金币充值';
  
    --往会员金币表以及金币收支明细表里存值
    SELECT COUNT(*)
      INTO COUNTNUM
      FROM DT_WFJ_JIFEN
     WHERE STAFF_ID = VI_STAFF_ID
       AND SCCID = PRO_SCCID;
    IF COUNTNUM > 0 THEN
      SELECT WFJ_JIFEN_SCORE, WFJ_JIFEN_ID
        INTO JIFEN_SCORE, NEW_JF_ID
        FROM DT_WFJ_JIFEN
       WHERE STAFF_ID = VI_STAFF_ID
         AND SCCID = PRO_SCCID;
    
      UPDATE DT_WFJ_JIFEN
         SET WFJ_JIFEN_SCORE = ROUND(JIFEN_SCORE + VII_MONEY)
       WHERE STAFF_ID = VI_STAFF_ID
         AND SCCID = PRO_SCCID;
    
    ELSE
      NEW_JF_ID := FUN_GET_ID('wfjjifen');
      INSERT INTO DT_WFJ_JIFEN
        (WFJ_JIFEN_KEY,
         WFJ_JIFEN_ID,
         STAFF_ID,
         WFJ_JIFEN_SCORE,
         WFJ_JIFEN_STATE,
         COMPANY_ID,
         SCCID)
      VALUES
        (DBMS_RANDOM.STRING('X', 32),
         NEW_JF_ID,
         VI_STAFF_ID,
         VII_MONEY,
         0,
         COM_ID,
         PRO_SCCID);
    END IF;
  
    --金币收支明细
    INSERT INTO DT_WFJ_JIFEN_DETAIL
      (JIFEN_DETAIL_KEY,
       JIFEN_DETAIL_ID,
       JIFEN_DETAIL_NAME,
       JIFEN_DETAIL_DATE,
       JIFEN_DETAIL_SCORE,
       JIFEN_DETAIL_STATE,
       WFJ_GUIZE_ID,
       WFJ_JIFEN_ID,
       WFJ_CASH_ID,
       WFJ_GOOD_ID)
    VALUES
      (DBMS_RANDOM.STRING('X', 32),
       FUN_GET_ID('wfjjifendetail'),
       '金币充值',
       SYSDATE,
       VII_MONEY,
       1,
       GUIZE_ID, --规则外键
       NEW_JF_ID,
       RK_CA_ID, --金币入库单据ID
       GOOD_BI_ID);
    -------------------------------------------------平台金币库存改变-----------------------------------------
  
    --平台金币库存表
    SELECT COUNT(*)
      INTO COUNTNUM
      FROM DT_INV_INVT I
     WHERE GOODSNAME = '微分金金币'
       AND COMPANYID = VI_COM_ID
       AND SOURCE = '用户兑换';
  
    IF COUNTNUM > 0 THEN
      SELECT I.INVENQUANTITY
        INTO KCL
        FROM DT_INV_INVT I
       WHERE GOODSNAME = '微分金金币'
         AND COMPANYID = VI_COM_ID
         AND SOURCE = '用户兑换';
    
      UPDATE DT_INV_INVT
         SET INVENQUANTITY = TO_CHAR(ROUND(TO_NUMBER(KCL) - VII_MONEY, 2),
                                     'fm999999999999999999999999999999990.999999999'),
             SUMPRICE      = TO_CHAR(ROUND(TO_NUMBER(KCL) - VII_MONEY, 2),
                                     'fm999999999999999999999999999999990.999999999')
       WHERE GOODSNAME = '微分金金币'
         AND COMPANYID = VI_COM_ID
         AND SOURCE = '用户兑换';
    ELSE
    
      SELECT COUNT(*)
        INTO COUNTNUM
        FROM DT_INV_INVT I
       WHERE GOODSNAME = '微分金金币'
         AND COMPANYID = VI_COM_ID
         AND SOURCE = '批量生产';
    
      IF COUNTNUM > 0 THEN
        SELECT I.INVENQUANTITY
          INTO KCL
          FROM DT_INV_INVT I
         WHERE GOODSNAME = '微分金金币'
           AND COMPANYID = VI_COM_ID
           AND SOURCE = '批量生产';
      
        UPDATE DT_INV_INVT
           SET INVENQUANTITY = TO_CHAR(ROUND(TO_NUMBER(KCL) - VII_MONEY, 2),
                                       'fm999999999999999999999999999999990.999999999'),
               SUMPRICE      = TO_CHAR(ROUND(TO_NUMBER(KCL) - VII_MONEY, 2),
                                       'fm999999999999999999999999999999990.999999999')
         WHERE GOODSNAME = '微分金金币'
           AND COMPANYID = VI_COM_ID
           AND SOURCE = '批量生产';
      
      END IF;
    END IF;
  
    COMMIT;
  END IF;
END PRO_BUYJINBI;
/

