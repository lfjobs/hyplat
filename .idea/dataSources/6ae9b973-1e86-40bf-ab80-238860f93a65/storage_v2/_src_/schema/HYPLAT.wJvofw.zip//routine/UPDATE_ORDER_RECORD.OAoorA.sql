create procedure UPDATE_ORDER_RECORD(v_teacherId      in varchar2,
                                                     v_relayTrainerName in varchar2,
                                                     v_relayTrainerId in varchar2,
                                                     v_startTime      in varchar2,
                                                     v_endTime        in varchar2) is
  cursor cemp is
    select d.etoid
      from tb_elyc_order_record d
     where d.teacherid = v_teacherId
       and d.status = '1'
       and d.lessionstarttime between
           to_date(v_startTime, 'yyyy-MM-dd hh24:mi:ss')
       and to_date(v_endTime, 'yyyy-MM-dd hh24:mi:ss');
  --定义约车计划Id变量
  v_plan_car_detail_id tb_elyc_order_record.etoid%type;
begin
  --打开光标
  open cemp;

  --循环取出光标中该时段内容每个教练员计划的Id
  loop
    --取出一个Id放入到自定义变量中
    fetch cemp
      into v_plan_car_detail_id;

    exit when cemp%notfound; --如果没有取到值则退出循环

  --更新时间段列表中的
    update tb_elyc_order_record t
       set t.replaceteacherid = v_relayTrainerId,t.teachername=v_relayTrainerName
     where t.teacherid = v_teacherId
       and t.etoid = v_plan_car_detail_id;

  end loop;

  --关闭光标
  close cemp;

  commit;

end UPDATE_ORDER_RECORD;
/

