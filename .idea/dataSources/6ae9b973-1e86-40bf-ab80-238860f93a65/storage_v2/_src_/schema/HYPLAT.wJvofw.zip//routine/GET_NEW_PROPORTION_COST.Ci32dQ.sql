create PROCEDURE GET_NEW_PROPORTION_COST(VI_CASH_ID     VARCHAR2, --单据ID
                                                    VI_COM_ID      VARCHAR2, --平台公司ID
                                                    VI_WFSTATUS    VARCHAR2, -- 付款状态
                                                    VI_JOU_NUM     VARCHAR2, -- 订单号
                                                    VI_PROJECTNAME VARCHAR2 -- 订单号
                                                    ) /**业务佣金**/
 IS

  V_SID   T_ESHOP_CUSCOM.STAFFID%TYPE; --当前会员ID
  V_SCCID T_ESHOP_CUSCOM.SCCID%TYPE; --当前会员账号ID
  V_SNAME DT_HR_STAFF.STAFFNAME%TYPE; --当前会员姓名
  V_SCODE DT_HR_STAFF.STAFFCODE%TYPE; --当前会员编号

  V_COM_NAME DTCOMPANY.COMPANYNAME%TYPE; --平台公司名称
  V_G_SN     DTCOMPANY.GROUPCOMPANYSN%TYPE; --平台集团组织机构

  V_GYS_CID   T_ESHOP_CUSCOM.COMPANYID%TYPE; --当前会员公司ID
  V_GYS_CNAME DTCOMPANY.COMPANYNAME%TYPE; --公司名称
  V_GYS_G_SN  DTCOMPANY.GROUPCOMPANYSN%TYPE; --集团组织机构

  V_NEW_JF_ID    DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE; --新生成金币表ID
  V_WFJ_NUM      T_ESHOP_CUSCOM.CUSTYPE%TYPE; --分金币会员类别序号
  V_MB_ID        DT_MEMBER_BACKUP.MB_ID%TYPE; --订单中可以分配会员
  V_CK_CA_ID     DTCASHIERBILLS.CASHIERBILLSID%TYPE; --出库单据ID
  V_RK_CA_ID     DTCASHIERBILLS.CASHIERBILLSID%TYPE; --入库单据ID
  V_NEW_CA_ID    DTCASHIERBILLS.CASHIERBILLSID%TYPE; --单据ID
  V_NEW_GB_ID    DTGOODSBILLS.GOODSBILLSID%TYPE; --物品单据ID
  V_CK_JUM       DTCASHIERBILLS.JOURNALNUM%TYPE; --出库单编号
  V_GOOD_BI_ID   DTGOODSBILLS.GOODSBILLSID%TYPE; --购买产品单据ID
  V_GUIZE_ID     DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE; --积分规则ID
  V_SCORE        DT_WFJ_JIFEN_DETAIL.JIFEN_DETAIL_SCORE%TYPE; --按照比例计算出的数值  (虚拟币个数)
  V_DEPOT_ID     DTDEPOTMANAGE.DEPOTID%TYPE; --仓库ID
  V_DEPOT_NAME   DTDEPOTMANAGE.DEPOTNAME%TYPE; --仓库名称
  V_DEPOT_ITEMID DTDEPOTMANAGE.ITEMID%TYPE; --仓库类别
  V_COUNTNUM     NUMBER(5); --条数
  V_XJHB         VARCHAR2(20);
  V_PRO_XJHB     VARCHAR2(10);
  --V_JOU_NUM      DTCASHIERBILLS.JOURNALNUM%TYPE; --出库单编号
  V_SUBJECTID   DTSUBJECTS.SUBJECTSID%TYPE;
  V_SUBJECTNAME DTSUBJECTS.SUBJECTSID%TYPE;
  V_WEIGHT      DT_PRODUCTPACKAGING.WEIGHT%TYPE;
  V_GOODSID     DT_PRODUCTPACKAGING.GOODSID%TYPE;
  V_VARIABLEID  DT_PRODUCTPACKAGING.VARIABLEID%TYPE;
  V_GOODSNUM    DT_PRODUCTPACKAGING.GOODSNUM%TYPE;
  V_GOODSNAME   DT_PRODUCTPACKAGING.GOODSNAME%TYPE;
  V_TYPE        DT_PRODUCTPACKAGING.TYPE%TYPE;
  V_STANDARD    DT_PRODUCTPACKAGING.STANDARD%TYPE;
  V_PPID        DT_PRODUCTPACKAGING.PPID%TYPE;

  V_SUM_MONEY DT_WFJ_JIFEN_DETAIL.JIFEN_DETAIL_SCORE%TYPE; --计算传值

  CURSOR VCUR_GET_USER IS
  
    SELECT T.STAFF_ID, T.COM_ID, T.M_TYPE, T.MB_ID, T.JB_NUM, T.M_ID
      FROM DT_MEMBER_BACKUP T
     WHERE T.CASH_ID = VI_CASH_ID
       AND T.STATUS IS NULL
     ORDER BY T.M_TYPE DESC;

BEGIN

  --平台公司信息
  SELECT C.COMPANYNAME, C.GROUPCOMPANYSN
    INTO V_COM_NAME, V_G_SN
    FROM DTCOMPANY C
   WHERE COMPANYID = VI_COM_ID;

  IF VI_WFSTATUS = '05' THEN
    V_XJHB     := '微分金积分';
    V_PRO_XJHB := '积分';
  ELSE
    V_XJHB     := '微分金金币';
    V_PRO_XJHB := '金币';
  END IF;

  --虚拟产品信息
  SELECT COUNT(*)
    INTO V_COUNTNUM
    FROM DT_PRODUCTPACKAGING A
   WHERE A.COMPANYID = VI_COM_ID
     AND A.GOODSNAME = V_XJHB;

  IF V_COUNTNUM > 0 THEN
  
    SELECT A.SUBJECTID,
           A.SUBJECTNAME,
           A.WEIGHT,
           A.GOODSID,
           A.VARIABLEID,
           A.GOODSNUM,
           A.GOODSNAME,
           A.TYPE,
           A.STANDARD,
           A.PPID
      INTO V_SUBJECTID,
           V_SUBJECTNAME,
           V_WEIGHT,
           V_GOODSID,
           V_VARIABLEID,
           V_GOODSNUM,
           V_GOODSNAME,
           V_TYPE,
           V_STANDARD,
           V_PPID
      FROM DT_PRODUCTPACKAGING A
     WHERE A.COMPANYID = VI_COM_ID
       AND A.GOODSNAME = V_XJHB;
  
  ELSE
  
    V_SUBJECTID   := NULL;
    V_SUBJECTNAME := NULL;
    V_WEIGHT      := NULL;
    V_GOODSID     := NULL;
    V_VARIABLEID  := NULL;
    V_GOODSNUM    := NULL;
    V_GOODSNAME   := V_XJHB;
    V_TYPE        := '虚拟产品';
    V_STANDARD    := NULL;
    V_PPID        := NULL;
  
  END IF;

  --佣金会员类别及分配比例
  OPEN VCUR_GET_USER;

  FETCH VCUR_GET_USER
    INTO V_SID, V_GYS_CID, V_WFJ_NUM, V_MB_ID, V_SCORE, V_SCCID;

  WHILE VCUR_GET_USER%FOUND LOOP
  
    if V_SCORE > 0 then
    
      V_SUM_MONEY := ROUND(V_SCORE / 100, 4);
    
      --查询会员个人信息
      SELECT S.STAFFCODE, S.STAFFNAME
        INTO V_SCODE, V_SNAME
        FROM DT_HR_STAFF S
       WHERE S.STAFFID = V_SID;
    
      --查询会员公司名称
      IF V_GYS_CID IS NOT NULL THEN
      
        SELECT C.COMPANYNAME, C.GROUPCOMPANYSN
          INTO V_GYS_CNAME, V_GYS_G_SN
          FROM DTCOMPANY C
         WHERE COMPANYID = V_GYS_CID;
      
      ELSE
      
        SELECT CC.CID, CC.PSEUDO_COMPANY_NAME, C.GROUPCOMPANYSN
          INTO V_GYS_CID, V_GYS_CNAME, V_GYS_G_SN
          FROM (SELECT T.COMPANYID CID, T.PSEUDO_COMPANY_NAME
                  FROM T_ESHOP_CUSCOM T
                 WHERE T.COMPANYID IS NOT NULL
                   AND ROWNUM = 1
                 START WITH T.SCCID = V_SCCID
                CONNECT BY PRIOR T.SUPPERSCCID = T.SCCID) CC
          LEFT JOIN DTCOMPANY C
            ON CC.CID = C.COMPANYID;
      
      END IF;
    
      --金币入库单id
      V_RK_CA_ID := FUN_GET_ID('cashierTally');
    
      --金币出库单ID
      V_CK_CA_ID := FUN_GET_ID('cashierTally');
    
      --金币出库单凭证号
      V_CK_JUM := FUN_GET_BILL_ID();
    
      FOR I IN 1 .. 2 LOOP
      
        IF I = 1 THEN
        
          V_DEPOT_NAME := '销售库';
          V_DEPOT_ID   := NULL;
          V_NEW_CA_ID  := V_RK_CA_ID;
        
        ELSE
        
          SELECT D.DEPOTNAME, D.DEPOTID, D.ITEMID
            INTO V_DEPOT_NAME, V_DEPOT_ID, V_DEPOT_ITEMID
            FROM DTDEPOTMANAGE D
           WHERE D.COMPANYID = VI_COM_ID
             AND D.DEPOTPID = '001'
             AND D.DEPOTSTATE = '00'
             AND D.DEPOTNAME = '销售库';
        
          V_NEW_CA_ID := V_CK_CA_ID;
        
        END IF;
      
        V_NEW_GB_ID := FUN_GET_ID('goodsbills');
      
        INSERT INTO DTGOODSBILLS
          (GOODSBILLSKEY,
           GOODSBILLSID,
           --COMPANYID,
           CASHIERBILLSID,
           SUBJECTSID,
           SUBJECTSNAME,
           COSTTYPE, --费用类别
           PAYTYPE, --付款方式
           WEIGHT,
           GOODSID,
           QUANTITY,
           PRICE,
           MONEY,
           DEPOTID, --库房ID
           DEPOTNAME, --库房名称
           GOODSVARIABLEID, --单位
           IDENTIFYINGCODE, --00
           BATCHNUMBER, --批号
           GOODSNOMBER, --物品在账单中的排列序号
           GOODSNUM,
           GOODSNAME,
           TYPEID,
           STANDARD,
           KCSTATUS, --16：已出库
           GOODSTATUS, --状态00正常 01维修02报废
           PPID)
        VALUES
          (DBMS_RANDOM.STRING('x', 32),
           V_NEW_GB_ID,
           --COMPANYID,
           V_NEW_CA_ID,
           V_SUBJECTID,
           V_SUBJECTNAME,
           '', --费用类别
           '08',
           V_WEIGHT,
           V_GOODSID,
           TO_CHAR(V_SCORE, 'fm999999999999999999999999999999990.999999999'),
           '0.01',
           TO_CHAR(V_SUM_MONEY,
                   'fm999999999999999999999999999999990.999999999'),
           V_DEPOT_ID,
           V_DEPOT_NAME,
           V_VARIABLEID,
           '00',
           '',
           '1',
           V_GOODSNUM,
           V_GOODSNAME,
           V_TYPE,
           V_STANDARD,
           '15',
           '00',
           V_PPID);
      
      END LOOP;
    
      --进销存单据表
      INSERT INTO DT_INV_FB
        (FINANCIALBILLKEY,
         FINANCIALBILLID,
         GROUPCOMPANYSN,
         COMPANYID,
         --ORGANIZATIONID,
         --DEPARTMENTID,
         BILLSTATUS,
         BILLSTYPE,
         JOURNALNUM,
         BILLSDATE,
         BILLSTAFFID,
         BILLSTAFFNAME,
         DEPOTID,
         DEPOTNAME,
         CASHIERBILLSID)
        SELECT DBMS_RANDOM.STRING('x', 32),
               FUN_GET_ID('financial'),
               'groupcompany20120523G3VR9PXHZD0000000021',
               'company201009046vxdyzy4wg0000000025',
               --a.organizationid,
               --a.departmentid,
               '22',
               V_PRO_XJHB || '出库单',
               V_CK_JUM,
               SYSDATE,
               A.INPUTID,
               A.INPUTNAME,
               V_DEPOT_ID,
               V_DEPOT_NAME,
               V_CK_CA_ID
          FROM DTCASHIERBILLS A
         WHERE A.CASHIERBILLSID = VI_CASH_ID;
    
      ----------------------------------------------------用户金币存储值改变------------------------------------
    
      SELECT G.WFJ_GUIZE_ID
        INTO v_GUIZE_ID
        FROM DT_WFJ_GUIZE G
       WHERE G.WFJ_GUIZE_NAME = '业务佣金';
    
      --往会员金币表以及金币收支明细表里存值
      if VI_WFSTATUS = '05' then
        UPDATE DT_WFJ_BONUSPOINTS
           SET BONUSPOINTSCORE = NVL(BONUSPOINTSCORE, 0) + V_SCORE
         WHERE SCCID = V_SCCID;
      
        IF SQL%NOTFOUND THEN
          V_NEW_JF_ID := FUN_GET_ID('BonusPoints');
        
          INSERT INTO DT_WFJ_BONUSPOINTS
            (BONUSPOINTSKEY, BONUSPOINTSID, SCCID, BONUSPOINTSCORE)
          VALUES
            (DBMS_RANDOM.STRING('x', 32), V_NEW_JF_ID, V_SCCID, V_SCORE);
        
        ELSE
        
          SELECT BONUSPOINTSID
            INTO V_NEW_JF_ID
            FROM DT_WFJ_BONUSPOINTS
           WHERE SCCID = V_SCCID;
        
        END IF;
      
        --金币收支明细
        INSERT INTO DT_WFJ_BonusPoints_Detail
          (bonuspointsdetailkey,
           bonuspointsdetailid,
           bonuspointsdetailname,
           bonuspointsdetaildate,
           bonuspointsdetailscore,
           wfjguizeid,
           bonuspointsid,
           wfjcashid,
           wfjgoodid)
        VALUES
          (DBMS_RANDOM.STRING('x', 32),
           FUN_GET_ID('BonusPointsDetail'),
           VI_PROJECTNAME || '-产品佣金分配',
           SYSDATE,
           V_SCORE,
           V_GUIZE_ID, --规则外键
           V_NEW_JF_ID,
           V_RK_CA_ID, --金币入库单据ID
           V_GOOD_BI_ID);
      
      else
      
        UPDATE DT_WFJ_JIFEN
           SET WFJ_JIFEN_SCORE = NVL(WFJ_JIFEN_SCORE, 0) + V_SCORE
         WHERE STAFF_ID = V_SID
           AND SCCID = V_SCCID;
      
        IF SQL%NOTFOUND THEN
          V_NEW_JF_ID := FUN_GET_ID('WfjJifen');
          INSERT INTO DT_WFJ_JIFEN
            (WFJ_JIFEN_KEY,
             WFJ_JIFEN_ID,
             STAFF_ID,
             WFJ_JIFEN_SCORE,
             WFJ_JIFEN_STATE,
             COMPANY_ID,
             SCCID)
          VALUES
            (DBMS_RANDOM.STRING('x', 32),
             V_NEW_JF_ID,
             V_SID,
             V_SCORE,
             0,
             V_GYS_CID,
             V_SCCID);
        ELSE
        
          SELECT WFJ_JIFEN_ID
            INTO V_NEW_JF_ID
            FROM DT_WFJ_JIFEN
           WHERE STAFF_ID = V_SID
             AND SCCID = V_SCCID;
        
        END IF;
      
        --金币收支明细
        INSERT INTO DT_WFJ_JIFEN_DETAIL
          (JIFEN_DETAIL_KEY,
           JIFEN_DETAIL_ID,
           JIFEN_DETAIL_NAME,
           JIFEN_DETAIL_DATE,
           JIFEN_DETAIL_SCORE,
           JIFEN_DETAIL_STATE,
           WFJ_GUIZE_ID,
           WFJ_JIFEN_ID,
           WFJ_CASH_ID,
           WFJ_GOOD_ID)
        VALUES
          (DBMS_RANDOM.STRING('x', 32),
           FUN_GET_ID('WfjJifenDetail'),
           VI_PROJECTNAME || '-产品佣金分配',
           SYSDATE,
           V_SCORE,
           1,
           V_GUIZE_ID, --规则外键
           V_NEW_JF_ID,
           V_RK_CA_ID, --金币入库单据ID
           V_GOOD_BI_ID);
      
      end if;
      -------------------------------------------------平台金币库存改变-----------------------------------------
      --平台金币库存表
    
      IF VI_WFSTATUS = '05' THEN
      
        UPDATE DT_INV_INVT
           SET INVENQUANTITY = TO_CHAR(TO_NUMBER(NVL(INVENQUANTITY, 0)) -
                                       V_SCORE,
                                       'FM999999999999999999999999999999990.999999999'),
               SUMPRICE      = TO_CHAR(TO_NUMBER(NVL(SUMPRICE, 0)) -
                                       V_SUM_MONEY,
                                       'FM999999999999999999999999999999990.999999999')
         WHERE GOODSNAME = V_XJHB
           AND COMPANYID = VI_COM_ID
           AND WAREHOUSENAME = '销售库';
      
      ELSE
      
        UPDATE DT_INV_INVT
           SET INVENQUANTITY = TO_CHAR(TO_NUMBER(NVL(INVENQUANTITY, 0)) -
                                       V_SCORE,
                                       'fm999999999999999999999999999999990.999999999'),
               SUMPRICE      = TO_CHAR(TO_NUMBER(NVL(SUMPRICE, 0)) -
                                       V_SUM_MONEY,
                                       'fm999999999999999999999999999999990.999999999')
         WHERE GOODSNAME = V_XJHB
           AND COMPANYID = VI_COM_ID
           AND SOURCE = '用户兑换'
           AND WAREHOUSENAME = '销售库';
      
        IF SQL%NOTFOUND THEN
        
          UPDATE DT_INV_INVT
             SET INVENQUANTITY = TO_CHAR(TO_NUMBER(NVL(INVENQUANTITY, 0)) -
                                         V_SCORE,
                                         'fm999999999999999999999999999999990.999999999'),
                 SUMPRICE      = TO_CHAR(TO_NUMBER(NVL(SUMPRICE, 0)) -
                                         V_SUM_MONEY,
                                         'fm999999999999999999999999999999990.999999999')
           WHERE GOODSNAME = V_XJHB
             AND COMPANYID = VI_COM_ID
             AND SOURCE = '批量生产'
             AND WAREHOUSENAME = '销售库';
        
        END IF;
      
      END IF;
    
      INSERT INTO DT_INV_STOCKINVT
        (STOCKINVKEY,
         STOCKINVID,
         COMPANYID,
         GROUPCOMPANYSN,
         GOODSID,
         GOODSTYPE,
         GOODSNAME,
         INVENQUANTITY,
         TYPE,
         STAFFID,
         STAFFNAME,
         WAREHOUSE,
         WAREHOUSENAME,
         GOODSBILLSID,
         INTIME)
      values
        (DBMS_RANDOM.STRING('x', 32),
         FUN_GET_ID('stockInv'),
         VI_COM_ID,
         'groupcompany20120523G3VR9PXHZD0000000021',
         V_GOODSID,
         V_TYPE,
         V_GOODSNAME,
         TO_CHAR(V_SCORE, 'fm999999999999999999999999999999990.999999999'),
         '01',
         V_SID,
         V_SNAME,
         V_DEPOT_ID,
         V_DEPOT_NAME,
         V_NEW_GB_ID,
         SYSDATE);
    
      --用户金币入库单
      INSERT INTO DTCASHIERBILLS
        (CASHIERBILLSKEY,
         CASHIERBILLSID,
         COMPANYID,
         BILLSTYPE,
         JOURNALNUM,
         STAFFID,
         STAFFNAME,
         STAFFCODE,
         CASHIERDATE,
         STATUS,
         COMPANYNAME,
         PROID,
         PROJECTNAME, --项目名称
         GROUPCOMPANYSN,
         INPUTID,
         INPUTNAME,
         APPSTYLE,
         PRICESUB,
         CCOMPANYID,
         CCOMPANYNAME,
         STATUSBILL,
         JNUMORDER)
      VALUES
        (DBMS_RANDOM.STRING('x', 32),
         V_RK_CA_ID,
         V_GYS_CID,
         V_PRO_XJHB || '入库单',
         FUN_GET_BILL_ID(),
         V_SID,
         V_SNAME, --会员名称
         V_SCODE, --会员编号
         SYSDATE,
         '15',
         V_GYS_CNAME, --公司名称
         '002',
         V_PRO_XJHB || '分配',
         V_GYS_G_SN, --集团组织机构ID
         V_SID,
         V_SNAME,
         '08',
         TO_CHAR(V_SUM_MONEY,
                 'fm999999999999999999999999999999990.999999999'),
         VI_COM_ID,
         V_COM_NAME,
         '04',
         VI_JOU_NUM);
    
      --添加关系表数据
      INSERT INTO DTRELATEDBILL
        (RBKEY, RBID, CASHID, CASHFID)
      VALUES
        (DBMS_RANDOM.STRING('x', 32),
         FUN_GET_ID('relatedbill'),
         VI_CASH_ID,
         V_RK_CA_ID);
    
      --平台金币出库单
    
      INSERT INTO DTCASHIERBILLS
        (CASHIERBILLSKEY,
         CASHIERBILLSID,
         COMPANYID,
         BILLSTYPE,
         JOURNALNUM,
         STAFFID,
         STAFFNAME,
         STAFFCODE,
         CASHIERDATE,
         STATUS,
         COMPANYNAME,
         PROID,
         PROJECTNAME, --项目名称
         GROUPCOMPANYSN,
         INPUTID,
         INPUTNAME,
         APPSTYLE,
         PRICESUB,
         CCOMPANYID,
         CCOMPANYNAME,
         STATUSBILL,
         JNUMORDER)
      VALUES
        (DBMS_RANDOM.STRING('x', 32),
         V_CK_CA_ID,
         VI_COM_ID,
         v_PRO_XJHB || '出库单',
         V_CK_JUM,
         V_SID,
         V_SNAME, --会员名称
         V_SCODE, --会员编号
         SYSDATE,
         '16',
         V_COM_NAME, --公司名称
         '002',
         v_PRO_XJHB || '分配',
         V_G_SN, --集团组织机构id
         V_SID,
         V_SNAME,
         '08',
         TO_CHAR(V_SUM_MONEY,
                 'fm999999999999999999999999999999990.999999999'),
         V_gys_CID,
         V_gys_CNAME,
         '04',
         VI_JOU_NUM);
    
    END IF;
  
    FETCH VCUR_GET_USER
      INTO V_SID, V_GYS_CID, V_WFJ_NUM, V_MB_ID, V_SCORE, V_SCCID;
  
  END LOOP;
  CLOSE VCUR_GET_USER;

END GET_NEW_PROPORTION_COST;
/

