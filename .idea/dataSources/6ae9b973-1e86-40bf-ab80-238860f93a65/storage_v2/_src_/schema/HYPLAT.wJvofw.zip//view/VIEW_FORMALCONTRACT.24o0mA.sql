create view VIEW_FORMALCONTRACT as
select a.archiveskey as formalcontractkey,a.archivesid as contractid,a.staffID,
s.staffName,s.sex,s.staffIdentityCard,
u.registerdate,
a.contractSignDate,
a.contractCode,
a.startValidity,
a.endValidity,
a.renewalDate,
a.companyID
from  DT_ARCHIVES_ARCHIVES a
join dtCos d on a.staffID = d.staffID
join dt_hr_staff s on d.staffid = s.staffId
join dtAudition u on u.staffid = a.staffid
where d.cosStatus = '50' and d.status='01' and u.status = '22'  and  u.companyid=d.companyid  and d.companyid=a.companyid


/

