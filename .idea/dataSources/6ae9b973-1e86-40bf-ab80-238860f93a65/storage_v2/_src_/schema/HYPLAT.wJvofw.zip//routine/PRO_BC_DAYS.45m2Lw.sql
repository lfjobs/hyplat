create PROCEDURE          "PRO_BC_DAYS" (vi_work_id varchar2,
                                        vi_com_id  varchar2, --公司id
                                        vi_date_s  char, --起始日期
                                        vi_date_e  char, --终止日期
                                        vi_acc_s   char, --起始科目
                                        vi_acc_e   char, --终止科目
                                        vi_dept    char, --部门id
                                        vi_bc_type char, --现金银行注记 A.银行，B.现金
                                        vi_type    char, --A：明细表，B：汇总表
                                       P_CURSOR OUT TESTPACKAGE.TEST_CURSOR --返回的记录集) 
                                        ) 
 IS
  vc_open_ym  char(6);
  vc_date_s   dt_inv_voucher.VOUCHERDATE%TYPE;
  vc_date_e   dt_inv_voucher.VOUCHERDATE%TYPE;
  vd_last_amt number(16, 2);
  vc_open2_ym char(6);
  vc_temp number(5);
  cursor vcur_get_vouchers is
    select sum(decode(b.DIRECTION, 'D', STANDARDMONEY, 0)) org_amt_d,
           sum(decode(b.DIRECTION, 'C', STANDARDMONEY, 0)) org_amt_c,
           sum(decode(b.DIRECTION, 'D', ACCOUNTINGMONEY, 0)) amt_d,
           sum(decode(b.DIRECTION, 'C', ACCOUNTINGMONEY, 0)) amt_c,
           b.CURRENCYID CURRENCYID,
           b.CURRENCYNAME CURRENCYNAME,
           a.ORG_ID org_id,
           b.SUBJECTSID SUBJECTSID,
           c.SUBJECTSNUMBERS,
           c.SUBJECTSNAME
      from dt_inv_voucher a, dt_inv_vouchers b, dtcsubjects c
     where a.VOUCHERID = b.VOUCHERID
       and a.COMPANYID = vi_com_id
       and ((a.org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
       and a.VOUCHERDATE between vc_date_s AND vc_date_e
       AND c.subjectsNumbers between vi_acc_s AND vi_acc_e
       AND SUBJECTSCATEGORY = vi_bc_type
       AND a.companyid = c.companyid
       AND b.SUBJECTSID = c.SUBJECTSID
     group by b.CURRENCYID,
              b.CURRENCYNAME,
              a.ORG_ID,
              b.SUBJECTSID,
              c.SUBJECTSNUMBERS,
              c.SUBJECTSNAME;

cursor vcur_get_vouchers_total is
    select sum(decode(b.DIRECTION, 'D', STANDARDMONEY, 0)) org_amt_d,
           sum(decode(b.DIRECTION, 'C', STANDARDMONEY, 0)) org_amt_c,
           sum(decode(b.DIRECTION, 'D', ACCOUNTINGMONEY, 0)) amt_d,
           sum(decode(b.DIRECTION, 'C', ACCOUNTINGMONEY, 0)) amt_c,
           b.CURRENCYID CURRENCYID,
           b.CURRENCYNAME CURRENCYNAME,
           a.ORG_ID org_id,
           b.SUBJECTSID SUBJECTSID,
           c.SUBJECTSNUMBERS,
           c.SUBJECTSNAME,
           a.VOUCHERDATE
      from dt_inv_voucher a, dt_inv_vouchers b, dtcsubjects c
     where a.VOUCHERID = b.VOUCHERID
       and a.COMPANYID = vi_com_id
       and ((a.org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
       and a.VOUCHERDATE between vc_date_s AND vc_date_e
       AND c.subjectsNumbers between vi_acc_s AND vi_acc_e
       AND SUBJECTSCATEGORY = vi_bc_type
       AND a.companyid = c.companyid
       AND b.SUBJECTSID = c.SUBJECTSID
     group by b.CURRENCYID,
              b.CURRENCYNAME,
              a.ORG_ID,
              b.SUBJECTSID,
              c.SUBJECTSNUMBERS,
              c.SUBJECTSNAME,
              a.VOUCHERDATE;

  cursor vcur_get_voucher_detail is
    select decode(b.DIRECTION, 'D', STANDARDMONEY, 0) org_amt_d,
           decode(b.DIRECTION, 'C', STANDARDMONEY, 0) org_amt_c,
           decode(b.DIRECTION, 'D', ACCOUNTINGMONEY, 0) amt_d,
           decode(b.DIRECTION, 'C', ACCOUNTINGMONEY, 0) amt_c,
           b.CURRENCYID CURRENCYID,
           b.CURRENCYNAME CURRENCYNAME,
           a.ORG_ID org_id,
           b.SUBJECTSID SUBJECTSID,
           c.SUBJECTSNUMBERS,
           c.SUBJECTSNAME,
           A.VOUCHERDATE,
           A.JOURNALNUM,
           B.VOUCHERSNUM,
           b.REASONTHING
      from dt_inv_voucher a, dt_inv_vouchers b, dtcsubjects c
     where a.VOUCHERID = b.VOUCHERID
       and a.COMPANYID = vi_com_id
       and ((a.org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
       AND c.subjectsNumbers between vi_acc_s AND vi_acc_e
       and a.VOUCHERDATE between vc_date_s AND vc_date_e      
       AND SUBJECTSCATEGORY = vi_bc_type
       AND a.companyid = c.companyid
       AND b.SUBJECTSID = c.SUBJECTSID
     ORDER BY A.VOUCHERDATE, A.JOURNALNUM, B.VOUCHERSNUM;

  cursor vcur_sort_bcdays IS
    select a.rowid, a.*, rownum rowsort
      from bc_day a
     where work_id = vi_work_id
     order by SUBJECTSID,
              CURRENCYID,
              sort,
              VOUCHERDATE,
              JOURNALNUM,
              VOUCHERNUM;
begin
  --处理期初


  vc_open_ym := fun_get_openym(vi_com_id, substrb(vi_date_s, 1, 6));--获取年月
  
  IF to_number(substrb(vi_date_s, 5, 2)) = 1 THEN--如果一月份（获取方式不同）

      vc_open2_ym:=to_char(to_number(substrb(vi_date_s, 1, 4)) -1) || to_char(12);
      
  ELSE--常规获取年月方式
    
      vc_open2_ym:=substrb(vi_date_s, 1, 4) ||
                 to_char(to_number(substrb(vi_date_s, 5, 2)) - 1, 'FM00');
  END IF;
  
  IF vc_open_ym = substrb(vi_date_s, 1, 6) THEN--插入年结表
    INSERT INTO bc_day
      (WORK_KEY,
       WORK_ID,
       COM_ID,
       SUBJECTSCODE,
       SUBJECTSID,
       SUBJECTSNAME,
       JOURNALNUM,
       VOUCHERDATE,
       BANK_NAME,
       BANK_STAFF,
       B_MONEY,
       S_MONEY,
       Z_MONEY,
       CB_MONEY,
       SORT,
       VOUCHERNUM,
       TAB_TYPE,
       YHZH,
       REASONTHING,
       CURRENCYID)
      SELECT dbms_random.string('x', 32),
             vi_work_id,
             vi_com_id,
             b.subjectsnumbers,
             a.SUBJECTSID,
             b.SUBJECTSNAME,
             0,
             ' ',
             ' ',
             ' ',
             sum(SCLDMONEY - SCLCMONEY),
             0,
             0,
             sum(SCLDMONEY - SCLCMONEY),
             1,
             '1',
             vi_type,
             ' ',
             ' ',
             CURRENCYID
        FROM DT_INV_DYCO a, dtcsubjects b
       WHERE a.COMPANYID = VI_COM_ID
         AND a.companyid = b.companyid
         and ((a.orgid = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
         AND b.subjectsNumbers between vi_acc_s AND vi_acc_e
         AND DYCO_YEAR = vc_open_ym
         and a.SUBJECTSID = b.SUBJECTSID
         AND SUBJECTSCATEGORY = vi_bc_type
           group by  b.subjectsnumbers,
             a.SUBJECTSID,
             b.SUBJECTSNAME,CURRENCYID;
  ELSE--插入月结表
    INSERT INTO bc_day
      (WORK_KEY,
       WORK_ID,
       COM_ID,
       SUBJECTSCODE,
       SUBJECTSID,
       SUBJECTSNAME,
       JOURNALNUM,
       VOUCHERDATE,
       BANK_NAME,
       BANK_STAFF,
       B_MONEY,
       S_MONEY,
       Z_MONEY,
       CB_MONEY,
       SORT,
       VOUCHERNUM,
       TAB_TYPE,
       YHZH,
       REASONTHING,
       CURRENCYID)
      SELECT dbms_random.string('x', 32),
             vi_work_id,
             vi_com_id,
             b.subjectsnumbers,
             a.SUBJECTSID,
             b.SUBJECTSNAME,
             0,
             ' ',
             ' ',
             ' ',
             sum(SCLDMONEY - SCLCMONEY),
             0,
             0,
             sum(SCLDMONEY - SCLCMONEY),
             1,
             1,
             vi_type,
             ' ',
             ' ',
             CURRENCYID
        FROM DT_INV_DMCO a, dtcsubjects b
       WHERE a.COMPANYID = VI_COM_ID
         AND a.companyid = b.companyid
         and ((a.org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
         AND b.subjectsNumbers between vi_acc_s AND vi_acc_e
         AND YEARMONTH = vc_open2_ym
         and a.SUBJECTSID = b.SUBJECTSID
         AND SUBJECTSCATEGORY = vi_bc_type
      group by  b.subjectsnumbers,
             a.SUBJECTSID,
             b.SUBJECTSNAME,CURRENCYID;
  END IF;
  
  select count(1) into vc_temp from bc_day;
  --处理期初，起始日期不是起始月份的第一天。
  IF substrb(vi_date_s, 7, 2) <> '01' THEN--如果不是一号。先统计从1号到昨天的
    vc_date_s := substrb(vi_date_s, 1, 6) || '01';
    vc_date_e := substrb(vi_date_s, 1, 6) ||
                 to_char(to_number(substrb(vi_date_s, 7, 2)) - 1, 'FM00');
    FOR i in vcur_get_vouchers LOOP
      UPDATE bc_day
         SET B_MONEY  = B_MONEY + nvl(i.org_amt_d, 0) - nvl(i.org_amt_c, 0),
             CB_MONEY = CB_MONEY + nvl(i.org_amt_d, 0) - nvl(i.org_amt_c, 0)
       WHERE work_id = vi_work_id
         AND COM_ID = VI_COM_ID
         and ((org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
         AND subjectscode between vi_acc_s AND vi_acc_e
         AND CURRENCYID = I.CURRENCYID
         and SUBJECTSID = i.SUBJECTSID
         AND sort = 1;

      IF SQL%NOTFOUND THEN
        INSERT INTO bc_day
          (WORK_KEY,
           WORK_ID,
           COM_ID,
           SUBJECTSCODE,
           SUBJECTSID,
           SUBJECTSNAME,
           JOURNALNUM,
           VOUCHERDATE,
           BANK_NAME,
           BANK_STAFF,
           B_MONEY,
           S_MONEY,
           Z_MONEY,
           CB_MONEY,
           SORT,
           TAB_TYPE,
           --VOUCHERNUM,
           YHZH,
           REASONTHING,
           CURRENCYID)
        VALUES
          (dbms_random.string('x', 32),
           vi_work_id,
           vi_com_id,
           i.SUBJECTSNUMBERS,
           i.SUBJECTSID,
           i.SUBJECTSNAME,
           0,
           ' ',
           ' ',
           ' ',
           nvl(i.org_amt_d, 0) - nvl(i.org_amt_c, 0),
           0,
           0,
           nvl(i.org_amt_d, 0) - nvl(i.org_amt_c, 0),
           1,
           --1,
           vi_type,
           ' ',
           ' ',
           ' ');
      END IF;
    END LOOP;
  END IF;
  
  --处理本期，起始日期不是起始月份的第一天。
  vc_date_s := vi_date_s;
  vc_date_e := vi_date_e;
IF vi_type = 'A' THEN
  FOR i in vcur_get_voucher_detail LOOP
    UPDATE bc_day
       SET S_MONEY     = B_MONEY + nvl(i.org_amt_d, 0),
           Z_MONEY     = Z_MONEY + nvl(i.org_amt_c, 0),
           JOURNALNUM  = i.JOURNALNUM,
           VOUCHERDATE = i.VOUCHERDATE,
           VOUCHERNUM  = i.VOUCHERSNUM,
           REASONTHING = i.REASONTHING
     WHERE work_id = vi_work_id
       AND COM_ID = VI_COM_ID
       and ((org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
       AND subjectscode between vi_acc_s AND vi_acc_e
       AND CURRENCYID = I.CURRENCYID
       and SUBJECTSID = i.SUBJECTSID
       AND sort = 1;
       
    IF SQL%NOTFOUND THEN
       dbms_output.put_line(nvl(i.org_amt_d, 0) - nvl(i.org_amt_c, 0));
      INSERT INTO bc_day
        (WORK_KEY,
         WORK_ID,
         COM_ID,
         SUBJECTSCODE,
         SUBJECTSID,
         SUBJECTSNAME,
         JOURNALNUM,
         VOUCHERDATE,
         BANK_NAME,
         BANK_STAFF,
         B_MONEY,
         S_MONEY,
         Z_MONEY,
         CB_MONEY,
         SORT,
         TAB_TYPE,
         VOUCHERNUM,
         YHZH,
         REASONTHING,
         CURRENCYID)
      VALUES
        (dbms_random.string('x', 32),
         vi_work_id,
         vi_com_id,
         i.SUBJECTSNUMBERS,
         i.SUBJECTSID,
         i.SUBJECTSNAME,
         I.JOURNALNUM,
         I.VOUCHERDATE,
         ' ',
         ' ',
         nvl(i.org_amt_d, 0) - nvl(i.org_amt_c, 0),
         nvl(i.org_amt_d, 0),
         nvl(i.org_amt_c, 0),
         nvl(i.org_amt_d, 0) - nvl(i.org_amt_c, 0),
         2,
         vi_type,
         I.VOUCHERSNUM,
         ' ',
         i.REASONTHING,
         I.CURRENCYID);
    END IF;
  END LOOP;
ELSE
    FOR i in vcur_get_vouchers_total LOOP
    UPDATE bc_day
       SET S_MONEY     = B_MONEY + nvl(i.org_amt_d, 0),
           Z_MONEY     = Z_MONEY + nvl(i.org_amt_c, 0),
           JOURNALNUM  =0,
           VOUCHERDATE = i.VOUCHERDATE,
           VOUCHERNUM  = 0,
           REASONTHING = ' '
     WHERE work_id = vi_work_id
       AND COM_ID = VI_COM_ID
       and ((org_id = vi_dept AND vi_dept <> 'ALL' ) or vi_dept = 'ALL')
       AND subjectscode between vi_acc_s AND vi_acc_e
       AND CURRENCYID = I.CURRENCYID
       and SUBJECTSID = i.SUBJECTSID
       AND sort = 1;
       
    IF SQL%NOTFOUND THEN
      INSERT INTO bc_day
        (WORK_KEY,
         WORK_ID,
         COM_ID,
         SUBJECTSCODE,
         SUBJECTSID,
         SUBJECTSNAME,
         JOURNALNUM,
         VOUCHERDATE,
         BANK_NAME,
         BANK_STAFF,
         B_MONEY,
         S_MONEY,
         Z_MONEY,
         CB_MONEY,
         SORT,
         TAB_TYPE,
         VOUCHERNUM,
         YHZH,
         REASONTHING,
         CURRENCYID)
      VALUES
        (dbms_random.string('x', 32),
         vi_work_id,
         vi_com_id,
         i.SUBJECTSNUMBERS,
         i.SUBJECTSID,
         i.SUBJECTSNAME,
         0,
         I.VOUCHERDATE,
         ' ',
         ' ',
         nvl(i.org_amt_d, 0) - nvl(i.org_amt_c, 0),
         0,
         0,
         nvl(i.org_amt_d, 0) - nvl(i.org_amt_c, 0),
         2,
         vi_type,
         0,
         ' ',
         ' ',
         I.CURRENCYID);
    END IF;
  END LOOP;
END IF ;

vd_last_amt:=0;
 FOR R IN vcur_sort_bcdays LOOP
    IF r.sort = 1 THEN
     vd_last_amt := r.B_MONEY + r.S_MONEY - r.Z_MONEY;
      UPDATE BC_DAY SET CB_MONEY = vd_last_amt WHERE ROWID = R.ROWID;
    ELSE
     UPDATE BC_DAY
         SET B_MONEY  = vd_last_amt,
            CB_MONEY = vd_last_amt + r.S_MONEY - r.Z_MONEY
       WHERE ROWID = R.ROWID;
      vd_last_amt := vd_last_amt + r.S_MONEY - r.Z_MONEY;
    END IF;
  END LOOP;

  FOR i in vcur_sort_bcdays LOOP
    update bc_day set sort = i.rowsort where rowid = i.rowid;
  END LOOP;

  COMMIT;
  --open P_CURSOR for select * from bc_day where WORK_ID=vi_work_id;
 if vi_bc_type='B' then
        open P_CURSOR for select b.voucherdate,b.subjectscode,b.subjectsname,c.codevalue,b.b_money,b.tab_type,b.sort,
                           b.s_money,b.z_money,b.cb_money,b.journalnum,b.vouchernum,b.reasonthing
                           from bc_day b,dtccode c where WORK_ID=vi_work_id and b.com_id=c.companyid and b.currencyid=c.codeid;
  else
        open P_CURSOR for select b.voucherdate,b.yhzh,b.bank_Name,b.BANK_STAFF,c.codevalue,b.subjectscode,b.subjectsname,b.B_Money,b.S_Money,
                           b.Z_Money,b.cb_Money,b.journalnum,b.vouchernum,b.reasonthing,b.tab_Type
                           from bc_day b,dtccode c where WORK_ID=vi_work_id and b.com_id=c.companyid and b.currencyid=c.codeid;
  end if;
END;


/

