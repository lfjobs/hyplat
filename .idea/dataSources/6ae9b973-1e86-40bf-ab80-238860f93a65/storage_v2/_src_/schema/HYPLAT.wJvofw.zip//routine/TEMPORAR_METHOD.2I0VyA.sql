create PROCEDURE          "TEMPORAR_METHOD" IS

num number;
cursor var_get_invt is
    select * from dt_inv_invt  i where i.invenquantity<300000;

BEGIN

    for i in var_get_invt  loop
         select goodsnumber into num from dtgoodsnum where cashierbillsid=i.inventoryid and rownum<=1 ;
         for ir in 2..i.INVENQUANTITY loop
             insert into dtgoodsnum(gnKey,gnID,companyID,goodsID,cashierBillsID,goodsBillsID,status,goodsCoding,goodsnumber)
                   values(get_Generate_Su('7','0','0'),get_table_ID('1','goodsNum'),i.companyID,i.goodsID,i.INVENTORYID,
                          '','03',i.GOODSCODING,num+ir-1);
          end loop;

    end loop;
END;


/

