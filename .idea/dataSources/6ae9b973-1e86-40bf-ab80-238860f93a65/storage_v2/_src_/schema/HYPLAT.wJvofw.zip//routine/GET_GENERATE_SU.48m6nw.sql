create FUNCTION "GET_GENERATE_SU" (
         type in varchar2, --类型  1:指定范围内的小数   2:指定范围内的整数  3:随机数字串  4:正态分布的随机数  5:随即字符串 6:随机日期 7:GUID
         initialRange in varchar2, --起始范围  取值范围
         endRange in  varchar2 --结束范围    长度
      ) return varchar2 --定义返回的数据类型
  is
      resu varchar2(1000);
  begin
  if type='1' then
    select dbms_random.value(to_number(initialRange),to_number(endRange)) into resu from dual;
    return resu;
  end if;
  if type='2' then
    select trunc(dbms_random.value(to_number(initialRange),to_number(endRange))) into resu from dual;
    return resu;
  end if;
  if type='3' then
    select substr(cast(dbms_random.value as varchar2(38)),3,to_number(endRange)) into resu from dual;
    return resu;
  end if;
  if type='4' then
    select dbms_random.normal into resu from dual;
    return resu;
  end if;
  if type='5' then
    select dbms_random.string(initialRange, to_number(endRange)) into resu from dual;
    return resu;
  end if;
  if type='6' then
    select to_date(2454084+TRUNC(DBMS_RANDOM.VALUE(0,365)),'J') into resu from dual;
    return resu;
  end if;
  if type='7' then
    select sys_guid() into resu from dual;
    return resu;
  end if;
  end;


/

