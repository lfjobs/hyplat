create view DT_HY_GOODSVO as
select
t.organizationID,t.departmentID,t.contactUserID,t.ccompanyID,t.billsType,t.pbillstypeid,t.journalNum,t.staffID,t.cashierDate,hh.archivesnum,hh.archivesdate,hh.deparchivesnum,hh.deparchivesdate,
t.discountMoney,t. afterDiscount,t.dataDepotID,t.dataDepotName,t.bankDepotID,t.bankDepotName,t.accountNum,t.status as cashierStatus,t.taxstatus,
t.taxstatus2,t.input, t.competent,t.manager,t.financial,t.taxdate,t.responsible,t.accountant,t.cashier,t.companyname,t.departmentname,t.staffname,
t.staffcode recordcode,t.ccompanyname,t.companyAddr,t.companyTel,t.cresponsible,t.responsibleTel,t.industryType,t.ctusername contactUserName,t.staffIdentityCard,
t.reference tel,t.phone,t.referenceCode userQq,t.referenceOrganization email,t.staffaddress userAddr,t.userAccountNum,t.contactConnections,t.status,t.consultstatus,s.batchnumber,s.perioddate,s.remindedcontent,
cc.goodscoding,cc.goodsname,cc.typeid,cc.variableid,cc.standard,cc.model,cc.mnemonicCode,cc.defaultstorage,
cc.goodsVariable,cc.variable1ID,cc.variable2ID,cc.variable3ID,cc.variable4id,
s.goodsBillsID,s.goodsBillsKey,s.companyID,s.cashierBillsID,s.goodsID,s.startDate,s.endDate,s.costType,s.payType,s.priceManage,
s.weight,s.boxStandard,s.price,s.quantity,s.money,s.subjectsID,s.subjectsName,s.depotType,s.depotID,s.depotName,s.loan,s.forLoan,s.direction,s.reasonthing,
s.balance,s.logistics,s.moneySpent,s.identifyingCode,s.goodsVariableID
,t.companybanknum,t.pcompanyid,s.goodsnomber
--from  dtGoodsBills s,dtgoodsmanage cc ,dtcashierbillsvo t
from  dt_history_goodsbills s
left join dtgoodsmanage cc on cc.goodsID=s.goodsid
left join dt_history_cashierbills t on t.cashierbillsid=s.cashierbillsid
left join dt_history_relation hh on hh.cashierbillsid=t.cashierbillsid


/

