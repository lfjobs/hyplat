create PROCEDURE          "get_product_mix" (ppID varchar2,          --产品ID
                                            goodsname varchar2,     --产品名称
                                            productPID varchar2,    --产品父ID
                                            cashierBillsID varchar2 --单据ID
                                            var_list  OUT TESTPACKAGE.TEST_CURSOR
                                            ) IS
var_sql    varchar(100);
var_sorting varchar(100);

begin

   var_sql='select pp.ppid,pp.parentid,pp.hierarchical,pp.goodsname,pp.quantity,i.invenquantity,a.outgoingQuantity';
   var_sql:='a.status,a.startTime,a.endTime,a.coachTeaching,a.studentLearningLog,a.teachingSupervisor';
   var_sql:=' from (select p.goodsname,p.ppid,p.parentId,p.quantity,p.productCode,p.hierarchical';
   var_sql:=' from dt_ProductPackaging p connect by p.parentId = prior p.ppid  start with p.ppID = ';
   var_sql:=ppID|'and p.goodsname='|goodsname|') pp';
   var_sql:=' left join dt_inv_invt i on pp.ppid=i.productid and i.warehousename=半成品库 left join dtAssembly';
   var_sql:=' a on a.productID=pp.ppid and a.productPID='|productPID|' and a.cashierBillsID='|cashierBillsID;

   select sorting into var_sorting from dt_productpackaging where ppid=productPID;

   if var_sorting='1' then
      var_sql:=' order by sorting desc';
   end if;


END var_sql for sql;


/

