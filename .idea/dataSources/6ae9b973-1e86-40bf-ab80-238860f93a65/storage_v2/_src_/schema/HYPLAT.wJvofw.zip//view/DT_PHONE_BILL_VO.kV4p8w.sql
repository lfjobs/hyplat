create view DT_PHONE_BILL_VO as
SELECT C.CASHIERBILLSID,
       C.CASHIERBILLSKEY,
       BILLSTYPE,
       C.JOURNALNUM,
       TRADE_NO,
       CONTACTUSERID,
       CTUSERNAME,
       C.COMPANYID,
       C.COMPANYNAME,
       PRICESUB,
       CASHIERDATE,
       OA_SCCID,
       FKSTATUS,
       C.WFSTATUS4,
       O.EXTENDEDTIME,
       C.PROJECTNAME,
       CUS.SCCID SELL_SCCID,
       CUS.ACCOUNT SELL_ACCOUNT,
       RF.STAFFNAME SELL_STAFFNAME,
       C.REMARK,
       C.PRIVATEROOM,
       C.MEALNUM,
       S.SUPPLIERSTATUS,
       S.PAYSTATUS,
       T.CGSCOMID,
       T.CGSCOMNAME,
       O.RECEIVENAME,
       O.RECEIVETEL,
       O.RECEIVEADDRESS,C.Goodscoding,C.Goodsname
  FROM DTCASHIERBILLS C
  LEFT JOIN DT_STATUS S
    ON C.CASHIERBILLSID = S.CASHIERBILLSID
  LEFT JOIN DT_CB_A_TRANSFERPAY T
    ON C.CASHIERBILLSID = T.CASHIERBILLSID
   AND T.CBATPID IS NOT NULL
  LEFT JOIN DT_ORDER_BILL_ADD O
    ON C.CASHIERBILLSID = O.OA_BILL_ID
  LEFT JOIN T_ESHOP_CUSCOM CUS
    ON C.COMPANYID = CUS.COMPANYID
  LEFT JOIN DT_HR_STAFF RF
    ON RF.STAFFID = CUS.STAFFID
 WHERE  C.BILLSTYPE = '项目收入预算单'
   AND C.STATUSBILL = '04'
   AND C.STATUS != '99'
/

comment on column DT_PHONE_BILL_VO.CASHIERBILLSID is '业务主键'
/

comment on column DT_PHONE_BILL_VO.BILLSTYPE is '单据类别'
/

comment on column DT_PHONE_BILL_VO.JOURNALNUM is '订单编号'
/

comment on column DT_PHONE_BILL_VO.TRADE_NO is '公司ID'
/

comment on column DT_PHONE_BILL_VO.CONTACTUSERID is '用户ID'
/

comment on column DT_PHONE_BILL_VO.CTUSERNAME is '用户Name'
/

comment on column DT_PHONE_BILL_VO.COMPANYID is '供货商id'
/

comment on column DT_PHONE_BILL_VO.COMPANYNAME is '供货商名称'
/

comment on column DT_PHONE_BILL_VO.PRICESUB is '价钱总和'
/

comment on column DT_PHONE_BILL_VO.CASHIERDATE is '制单时间'
/

comment on column DT_PHONE_BILL_VO.OA_SCCID is '用户账号id'
/

comment on column DT_PHONE_BILL_VO.FKSTATUS is '状态 00:已付款 01:未付款 02:已出库正在物流 03:用户已收货 04:已分配金币 05:申请退货 06:同意退货 07:退货中 08:确认收货09:转账确认'
/

comment on column DT_PHONE_BILL_VO.WFSTATUS4 is '在线支付:00微信支付，01，支付宝支付，02银联支付 03:线下转账'
/

comment on column DT_PHONE_BILL_VO.EXTENDEDTIME is '收货延长时间'
/

comment on column DT_PHONE_BILL_VO.PROJECTNAME is '项目名称'
/

comment on column DT_PHONE_BILL_VO.SELL_SCCID is '商家账号sccId'
/

comment on column DT_PHONE_BILL_VO.SELL_ACCOUNT is '商家账号account'
/

comment on column DT_PHONE_BILL_VO.SELL_STAFFNAME is '商家账户姓名'
/

comment on column DT_PHONE_BILL_VO.REMARK is '备注留言'
/

comment on column DT_PHONE_BILL_VO.PRIVATEROOM is '餐桌'
/

comment on column DT_PHONE_BILL_VO.MEALNUM is '取餐号'
/

comment on column DT_PHONE_BILL_VO.SUPPLIERSTATUS is '供应商状态/采购商状态 00:订单初始 01:拣货 02：发货 03：送货 04：物流 05:签收 06：收货 07：验货 08：入库 09：分金币'
/

comment on column DT_PHONE_BILL_VO.PAYSTATUS is '支付状态 01：未支付 02：欠款 03：已支付'
/

comment on column DT_PHONE_BILL_VO.CGSCOMID is '采购商公司id'
/

comment on column DT_PHONE_BILL_VO.CGSCOMNAME is '采购商公司名称'
/

comment on column DT_PHONE_BILL_VO.RECEIVENAME is '收货人'
/

comment on column DT_PHONE_BILL_VO.RECEIVETEL is '收货电话'
/

comment on column DT_PHONE_BILL_VO.RECEIVEADDRESS is '收货地址'
/

comment on column DT_PHONE_BILL_VO.GOODSCODING is '设备编号'
/

comment on column DT_PHONE_BILL_VO.GOODSNAME is '设备名称'
/

