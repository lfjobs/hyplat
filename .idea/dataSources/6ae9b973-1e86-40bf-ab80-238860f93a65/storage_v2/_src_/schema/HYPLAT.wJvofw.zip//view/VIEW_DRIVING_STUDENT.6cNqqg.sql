create view VIEW_DRIVING_STUDENT as
select  ddp.drivingprincipalkey,dhs.staffid,dhs.staffcode,dhs.recordcode,dhs.staffname,dhs.usednmae,dhs.reference,
dhs.sex,dhs.birthday,dhs.nativeplace,dhs.nationality,dhs.nation,dhs.staffidentitycard,
ddp.companyid,dc.companyname,ddp.registrationdate,ddp.studentperiods,ddpt.docstatus,ddpt.studentstatus,ddp.istrues,ddpt.testresult,
ddc.printcount,
ddd.states,(case
 when ddpt.docstatus='01' and ddpt.studentstatus='04' then '未报开学'
 when ddpt.docstatus='01' and ddpt.studentstatus='05' and  (ddp.istrues is null or ddp.istrues ='不合格') then '已报开学'
 when ddpt.docstatus='01' and ddpt.studentstatus='03' and  ddp.istrues='合格' then '已预约培训'
 when ddpt.docstatus='01' and ddpt.studentstatus='08' then '已培训'
 when ddpt.docstatus='01' and ddpt.studentstatus = '06' and ddpt.testresult is  null   then '已约考'
 when ddpt.docstatus='01' and ddpt.studentstatus = '06' and ddpt.testresult is not null then '不合格'
 when ddpt.docstatus='01' and ddpt.studentstatus = '07'  then '已合格'
 when ddpt.docstatus !='01' and ddpt.studentstatus = '02'  then '未预约培训'
 when ddpt.docstatus !='01' and ddpt.studentstatus = '03'  then '已预约培训'
 when ddpt.docstatus !='01' and ddpt.studentstatus = '05'  then '已培训'
 when ddpt.docstatus !='01' and ddpt.studentstatus = '06' and ddpt.testresult is  null   then '已约考'
 when ddpt.docstatus !='01' and ddpt.studentstatus = '06' and ddpt.testresult is not null then '不合格'
 when ddpt.docstatus !='01' and ddpt.studentstatus = '07'  then '已合格'
 else '未定义' end) studentstatusnote,ddpt.inputtime,ddm.organizationid ddmorganizationid,ddm.organizationname ddmorganizationname,
 ddm.signupdate ddmsignupdate,ddm.referrerid ddmreferrerid,ddm.referrer ddmreferrer,dhsc1.contactWay
from   dt_driving_principal ddp
left join  dt_driving_principal_type  ddpt  on ddp.drivingprincipalid=ddpt.drivingprincipalid
left join dt_hr_staff dhs on ddp.studentid=dhs.staffid
left join dt_driving_deal ddd on ddp.studentid=ddd.staffid and ddd.companyid= ddp.companyid
left join dt_drivingcard ddc on ddp.studentid=ddc.studentid and ddc.companyid=ddp.companyid
left join dtcompany dc on ddp.companyid=dc.companyid
left join DT_DRIVING_AllINFORMATION ddm on ddm.staffid=ddp.studentid and ddm.companyid=ddp.companyid and ddm.dataTitle='04'

left join ( select * from (select dhsc.staffid, dhsc.contactWay,
 row_number() over(partition by dhsc.staffid order by dhsc.contactdate desc) rn
  from dt_hr_staff_contact dhsc
  where  dhsc.contacttype='scode20100426c8rdqacjae0000000002' ) where rn=1
)  dhsc1 on ddp.studentid=dhsc1.staffid


/

