create PROCEDURE PRO_INV IS

  PPID     DTGOODSBILLS.PPID%TYPE; --产品ID
  QUANTITY VARCHAR2(50);
  COUNTNUM NUMBER;

  CURSOR VCUR_GET_GOODS IS
    SELECT P.PPID FROM DT_PRODUCTPACKAGING P;

BEGIN

  OPEN VCUR_GET_GOODS;
  LOOP
    FETCH VCUR_GET_GOODS
      INTO PPID;
    EXIT WHEN VCUR_GET_GOODS%NOTFOUND;
  
    SELECT COUNT(*)
      INTo COUNTNUM
      FROM DT_INV_INVT I
     WHERE I.PRODUCTID = PPID;
  
    IF COUNTNUM = 1 THEN
      SELECT I.INVENQUANTITY
        INTO QUANTITY　FROM DT_INV_INVT I
       WHERE I.PRODUCTID = PPID;
    
      IF QUANTITY <= 0 THEN
        QUANTITY := '1';
      END IF;
    
      UPDATE DT_PRODUCTPACKAGING P
         SET P.INVNUM = QUANTITY
       WHERE P.PPID = PPID;
    
    elsif COUNTNUM > 1 THEN
      Begin
        SELECT MAX(I.INVENQUANTITY)
          INTO QUANTITY　FROM DT_INV_INVT I
         WHERE I.PRODUCTID = PPID;
      EXCEPTION
              When OTHERS then
          --处理逻辑
          dbms_output.put_line(ppid);
        
      End;
      
      UPDATE DT_PRODUCTPACKAGING P
         SET P.INVNUM = QUANTITY
       WHERE P.PPID = PPID;
    END IF;
  
    FETCH VCUR_GET_GOODS
      INTO PPID;
  END LOOP;
  CLOSE VCUR_GET_GOODS;
exception
  when others then
    dbms_output.put_line('**Error line: ' ||
                         dbms_utility.format_error_backtrace());
    dbms_output.put_line('**Error code: ' || SQLCODE);
    dbms_output.put_line('**Error info: ' || SQLERRM);
  
    ROLLBACK;
END PRO_INV;
/

