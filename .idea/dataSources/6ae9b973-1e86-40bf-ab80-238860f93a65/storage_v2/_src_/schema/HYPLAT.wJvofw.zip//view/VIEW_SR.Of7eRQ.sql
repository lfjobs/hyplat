create view VIEW_SR as
select t."RESPONSIBILITIESKEY",
t."RESPONSIBILITIESID",
t."COMPANYID",
t."STAFFID",
t."ORGANIZATIONID",
t."DEPARTMENTID",
t."ORGANIZATIONPID",
t."ORGANIZATIONCID",
t."RESPONSIBILITIESNUM",
t."RECORDNUM",
t."STARTDATE",
t."ENDDATE",
t."POSTNAME",
t."DUTYNAME",
t."POSTMANAGE",
t."FILENUM",
t."COMPANYNAME",
t."MANAGESCOPE",
t."JOBCONTENT1",
t."JOBCONTENT2",
t."JOBCONTENT3",
t."JOBCONTENT4",
t."JOBCONTENT5",
b.staffname staffname,
b.staffcode staffcode,
b.photo photo,
(select a.companyname from dtcompany a where a.companyid=t."COMPANYID" union select b.organizationname from dtcorganization b where b.organizationid=t."COMPANYID") companyIDName,
(select a.companyname from dtcompany a where a.companyid=t."DEPARTMENTID" union select b.organizationname from dtcorganization b where b.organizationid=t."DEPARTMENTID") departmentIDName,
(select a.companyname from dtcompany a where a.companyid=t."ORGANIZATIONPID" union select b.organizationname from dtcorganization b where b.organizationid=t."ORGANIZATIONPID") organizationPIDName,
(select a.companyname from dtcompany a where a.companyid=t."ORGANIZATIONCID" union select b.organizationname from dtcorganization b where b.organizationid=t."ORGANIZATIONCID")organizationCIDName
from dt_hr_staff b,
dtresponsibilities t
where  b.staffid = t.staffid
and exists
(select s.staffid from view_sc s where t.companyid = s.companyid and t.staffid = s.staffid)


/

