create FUNCTION          "FUN_GET_OPENYM" (vc_companyid in varchar2,
                                          vc_ym        in varchar2)
  RETURN CHAR AS
  vc_yms char(6);
BEGIN
  BEGIN
    SELECT STARTDATE
      INTO vc_yms
      FROM DT_INV_FISPERIOD
     WHERE companyid = vc_companyid
       AND vc_ym between startdate AND enddate;
  EXCEPTION
    WHEN OTHERS THEN
      vc_yms := ' ';
  END;
  RETURN vc_yms;
END;


/

