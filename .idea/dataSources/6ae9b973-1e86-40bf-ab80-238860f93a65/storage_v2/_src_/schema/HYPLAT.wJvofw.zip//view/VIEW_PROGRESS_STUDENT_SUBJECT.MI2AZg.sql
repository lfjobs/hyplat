create view VIEW_PROGRESS_STUDENT_SUBJECT as
select ddpt.principaltypekey compositekey ,ddp.studentid,dhs.recordcode studentcode,ddp.registrationdate registrationdate,upper(ddp.registrationcarname) registrationcarname,
ddp.schoolopendate schoolopendate,ddp.studentname studentname,
ddp.studentsex studentsex,ddp.studentphone studentphone
,ddp.studentcard studentcard,ddp.barcode barcode,
ddpt.coachname coachname,ddp.companyid  companyid,'  ' complete,
ddpt.docstatus docstatus,ever.time finished ,allsc.quantity total
from dt_driving_principal ddp
left join dt_driving_principal_type ddpt on ddpt.drivingprincipalid=ddp.drivingprincipalid
left join dt_hr_staff dhs on dhs.staffid=ddp.studentid
left join view_progress_student_ever ever on ddp.companyid=ever.companyid and ddp.studentid=ever.ddsrstudentid and ddpt.docstatus=ever.subject
left join view_progress_student_all alls on ddp. companyid=alls .companyid and upper (ddp. registrationcarname)=alls .type and ddpt.docstatus =alls. subject
left join dt_ProductPackaging allsf on ddp. companyid=allsf.companyid and ddp.registrationcarid=allsf.goodsid
left join dt_ProductPackaging allsc on allsf.ppid=allsc.parentid and decode(allsc.goodsname,'科目一','01','科目二','02','科目三','03','04')=ddpt.docstatus
order by  ddp.registrationdate desc nulls last


/

