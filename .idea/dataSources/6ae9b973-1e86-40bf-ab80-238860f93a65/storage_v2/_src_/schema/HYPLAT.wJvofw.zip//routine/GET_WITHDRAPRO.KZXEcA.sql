create PROCEDURE GET_WITHDRAPRO (SCCID IN VARCHAR, STAFFID IN VARCHAR,
																							WFJ_USER IN VARCHAR,
																							JNUMORDER IN VARCHAR,
																							MONEY IN NUMBER, 
																							TRADE_NO IN VARCHAR, 
																							METHODPAY IN VARCHAR, 
																							WITHDATE IN DATE, 
																							MESSGE OUT VARCHAR)
IS

V_WFJ_COMID DTCOMPANY.COMPANYID%TYPE;
V_WFJ_WFJ_COMNAME DTCOMPANY.COMPANYNAME%TYPE;
V_CUS_COMID DTCOMPANY.COMPANYID%TYPE;
V_STAFFNAME DT_HR_STAFF.STAFFNAME%TYPE;
V_STAFF_CODE DT_HR_STAFF.RECORDCODE%TYPE;
V_COMID DTCOMPANY.COMPANYID%TYPE;
V_COMNAME DTCOMPANY.COMPANYNAME%TYPE;
V_COMGN DTCOMPANY.GROUPCOMPANYSN%TYPE;
V_STANAME DT_HR_STAFF.STAFFNAME%TYPE;

V_CBID DTCASHIERBILLS.CASHIERBILLSID%TYPE ;
V_CBID2 DTCASHIERBILLS.CASHIERBILLSID%TYPE;
V_CBID3 DTCASHIERBILLS.CASHIERBILLSID%TYPE;
V_CBID4 DTCASHIERBILLS.CASHIERBILLSID%TYPE;
V_PZID  DTCASHIERBILLS.JOURNALNUM%TYPE;
V_PZID2 DTCASHIERBILLS.JOURNALNUM%TYPE;
V_PZID3 DTCASHIERBILLS.JOURNALNUM%TYPE;
V_PZID4 DTCASHIERBILLS.JOURNALNUM%TYPE;

V_AMT NUMBER;

V_NO VARCHAR2(50 CHAR);

V_PPID_GOLD VARCHAR2(50 CHAR);
V_PPID_BANK VARCHAR2(50 CHAR);
V_GoodsID_GOLD VARCHAR2(50 CHAR); 
V_GoodsNum_GOLD VARCHAR2(50 CHAR);
V_GoodsName_GOLD VARCHAR2(200 CHAR);
V_Standard_GOLD VARCHAR2(50 CHAR);
V_VariableID_GOLD VARCHAR2(50 CHAR);
V_Weight_GOLD VARCHAR2(50 CHAR);




BEGIN
	  V_COMID :='COMPANY201009046VXDYZY4WG0000000025';
		V_COMNAME := '北京天太世统科技有限公司';
		V_COMGN :='GROUPCOMPANY20120523G3VR9PXHZD0000000021';
	
		
		
		SELECT EC.COMPANYID INTO V_WFJ_COMID FROM T_ESHOP_CUSCOM EC WHERE EC.SCCID = SCCID;
		
		IF V_WFJ_COMID IS NULL THEN
			SELECT S.COMPANYID INTO  V_WFJ_COMID
			FROM (SELECT T.STAFFID, T.COMPANYID, T.STATE,T.SUPERIORAGENT,T.PSEUDO_COMPANY_NAME,T.CUSTYPE,T.SCCID,T.ACCOUNT, ROWNUM NO
			FROM T_ESHOP_CUSCOM T
			WHERE T.STATE='2'
			START WITH T.SCCID = SCCID
			CONNECT BY PRIOR T.SUPPERSCCID = T.SCCID) S WHERE S.NO = '1'; ---ret
			IF V_WFJ_COMID IS NULL THEN
				MESSGE := '有参数为空';
				RETURN;
			END IF;
		END IF;

	SELECT C.COMPANYNAME
			INTO  V_WFJ_WFJ_COMNAME
			FROM DTCOMPANY C
			WHERE C.COMPANYID = V_WFJ_COMID;		
			
			
	SELECT S.STAFFNAME,S.RECORDCODE
			INTO  V_STAFFNAME,V_STAFF_CODE
			FROM DT_HR_STAFF S
			WHERE S.STAFFID = STAFFID;		
	IF V_STAFFNAME IS NULL THEN
			MESSGE := '请先完善用户信息！！！';
			RETURN;
	END IF;
			
	V_PZID := FUN_GET_BILL_ID();
	V_PZID2 := FUN_GET_BILL_ID();
	V_PZID3 := FUN_GET_BILL_ID();
	V_PZID4 := FUN_GET_BILL_ID();
	
	
	V_AMT := MONEY + 3;
	SELECT PP.PPID,PP.GoodsID,PP.GoodsNum, PP.GoodsName,PP.Standard,PP.VariableID,PP.Weight
		INTO V_PPID_GOLD ,V_GoodsID_GOLD,V_GoodsNum_GOLD,V_GoodsName_GOLD,V_Standard_GOLD,V_VariableID_GOLD,V_Weight_GOLD
		FROM DT_PRODUCTPACKAGING PP 
		WHERE PP.GOODSNAME ='微分金金币' AND PP.COMPANYID=V_COMID;
	SELECT PP.PPID INTO V_PPID_BANK FROM DT_PRODUCTPACKAGING PP WHERE PP.GOODSNAME ='银行存款' AND PP.COMPANYID=V_COMID;
	IF V_PPID_GOLD IS NULL THEN
		MESSGE := '1操作失误了！！！';
		RETURN;
	END IF;
	IF V_PPID_BANK IS NULL THEN
		MESSGE := '2操作失误了！！！';
		RETURN;
	END IF;
			V_CBID :=FUN_GET_ID('CASHIERBILLS');
	            INSERT INTO DTCASHIERBILLS
              (CASHIERBILLSKEY,
               CASHIERBILLSID,
               COMPANYID,
               BILLSTYPE,
               JOURNALNUM,
               STAFFID,
               STAFFNAME,
               CASHIERDATE,    --WITHDATE
               STATUS, --16
               COMPANYNAME, --V_WFJ_WFJ_COMNAME
               PROID,--003
               PROJECTNAME, --金币兑现
               INPUTID, --STAFFID
               INPUTNAME,--V_STAFFNAME
							 InputCompanyid,--V_WFJ_COMID
							 InputCompanyName,--V_WFJ_WFJ_COMNAME
               APPSTYLE,--07
               PRICESUB,--AMT
               CCOMPANYID,--company201009046vxdyzy4wg0000000025
               CCOMPANYNAME,--北京天太世统科技有限公司
							 CompanyAddr,--东直门外大街42号宇飞大厦801室
							 CompanyTel,--010-64167113
							 Cresponsible,--刘太平
							 ResponsibleTel,--15810799888
               STATUSBILL,--04
               JNUMORDER,--JNUMORDER
							 Trade_no,--JNUMORDER
							 WfStatus4)--METHODPAY
            VALUES
              (DBMS_RANDOM.STRING('X', 32),
               V_CBID,
               V_WFJ_COMID,
               '金币出库单',
               FUN_GET_BILL_ID(),
               STAFFID,
               V_STAFFNAME, --会员名称
               WITHDATE,
               '16',
               V_WFJ_WFJ_COMNAME, --公司名称
               '003',
               '金币兑现',
               STAFFID, --集团组织机构ID
               V_STAFFNAME,
               V_WFJ_COMID,
               V_WFJ_WFJ_COMNAME,
               '07',
               V_AMT,
               'company201009046vxdyzy4wg0000000025',
               '北京天太世统科技有限公司',
               '东直门外大街42号宇飞大厦801室',
               '010-64167113',
							 '刘太平',
							 '15810799888',
							 '04',
							 JNUMORDER,
							 JNUMORDER,
							 METHODPAY);
							 
		INSERT INTO DTGOODSBILLS
		(GOODSBILLSKEY,
		CashierBillsID, --V_CBID
		 GoodsBillsID, --FUN_GET_ID('GoodsBills'),
		 GoodsID,--V_GoodsID_GOLD,
		 GoodsNum,--V_GoodsNum_GOLD,
		 GoodsName,--V_GoodsName_GOLD,
		 Standard,--V_Standard_GOLD,
		 GoodsVariableID,--V_VariableID_GOLD,
		 Weight,--V_Weight_GOLD,
		 Price,--0.01,
		 Quantity,--V_AMT*100,
		 Money,--V_AMT,
		 StartDate,--
		 EndDate,--
		 BatchNumber,--
		 PeriodDate,--
		 RemindedContent,--
		 CostType,--
		 PayType,--
		 PriceManagE,--
		 KcStatus,--
		 Goodstatus,--
		 SortCode,--
		 PpID--V_PPID_GOLD
		)
		VALUES
       (DBMS_RANDOM.STRING('X', 32),
			 V_CBID,
			 FUN_GET_ID('GoodsBills'),
			 V_GoodsID_GOLD,
			 V_GoodsNum_GOLD,
			 V_GoodsName_GOLD,
			 V_Standard_GOLD,
			 V_VariableID_GOLD,
			 V_Weight_GOLD,
			 '0.01',
			 V_AMT*100,
			 V_AMT,
			 NULL,
			 NULL,
			 NULL,
			 NULL,
			 NULL,
			 NULL,
			 NULL,
			 NULL,
			 NULL,
			 NULL,
			 NULL,
			 V_PPID_GOLD);
							 V_CBID2 :=FUN_GET_ID('CASHIERBILLS');
							 INSERT INTO DTCASHIERBILLS
              (CASHIERBILLSKEY,
               CASHIERBILLSID,
               COMPANYID,
               BILLSTYPE,
               JOURNALNUM,
               STAFFID,
               STAFFNAME,
               CASHIERDATE,    --WITHDATE
               STATUS, --16
               COMPANYNAME, --V_WFJ_WFJ_COMNAME
               PROID,--003
               PROJECTNAME, --金币兑现
               INPUTID, --STAFFID
               INPUTNAME,--V_STAFFNAME
							 InputCompanyid,--V_WFJ_COMID
							 InputCompanyName,--V_WFJ_WFJ_COMNAME
               APPSTYLE,--07
               PRICESUB,--AMT
               CCOMPANYID,--company201009046vxdyzy4wg0000000025
               CCOMPANYNAME,--北京天太世统科技有限公司
							 CompanyAddr,--东直门外大街42号宇飞大厦801室
							 CompanyTel,--010-64167113
							 Cresponsible,--刘太平
							 ResponsibleTel,--15810799888
               STATUSBILL,--04
               JNUMORDER,--JNUMORDER
							 Trade_no,--JNUMORDER
							 WfStatus4)--METHODPAY
            VALUES
              (DBMS_RANDOM.STRING('X', 32),
               V_CBID,
               V_WFJ_COMID,
               '收款单',
               FUN_GET_BILL_ID(),
               STAFFID,
               V_STAFFNAME, --会员名称
               WITHDATE,
               '45',
               V_WFJ_WFJ_COMNAME, --公司名称
               '003',
               '金币兑现',
               STAFFID, --集团组织机构ID
               V_STAFFNAME,
               V_WFJ_COMID,
               V_WFJ_WFJ_COMNAME,
               '07',
               V_AMT,
               'company201009046vxdyzy4wg0000000025',
               '北京天太世统科技有限公司',
               '东直门外大街42号宇飞大厦801室',
               '010-64167113',
							 '刘太平',
							 '15810799888',
							 '04',
							 JNUMORDER,
							 JNUMORDER,
							 METHODPAY);
							 
							 
							 
END;
/

