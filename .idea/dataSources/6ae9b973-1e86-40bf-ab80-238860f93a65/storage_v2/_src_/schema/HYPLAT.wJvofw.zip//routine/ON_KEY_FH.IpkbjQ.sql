create procedure on_Key_fh(vi_com_id          varchar2, --公司id
                                      fh_staff_id        varchar2, --发货人的staffid 
                                      vi_cashi_id        varchar2,
                                      parameter          OUT varchar2,
                                      ca_journalNum      out varchar2,
                                      goods_goodsbillsid out varchar2) IS
  ddid                 DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  jornum               dtcashierbills.journalnum%type;
  new_ca_id            DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  new_go_id            dtgoodsbills.goodsbillsid%type;
  bill_type            varchar2(100);
  potID                varchar2(50);
  potName              varchar2(50);
  inventory_ID         varchar2(50);
  goods_id             varchar2(50);
  nnber                number;
  salesInventoryId     varchar2(50);
  logisticsInventoryId varchar2(50);
  pro_com_id           dtcompany.companyid%type;
  com_name             dtcompany.companyname%type;
  gn_id                dtcompany.groupcompanysn%type;
  ca_zt                dtcashierbills.status%type;

  fh_staff_name varchar2(50); --发货人的姓名      

  goods_com_id    varchar2(50);
  goods_cashi_id1 varchar2(50);
  goods_cashi_id2 varchar2(50);
  countnum        number;

  money_jisuan number;

  cursor vcur_get_vouchers is
    select cb.cashierbillsid, cb.journalnum
      from dtCashierBills cb, dt_order_bill_add o
     where cb.cashierbillsid = o.oa_bill_id
       and cb.billsType = '项目收入预算单'
       and o.oa_gys_id = vi_com_id
       and cb.fkStatus = '00'
       and cb.statusbill = '04'
       and cb.status != '27'
       and cb.cashierbillsid = vi_cashi_id
       and cb.status != '99'
     order by cb.cashierDate DESC;

  cursor var_get_goodsbills is
    select g.goodsbillsid,
           g.goodsid,
           g.quantity,
           g.money,
           g.depotID,
           g.standard,
           g.price,
           g.goodsnum,
           g.typeid,
           g.goodsname,
           g.depotname,
           g.ppid,
           p.companyid
      from dtgoodsbills g
      left join dt_productpackaging p
        on g.ppid = p.ppid
     where g.cashierbillsid = ddid
       and g.canstatus is null
     order by p.companyid;

  /*cursor var_get_goodsNum is
  select *
    from dtgoodsnum num
   where num.goodsid = goods_id
     and num.status = '03'
     and num.cashierbillsid = salesInventoryId
     and rownum <= nnber;*/

begin
  goods_com_id := ' ';
  parameter    := '00';
  open vcur_get_vouchers;
  fetch vcur_get_vouchers
    into ddid, jornum;
  LOOP
    EXIT WHEN vcur_get_vouchers%notFOUND;
  
    select staffname
      into fh_staff_name
      from dt_hr_staff
     where staffid = fh_staff_id;
  
    update dt_order_bill_add
       set sendId = fh_staff_id, sName = fh_staff_name, fhDate = sysdate
     where oa_bill_id = ddid;
  
    for goods in var_get_goodsbills loop
    
      select depotID, depotName
        into potID, potName
        from dtDepotManage
       where companyID = goods.companyid
         and depotPID = '001'
         and depotName = '销售库'
         and depotState = '00';
    
      select count(*)
        into nnber
        from dt_inv_invt i
       where i.companyid = goods.companyid
         and i.goodsid = goods.goodsid
         and i.productid = goods.ppid
         and i.warehouse = potID
         and i.invenquantity >= goods.quantity
         and i.invenquantity > 0;
    
      if nnber = 0 then
        parameter := '01';
      
        select journalNum
          into ca_journalNum
          from dtcashierbills
         where cashierbillsid = ddid;
        goods_goodsbillsid := goods.goodsbillsid;
        GOTO here;
      end if;
    
      --判断该物品的公司和上个物品的公司是否相同，若不同则生成单据表信息
      if goods_com_id != goods.companyid then
        for i in 1 .. 2 loop
          if i = 1 then
            bill_type := '销售出库单';
            ca_zt     := '19';
            select c.companyid, c.companyname, c.groupcompanysn
              into pro_com_id, com_name, gn_id
              from dtcompany c
             where c.companyid = goods.companyid;
            goods_cashi_id1 := fun_get_id('cashierTally');
            new_ca_id       := goods_cashi_id1;
          end if;
          if i = 2 then
            bill_type       := '物流入库单';
            ca_zt           := '15';
            pro_com_id      := 'company201009046vxdyzy4wg0000000025';
            com_name        := '北京天太世统科技有限责任公司';
            gn_id           := 'groupcompany20120523G3VR9PXHZD0000000021';
            goods_cashi_id2 := fun_get_id('cashierTally');
            new_ca_id       := goods_cashi_id2;
          end if;
        
          --销售出库单
          INSERT INTO dtCashierBills
            (cashierbillskey,
             cashierbillsid,
             companyid,
             contactuserid,
             ccompanyid,
             billstype,
             journalnum,
             staffid,
             cashierdate,
             discountmoney,
             afterdiscount,
             status,
             datadepotid,
             datadepotname,
             responsible,
             accountant,
             cashier,
             bankdepotid,
             bankdepotname,
             accountnum,
             useraccountnum,
             contactconnections,
             phone,
             companybanknum,
             pcompanyid,
             depstatue,
             taxstatus,
             taxstatus2,
             competent,
             manager,
             financial,
             taxdate,
             marketer,
             personnel,
             consultstatus,
             billcheck,
             goodscoding,
             goodsname,
             defaultstorage,
             mnemoniccode,
             standard,
             typeid,
             model,
             variableid,
             acquiescestandard,
             pieces,
             pbillstypeid,
             companyname,
             departmentname,
             ctusername,
             ccompanyname,
             staffname,
             staffcode,
             pcompanyname,
             reference,
             staffidentitycard,
             referencecode,
             referenceorganization,
             staffaddress,
             companyaddr,
             companytel,
             cresponsible,
             responsibletel,
             industrytype,
             assignsid,
             assignsname,
             signupdate,
             referrername,
             referrerid,
             referrerphone,
             referreridentitycard,
             referreremail,
             referreraddress,
             statusbill,
             oorgid,
             oorgname,
             zzaccountnum,
             csbid,
             projectname,
             starttime,
             endtime,
             xmtype,
             xmtypename,
             csbjournalnum,
             groupcompanysn,
             content,
             inputid,
             inputname,
             inputcompanyid,
             inputcompanyname,
             inputorganizationid,
             inputorganizationname,
             examineid,
             examinename,
             examinecomid,
             examinecomname,
             examineorgid,
             examineorgname,
             zctype,
             remark,
             targetstart,
             targetend,
             targetdeptid,
             targetdeptname,
             targetsalerid,
             targetsalername,
             appstyle,
             proid,
             projectcode,
             wfstatus1,
             wfstatus2,
             wfstatus3,
             fkstatus,
             paystatus,
             wfstatus4,
             rezhi,
             trade_no,
             unionpayqueryid,
             wfth,
             wfthytpe,
             pricesub,
             ghscomid,
             gyscomname,
             mjid,
             ghsid,
             wlcomname,
             wlyf,
             yhname,
             dlvip,
             hrvip,
             jnumorder)
            SELECT dbms_random.string('x', 32),
                   new_ca_id,
                   pro_com_id,
                   contactuserid,
                   ccompanyid,
                   bill_type,
                   FUN_GET_BILL_ID(),
                   staffid,
                   sysdate,
                   discountmoney,
                   afterdiscount,
                   ca_zt,
                   datadepotid,
                   datadepotname,
                   responsible,
                   accountant,
                   cashier,
                   bankdepotid,
                   bankdepotname,
                   accountnum,
                   useraccountnum,
                   contactconnections,
                   phone,
                   companybanknum,
                   pcompanyid,
                   depstatue,
                   taxstatus,
                   taxstatus2,
                   competent,
                   manager,
                   financial,
                   taxdate,
                   marketer,
                   personnel,
                   consultstatus,
                   billcheck,
                   goodscoding,
                   goodsname,
                   defaultstorage,
                   mnemoniccode,
                   standard,
                   typeid,
                   model,
                   variableid,
                   acquiescestandard,
                   pieces,
                   pbillstypeid,
                   com_name,
                   departmentname,
                   ctusername,
                   ccompanyname,
                   staffname,
                   staffcode,
                   pcompanyname,
                   reference,
                   staffidentitycard,
                   referencecode,
                   referenceorganization,
                   staffaddress,
                   companyaddr,
                   companytel,
                   cresponsible,
                   responsibletel,
                   industrytype,
                   assignsid,
                   assignsname,
                   signupdate,
                   referrername,
                   referrerid,
                   referrerphone,
                   referreridentitycard,
                   referreremail,
                   referreraddress,
                   statusbill,
                   oorgid,
                   oorgname,
                   zzaccountnum,
                   csbid,
                   projectname,
                   starttime,
                   endtime,
                   xmtype,
                   xmtypename,
                   csbjournalnum,
                   gn_id,
                   content,
                   inputid,
                   inputname,
                   inputcompanyid,
                   inputcompanyname,
                   inputorganizationid,
                   inputorganizationname,
                   examineid,
                   examinename,
                   examinecomid,
                   examinecomname,
                   examineorgid,
                   examineorgname,
                   zctype,
                   remark,
                   targetstart,
                   targetend,
                   targetdeptid,
                   targetdeptname,
                   targetsalerid,
                   targetsalername,
                   appstyle,
                   proid,
                   projectcode,
                   wfstatus1,
                   wfstatus2,
                   wfstatus3,
                   fkstatus,
                   paystatus,
                   wfstatus4,
                   rezhi,
                   trade_no,
                   unionpayqueryid,
                   wfth,
                   wfthytpe,
                   pricesub,
                   ghscomid,
                   gyscomname,
                   mjid,
                   ghsid,
                   wlcomname,
                   wlyf,
                   yhname,
                   dlvip,
                   hrvip,
                   journalnum
              from dtCashierBills cb
             where cb.billsType = '项目收入预算单'
               and cb.cashierbillsid = ddid;
        
          INSERT INTO dtrelatedbill
            (rbkey, rbid, cashid, cashfid)
          VALUES
            (dbms_random.string('x', 32),
             fun_get_id('relatedbill'),
             ddid,
             new_ca_id);
        
          if i = 1 then
            INSERT INTO dt_inv_fb
              (financialbillkey,
               financialbillid,
               groupcompanysn,
               companyid,
               billstatus,
               billstype,
               journalnum,
               billsdate,
               billstaffid,
               billstaffname,
               cashierbillsid)
              SELECT dbms_random.string('x', 32),
                     fun_get_id('financial'),
                     gn_id,
                     pro_com_id,
                     '16',
                     bill_type,
                     journalnum,
                     sysdate,
                     a.inputid,
                     a.inputname,
                     new_ca_id
                FROM dtcashierbills a
               WHERE a.cashierbillsid = ddid;
          else
            select depotID, depotName
              into potID, potName
              from dtDepotManage
             where companyID = pro_com_id
               and depotPID = '001'
               and depotName = '物流库'
               and depotState = '00';
          
            INSERT INTO dt_inv_fb
              (financialbillkey,
               financialbillid,
               groupcompanysn,
               companyid,
               billstatus,
               billstype,
               journalnum,
               billsdate,
               billstaffid,
               billstaffname,
               cashierbillsid,
               drdepotID,
               drdepotName)
              SELECT dbms_random.string('x', 32),
                     fun_get_id('financial'),
                     gn_id,
                     pro_com_id,
                     '15',
                     status,
                     journalnum,
                     sysdate,
                     a.inputid,
                     a.inputname,
                     new_ca_id,
                     potID,
                     potName
                FROM dtcashierbills a
               WHERE --a.companyid = vi_com_id
              --and
               a.cashierbillsid = ddid;
          end if;
        
        end loop;
      end if;
    
      --生成物品表数据，并执行出入库动作
      for i in 1 .. 2 loop
        if i = 1 then
          select c.companyid, c.companyname, c.groupcompanysn
            into pro_com_id, com_name, gn_id
            from dtcompany c
           where c.companyid = goods.companyid;
          new_ca_id := goods_cashi_id1;
        else
          pro_com_id := 'company201009046vxdyzy4wg0000000025';
          com_name   := '北京天太世统科技有限责任公司';
          gn_id      := 'groupcompany20120523G3VR9PXHZD0000000021';
          new_ca_id  := goods_cashi_id2;
        end if;
      
        new_go_id := fun_get_id('goodsbills');
        INSERT INTO dtgoodsbills
          (goodsbillskey,
           goodsbillsid,
           companyid,
           cashierbillsid,
           subjectsid,
           subjectsname,
           startdate,
           enddate,
           costtype,
           paytype,
           weight,
           boxstandard,
           goodsid,
           pricemanage,
           quantity,
           price,
           money,
           depotid,
           depotname,
           depottype,
           loan,
           forloan,
           direction,
           balance,
           status,
           logistics,
           moneyspent,
           goodsvariableid,
           identifyingcode,
           companybanknum,
           batchnumber,
           perioddate,
           remindedcontent,
           registrationdate,
           accompanydate,
           accompanycontent,
           testscores,
           eligibility,
           reason,
           testrefnumber,
           testelignumber,
           testnotelignumber,
           notifysuccessful,
           examtime,
           examscores,
           projectdec,
           attachmentname,
           attachmentpath,
           remark,
           worksite,
           serviceway,
           servicecontent,
           servicereason,
           dealstatus,
           goodsnomber,
           entrytime,
           goodsstatus,
           billsnumbers,
           reasonthing,
           otheramount,
           balance2,
           ebdid,
           ebbid,
           canstatus,
           ccompanyid,
           ccompanyname,
           connectid,
           connectname,
           inventoryid,
           stockinvid,
           goodsnumber,
           isselected,
           goodsnum,
           goodsname,
           typeid,
           standard,
           sortcode,
           kcstatus,
           goodstatus,
           storagequantity,
           requantity,
           isqualify,
           targetstart,
           targetend,
           targetdeptid,
           targetdeptname,
           targetsalerid,
           targetsalername,
           studentcode,
           studentperiods,
           schoolopendate,
           tiaoprice,
           tiaoquantity,
           tiaomoney,
           plangoodsbillsid,
           realmoney,
           rebate,
           rebateprice,
           ppid,
           photofilename,
           alreadymoney,
           futuremoney,
           tradeno)
          SELECT dbms_random.string('x', 32),
                 new_go_id,
                 companyid,
                 new_ca_id,
                 subjectsid,
                 subjectsname,
                 startdate,
                 enddate,
                 costtype,
                 paytype,
                 weight,
                 boxstandard,
                 goodsid,
                 pricemanage,
                 quantity,
                 price,
                 money,
                 depotid,
                 depotname,
                 depottype,
                 loan,
                 forloan,
                 direction,
                 balance,
                 status,
                 logistics,
                 moneyspent,
                 goodsvariableid,
                 '00',
                 companybanknum,
                 batchnumber,
                 perioddate,
                 remindedcontent,
                 registrationdate,
                 accompanydate,
                 accompanycontent,
                 testscores,
                 eligibility,
                 reason,
                 testrefnumber,
                 testelignumber,
                 testnotelignumber,
                 notifysuccessful,
                 examtime,
                 examscores,
                 projectdec,
                 attachmentname,
                 attachmentpath,
                 remark,
                 worksite,
                 serviceway,
                 servicecontent,
                 servicereason,
                 dealstatus,
                 goodsnomber,
                 entrytime,
                 goodsstatus,
                 billsnumbers,
                 reasonthing,
                 otheramount,
                 balance2,
                 ebdid,
                 ebbid,
                 canstatus,
                 ccompanyid,
                 ccompanyname,
                 connectid,
                 connectname,
                 inventoryid,
                 stockinvid,
                 goodsnumber,
                 isselected,
                 goodsnum,
                 goodsname,
                 typeid,
                 standard,
                 sortcode,
                 kcstatus,
                 goodstatus,
                 storagequantity,
                 requantity,
                 isqualify,
                 targetstart,
                 targetend,
                 targetdeptid,
                 targetdeptname,
                 targetsalerid,
                 targetsalername,
                 studentcode,
                 studentperiods,
                 schoolopendate,
                 tiaoprice,
                 tiaoquantity,
                 tiaomoney,
                 plangoodsbillsid,
                 realmoney,
                 rebate,
                 rebateprice,
                 ppid,
                 photofilename,
                 alreadymoney,
                 futuremoney,
                 tradeno
            FROM dtgoodsbills a
           WHERE
          --a.companyid = vi_com_id
          --and
           a.goodsbillsid = goods.goodsbillsid;
      
        if i = 1 then
        
          --出库动作
          if INSTR(goods.money, '-', 1) = 0 then
          
            money_jisuan := ROUND(TO_NUMBER(goods.money), 2);
          else
            money_jisuan := ROUND(TO_NUMBER(substr(goods.money,
                                                   0,
                                                   INSTR(goods.money, '-', 1) - 1)),
                                  2);
          
          end if;
        
          insert into dt_inv_stockinvt
            (stockinvKey,
             stockinvID,
             companyID,
             goodsBillsId,
             goodsID,
             goodsType,
             goodsName,
             invenQuantity,
             summoney,
             intime,
             type,
             warehouse,
             warehouseName)
          values
            (dbms_random.string('x', 32),
             fun_get_id('stockInv'),
             pro_com_id,
             new_go_id,
             goods.goodsid,
             goods.typeid,
             goods.goodsname,
             goods.quantity,
             money_jisuan,
             sysdate,
             '01',
             goods.depotID,
             goods.depotName);
        
          update dt_inv_invt i
             set i.invenquantity = i.invenquantity - goods.quantity,
                 i.sumprice      = i.sumprice - money_jisuan
           where i.companyid = pro_com_id
             and i.goodsid = goods.goodsid
             and i.warehouse = goods.depotid
             and i.productid = goods.ppid;
        
        end if;
      
        if i = 2 then
        
          select depotID, depotName
            into potID, potName
            from dtDepotManage
           where companyID = pro_com_id
             and depotPID = '001'
             and depotName = '物流库'
             and depotState = '00';
        
          --物流入库动作
        
          if INSTR(goods.money, '-', 1) = 0 then
          
            money_jisuan := ROUND(TO_NUMBER(goods.money), 2);
          else
            money_jisuan := ROUND(TO_NUMBER(substr(goods.money,
                                                   0,
                                                   INSTR(goods.money, '-', 1) - 1)),
                                  2);
          
          end if;
        
          insert into dt_inv_stockinvt
            (stockinvKey,
             stockinvID,
             companyID,
             goodsBillsId,
             goodsID,
             goodsType,
             goodsName,
             invenQuantity,
             summoney,
             intime,
             type,
             warehouse,
             warehouseName)
          values
            (dbms_random.string('x', 32),
             fun_get_id('stockInv'),
             pro_com_id,
             new_go_id,
             goods.goodsid,
             goods.typeid,
             goods.goodsname,
             goods.quantity,
             money_jisuan,
             sysdate,
             '00',
             potID,
             potName);
        
          inventory_ID := fun_get_id('Inventory');
        
          update dt_inv_invt i
             set i.invenquantity = i.invenQuantity + goods.quantity,
                 i.sumprice      = i.sumprice + money_jisuan
           where i.companyid = pro_com_id
             and i.productid = goods.ppid
             and i.goodsid = goods.goodsid
             and i.warehouse = potID;
        
          IF SQL%NOTFOUND THEN
            insert into dt_inv_invt
              (inventoryKey,
               inventoryID,
               companyID,
               warehouse,
               warehouseName,
               goodsID,
               goodsType,
               goodsName,
               standard,
               goodsCoding,
               unitPrice,
               invenQuantity,
               goodstatus,
               sumPrice,
               productid)
            values
              (dbms_random.string('x', 32),
               inventory_ID,
               pro_com_id,
               potID,
               potName,
               goods.goodsid,
               goods.typeid,
               goods.goodsname,
               goods.standard,
               goods.goodsnum,
               goods.price,
               goods.quantity,
               '00',
               money_jisuan,
               goods.ppid);
          
            logisticsInventoryId := inventory_ID;
          else
            select inventoryId
              into logisticsInventoryId
              from dt_inv_invt
             where productid = goods.ppid
               and companyid = pro_com_id
               and GOODSTATUS = '00'
               and WAREHOUSENAME = '物流库';
          end if;
        
          select inventoryId
            into salesInventoryId
            from dt_inv_invt
           where productid = goods.ppid
             and companyid = goods.companyid
             and GOODSTATUS = '00'
             and WAREHOUSENAME = '销售库';
        
          -- 更改物品序号
          goods_id := goods.goodsid;
          nnber    := goods.quantity;
        
          /*for num in var_get_goodsNum loop
            update dtgoodsnum n
               set n.status         = '05',
                   n.cashierbillsid = logisticsInventoryId,
                   n.goodsbillsid   = goods.goodsbillsid
             where n.gnid = num.gnid;
          end loop;*/
        
        end if;
      end loop;
      goods_com_id := goods.companyid;
    end loop;
  
    select count(*)
      into countnum
      from dtcashierbills c
     where c.jnumorder = jornum
       and c.billstype = '销售出库单';
    if countnum > 0 then
      countnum := 0;
      update dtcashierbills c
         set c.status = '16', c.fkstatus = '02'
       where c.cashierbillsid = ddid;
      COMMIT;
    end if;
    goods_com_id := ' ';
    FETCH vcur_get_vouchers
      INTO ddid, jornum;
  end loop;

  <<here>>
  null;

  close vcur_get_vouchers;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('SQL CODE:' || SQLCODE || CHR(10) || SQLERRM ||
                         CHR(10) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE());
END on_Key_fh;
/

