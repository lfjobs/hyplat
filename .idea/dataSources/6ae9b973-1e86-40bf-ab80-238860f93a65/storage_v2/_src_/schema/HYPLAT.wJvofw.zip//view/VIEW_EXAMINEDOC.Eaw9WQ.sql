create view VIEW_EXAMINEDOC as
select d.key,
d.docId,
d.title,
d.theme,
d.doctype,
t.outcome_,
d.emergencytype,
d.startvalidity,
d.endvalidity,
d.partya,
d.partyb,
d.partyaname,
d.partybname,
d.partyastaff,
d.partybstaff,
d.staffidentitycarda,
d.staffidentitycardb,
d.partyastaffnames,
d.partybstaffnames,
com.companyidentifier || d.Docnum as docnum,
t.assignee_,
t.create_ as examinetime,
d.frommember,
ss.staffname fromname,
d.module,
d.deptidofsubscriber,
d.companyidofsubscriber,
d.drafterid,
s.staffname as draftername,
d.organizationid,
org.organizationname as deptNameOfDraft,
d.companyid,com.companyname as companyName,
d.status
from jbpm4_hist_task t inner join jbpm4_hist_var v on  t.execution_=v.procinstid_  inner join
dt_oa_document d on v.value_= d.docId inner join dt_hr_staff s on s.staffid = d.drafterid left join dt_hr_staff ss on ss.staffid=d.frommember left join dtCOrganization org on org.organizationid = d.organizationid left join dtCompany com
on com.companyid = d.companyid
where (t.outcome_='Not Approve' or t.outcome_='to Seal') and v.varname_='docId'

and d.docId not in(select r.docId from dt_oa_doc_delrecord r where r.stage = 'examine' and r.operator = t.assignee_)
/

