create view DT_INV_VOUCHERVO as
select voucherkey,
  voucherid,
  companyid,
  org_id,
  journalnum,
  companyname,
  org_name,
  makepeople,
  makedate,
  auditingpeo,
  auditingdate,
  tallypeople,
  tallydate,
  vouchercategory,
  makepeopleid,
  auditingpeoid,
  tallypeopleid,
  voucherdate,
  voucherorigin
  from DT_INV_VOUCHER


/

