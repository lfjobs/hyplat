create view DTCOSJOBPLANVO as
select
co.companyName,
org.organizationName,
st.staffname,
st.staffcode ,
jt.jobplanid,
jt.companyid,jt.organizationid,jt.staffid,jt.startdate,jt.jobname,jt.postmanage,jt.enddate,
jt.entry,jt.projectcode,jt.projectdetailscode,jt.projectrequirements,jt.fraction,
jt.points,jt.actualscore,jt.entrydate,jt.manager,jt.humansupervisor,jt.supervisor,
jt.jobcontent,jt.jobplankey,jt.codeid,jt.codevalue,jt.jobstatus
from dtcosjobplan jt
join view_sc st
on jt.staffid = st.staffid and jt.companyid = st.companyid
left join dtcompany co on  co.companyid = jt.companyid
left join dtcorganization org on  org.organizationID = jt.organizationid


/

