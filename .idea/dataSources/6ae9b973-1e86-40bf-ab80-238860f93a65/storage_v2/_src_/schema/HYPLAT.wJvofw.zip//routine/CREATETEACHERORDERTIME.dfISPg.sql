create procedure createTeacherOrderTime(v_companyId    in varchar2,
                                                   v_createperson in varchar2,
                                                   v_days_detail  in varchar2) is
  v_is_company_exist number;--驾校是否存在
  v_is_school_rest   number;--驾校是否休息
   
  cursor c_teacher_info is select distinct t.* from tb_jp_teacher t where t.companyid = v_companyId;--查询当前公司驾校的所有教练
  v_teacher_info tb_jp_teacher%rowType;--声明一个是教练类型的行类型
  
  v_student_pb tb_elyc_scheduling_detail%rowType;--排班数据行类型
  
  Type v_array IS varray(7) OF tb_elyc_scheduling_detail%rowType;--定义排班数组行类型
  -- 排班数据数组
  a_scheduling_detail v_array;--数组重命名
  
  --定义游标类型
  type cus_cur_type is ref cursor return tb_elyc_reservation_detail%rowtype;--定义游标为约车详细时间段模式行类型
  --详细约车时间段游标
  c_reservation_detail cus_cur_type;
  
  --详细约车时间段行数据类型
  v_reservation_detail tb_elyc_reservation_detail%rowtype;
  
  --教练休班游标，驾校休息
  type c_teacher_rest_type is ref cursor return tb_elyc_trainer_vacation%rowtype;
  c_teacher_rest c_teacher_rest_type;
  
  type c_school_rest_type is ref cursor return tb_elyc_school_rest%rowtype;
  c_school_rest c_school_rest_type;
  
  v_teacher_rest tb_elyc_trainer_vacation%rowType;
  v_school_rest tb_elyc_school_rest%rowType;
  
  v_check_vacation number;
  
  v_detail_time_status varchar2(32);
  
  v_days date;--声明一个日期变量
  
  v_check_has_create int;--声明教练是否有了当天的约车记录
  
begin
  v_days := to_date(v_days_detail, 'yyyy-mm-dd');--将当天日期格式化付给变量
  --nvl 如果为空，显示为0 查询当前公司，当天处在放假时间的数据条数如果为空设置为0，赋值给v_is_school_rest
  select nvl(count(*), 0) into v_is_school_rest from tb_elyc_school_rest sr where (v_days between sr.holidaybegin and sr.holidayend) and sr.companyid = v_companyId;
  
 

 --判断驾校是否休假
  if v_is_school_rest = 0 then  --如果不休假
    select nvl(count(*), 0) into v_is_company_exist from tb_jp_company t where t.company_id = v_companyId;--驾校是否存在
     if v_is_company_exist = 1 then
          for v_teacher_info in c_teacher_info loop
        select nvl(count(*), 0)
          into v_check_has_create
          from tb_elyc_order_detail_time t
         where t.companyid = v_companyId
           and t.teacherid = v_teacher_info.teacherid
           and to_char(t.lessionstarttime, 'yyyy-mm-dd') = v_days_detail;--循环查询每一个教练当天开始的预约时间段的条数
       
       if v_check_has_create = 0 then--如果已经创建的预约记录结束当前循环，进行下次循环
       --查询当天教练是否休假
        select nvl(count(*),0) into v_check_vacation from tb_elyc_trainer_vacation v where v.trainer_id = v_teacher_info.teacherid and (v_days between to_date(to_char(v.start_time,'yyyy-mm-dd'),'yyyy-mm-dd') and to_date(to_char(v.end_time,'yyyy-mm-dd'),'yyyy-mm-dd'));

         if v_check_vacation > 0 then --如果休假
          
          open c_teacher_rest for select v.* from tb_elyc_trainer_vacation v where v.trainer_id = v_teacher_info.teacherid and (v_days between to_date(to_char(v.start_time,'yyyy-mm-dd'),'yyyy-mm-dd') and to_date(to_char(v.end_time,'yyyy-mm-dd'),'yyyy-mm-dd'));
          fetch c_teacher_rest into v_teacher_rest;
          while c_teacher_rest%found loop
            update tb_elyc_trainer_vacation rest set rest.STATUS = '01' where rest.trainer_id = v_teacher_rest.trainer_id;--将教练休班改变状态
            commit;
            
              DBMS_OUTPUT.PUT_LINE('更新一行教练休班');
            fetch c_teacher_rest into v_teacher_rest;
          end loop;
    
        else  --如果没有休假
          v_detail_time_status := '2';
                --根据教练员id对应的班次id取教练员班次轮班信息放入a_scheduling_detail 数组
        select sd.* BULK COLLECT
          INTO a_scheduling_detail
          from tb_elyc_scheduling_detail sd
         where sd.classid =
               (select s.classid from tb_elyc_teacher_rscheduling rs, tb_elyc_scheduling s where rs.teacherid = v_teacher_info.teacherid and rs.classid= s.classid and s.status = '01');
        

               
          --如果只有一条轮班信息
        if a_scheduling_detail.count() = 1 then
          --varray 数组下标从1开始
          v_student_pb := a_scheduling_detail(1);
          
           --如果轮转方式为   day   则根据预约模式id取详细预约时间段
          if v_student_pb.rotatemode = '日' then
          
           --获取约车详细时间段列表的游标
            open c_reservation_detail for
              select *
                from tb_elyc_reservation_detail rd
               where rd.reservationmodeid in
                     (select rm.reservationmodeid from tb_elyc_reservation_mode rm where rm.reservationmodeid= v_student_pb.reservationmodeid and rm.status = '01');
           
           fetch c_reservation_detail
              into v_reservation_detail;
            --循环更新到教练详细可预约时间段表中
            while c_reservation_detail%found loop
              insert into tb_elyc_order_detail_time
                (odtkey,
                 odtId,
                 teacherid,
                 lessionstarttime,
                 lessionendtime,
                 status,
                 createdate,
                 updatedate,
                 createperson,
                 updateperson,
                 companyid,
                 hours
                 )
              values
                 (DBMS_RANDOM.STRING('X', 32),
                 DBMS_RANDOM.STRING('X', 32),
                 v_teacher_info.teacherid,
                 to_date(v_days_detail || v_reservation_detail.starttime || '00','yyyy-MM-dd hh24:mi:ss'),
                 to_date(v_days_detail || v_reservation_detail.endtime || '00','yyyy-MM-dd hh24:mi:ss'),
                 v_detail_time_status,
                 sysdate,
                 sysdate,
                 v_createperson,
                 v_createperson,
                 v_companyId,
                 v_reservation_detail.hours
                 );
              commit;
              DBMS_OUTPUT.PUT_LINE('增加一行');
              fetch c_reservation_detail into v_reservation_detail;
            end loop;
           end if;
     
         end if;

        end if;
   
       
        end if; 
      end loop;

      end if;
  
    else

      open c_school_rest for select sr.* from tb_elyc_school_rest sr where (v_days between sr.holidaybegin and sr.holidayend) and sr.companyid = v_companyId;
          fetch c_school_rest into v_school_rest;
          while c_school_rest%found loop
            update tb_elyc_school_rest rest set rest.STATUS = '1' where rest.esrid = v_school_rest.esrid;
            commit;
              DBMS_OUTPUT.PUT_LINE('更新一行驾校休息');
            fetch c_school_rest into v_school_rest;
          end loop;
    end if;


end createTeacherOrderTime;
/

