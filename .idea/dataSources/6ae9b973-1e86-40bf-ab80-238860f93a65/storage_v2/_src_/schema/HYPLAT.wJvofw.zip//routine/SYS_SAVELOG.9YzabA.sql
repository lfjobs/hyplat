create PROCEDURE SYS_SAVELOG(PROGRAM_NAME VARCHAR2, --过程名称
                                        IS_SUCCEED   VARCHAR2, --是否执行成功 Y|N
                                        EXECUTE_MSG  CLOB, --过程执行信息
                                        BEGIN_TIME   TIMESTAMP, --过程开始执行TIMESTAMP
                                        logClob      clob --执行操作日志
                                        ) AS
  V_PROGRAM_NAME VARCHAR2(1000) := SUBSTRB(PROGRAM_NAME, 1, 1000); --过程名称
  V_IS_SUCCEED   CHAR(1) := SUBSTR(IS_SUCCEED, 1, 1); --过程执行成功表示 Y N
  V_BEGIN_TIME   TIMESTAMP := BEGIN_TIME;
  PRAGMA AUTONOMOUS_TRANSACTION; --日志开启自治事务，不影响业务逻辑事务
  tableid NUMBER;
  /*
  调用方式：
  1.正常日志：PROC_SAVELOG(V_PROC_NAME, 'Y', '执行成功。。。',V_BEGIN_TIME);
  2.异常日志：PROC_SAVELOG(V_PROC_NAME, 'N', SQLERRM,V_BEGIN_TIME);
  */
BEGIN

  INSERT INTO PROGRAM_EXECUTE_LOG
    (PROGRAM_NAME,
     IS_SUCCEED,
     LOG_DATE,
     EXECUTE_MSG, --已改为CLOB
     TIME_CONSUMING,
     --EXECUTE_ORDER,
     EXECUTE_BEGINTIME,
     EXECUTE_ENDTIME)
  VALUES
    (V_PROGRAM_NAME,
     V_IS_SUCCEED,
     SYSDATE,
     EXECUTE_MSG,
     F_TIMESTAMP_DIFF(SYSTIMESTAMP, V_BEGIN_TIME),
     --SEQ_PROGRAM_EXECUTE_LOG.NEXTVAL,
     V_BEGIN_TIME,
     SYSTIMESTAMP);

  /*select EXECUTE_ORDER
    into tableid
    from PROGRAM_EXECUTE_LOG
   where PROGRAM_NAME = V_PROGRAM_NAME;

  insert into PROCEDURE_LOG (logClob, pel_order) values (logClob, tableid);*/

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END;
/

