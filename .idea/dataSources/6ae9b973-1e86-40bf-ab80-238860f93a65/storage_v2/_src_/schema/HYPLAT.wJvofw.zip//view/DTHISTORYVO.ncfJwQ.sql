create view DTHISTORYVO as
select t.companyname,t.departmentname,t.staffname,t.staffcode recordcode,
t.ccompanyname,cc.companyaddr,cc.companytel,cc.responsibletel,cc.cresponsible,cc.industryType
,t.ctusername as  contactusername,cu.staffidentitycard,cu.staffaddress as useraddr,
cu.reference as  tel,cu.referenceCode as userqq,cu.referenceOrganization as email,
t.companyid,t.pcompanyid,t.cashierbillsid,t.personnel,t.marketer,t.depstatue,t.contactconnections,
t.accountnum,t.bankdepotid,t.bankdepotname,t.cashier,t.accountant,t.responsible,t.phone,t.taxdate,
t.financial,t.manager,t.competent,t.input,t.taxstatus2,t.taxstatus,t.status,t.datadepotname,t.datadepotid,
t.afterdiscount,t.discountmoney,t.cashierdate,t.staffid,t.journalnum,t.billstype,t.ccompanyid,t.contactuserid,
t.useraccountnum,t.departmentid,t.organizationid,t.companybanknum,t.cashierbillskey,t.consultstatus,t.billcheck,t.goodscoding,t.goodsname,
t.defaultstorage,t.mnemoniccode,t.standard,t.typeid,t.model,t.variableid,t.acquiescestandard
from dt_history_cashierbills t
left join  dtcontactcompany cc on  cc.ccompanyid= t.ccompanyid
left join dt_hr_staff cu on  cu.staffid = t.contactuserid


/

