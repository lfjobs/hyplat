create view BCDAYVO as
select b.voucherdate,b.subjectscode,b.vou_Ex,b.B_Money,b.S_Money,b.Z_Money,b.cb_Money,
      b.journalnum,b.vouchernum,b.reasonthing,c.codedesc
      from BC_DAY b,dtCCode c where b.com_Id=c.companyID


/

