create PROCEDURE GET_ASSIGNN_FSHB_JIFEN IS

  VI_ACCOUNT T_ESHOP_CUSCOM.ACCOUNT%TYPE;
  VI_NUM     DT_WFJ_JIFEN.WFJ_JIFEN_SCORE%TYPE;
  VI_SUMNUM  DT_WFJ_JIFEN.WFJ_JIFEN_SCORE%TYPE;
  VI_COM_ID  DTCOMPANY.COMPANYID%TYPE;
  VI_COUNT   NUMBER;

  --V_COUNTNUM NUMBER;
  V_Z_JFNUM NUMBER;
  V_S_JFNUM NUMBER;

  V_FSHB_SNAME DT_HR_STAFF.STAFFNAME%TYPE;
  V_FSHB_SCODE DT_HR_STAFF.STAFFCODE%TYPE;
  V_FSHB_SID   DT_HR_STAFF.STAFFID%TYPE;
  V_FSHB_SCCID T_ESHOP_CUSCOM.SCCID%TYPE;

  V_SNAME DT_HR_STAFF.STAFFNAME%TYPE;
  V_SCODE DT_HR_STAFF.STAFFCODE%TYPE;
  V_SID   DT_HR_STAFF.STAFFID%TYPE;
  V_SCCID T_ESHOP_CUSCOM.SCCID%TYPE;

  V_FSHB_COM_NAME DTCOMPANY.COMPANYNAME%TYPE;
  V_FSHB_G_SN     DTCOMPANY.GROUPCOMPANYSN%TYPE;
  V_FSHB_COM_ID   DTCOMPANY.COMPANYID%TYPE;

  V_COM_NAME DTCOMPANY.COMPANYNAME%TYPE;
  V_G_SN     DTCOMPANY.GROUPCOMPANYSN%TYPE;
  V_COM_ID   DTCOMPANY.COMPANYID%TYPE;

  V_XJHB DTGOODSBILLS.GOODSNAME%TYPE;

  V_GOODSID   DTGOODSBILLS.GOODSID%TYPE;
  V_TYPE      DTGOODSBILLS.TYPEID%TYPE;
  V_GOODSNAME DTGOODSBILLS.GOODSNAME%TYPE;

  V_RK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  V_CK_CA_ID  DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  V_CK_JUM    DTCASHIERBILLS.JOURNALNUM%TYPE;
  V_NEW_CA_ID DTCASHIERBILLS.CASHIERBILLSID%TYPE;
  V_NEW_GB_ID DTGOODSBILLS.GOODSBILLSID%TYPE;

  V_S_GUIZE_ID DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE;
  V_Z_GUIZE_ID DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE;

  V_Z_JF_ID      DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE;
  V_S_JF_ID      DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE;
  V_NEW_JF_ID    DT_WFJ_JIFEN.WFJ_JIFEN_ID%TYPE;
  V_NEW_GUIZE_ID DT_WFJ_GUIZE.WFJ_GUIZE_ID%TYPE;

  V_JIFEN_DETAIL_NAME DT_WFJ_JIFEN_DETAIL.JIFEN_DETAIL_NAME%TYPE;

  V_BEGIN_TIME TIMESTAMP := SYSTIMESTAMP;
  V_PROC_NAME  VARCHAR2(1000) := 'GET_ASSIGNN_FSHB_JIFEN/' ||
                                 TO_CHAR(sysdate, 'YYYY-MM-DD');
  V_EXE_MSG    CLOB;
  V_ERR_MSG    VARCHAR2(1000);
  RESULT       VARCHAR2(100);

  V_LOG CLOB;

  DETAILID DT_WFJ_BONUSPOINTS_DETAIL.BONUSPOINTSDETAILID%TYPE;

  CURSOR VCUR_GET_FS IS
    SELECT T.ACCOUNT, T.SCCID
      FROM T_ESHOP_CUSCOM T,
           DT_WFJ_JIFEN J,
           (SELECT D.WFJ_JIFEN_ID DID,
                   SUM(NVL(DECODE(G.WFJ_GUIZE_ID,
                                  'WfjGuize20151120R5HZ2UPCV50000000006',
                                  D.JIFEN_DETAIL_SCORE),
                           0)) DD1
              FROM DT_WFJ_JIFEN_DETAIL D, DT_WFJ_GUIZE G
             WHERE D.WFJ_GUIZE_ID = G.WFJ_GUIZE_ID
               AND D.STATUS IS NULL
               AND D.WFJ_JIFEN_ID IN
                   (SELECT J.WFJ_JIFEN_ID
                      FROM DT_WFJ_JIFEN J
                     WHERE J.SCCID IN
                           (SELECT T.SCCID
                              FROM T_ESHOP_CUSCOM T
                             WHERE T.CUSTYPE = 7
                               AND T.SUPPERSCCID IS NOT NULL
                               AND T.STAFFID IS NOT NULL
                               AND T.ACCOUNT IS NOT NULL))
             GROUP BY D.WFJ_JIFEN_ID) DD
     WHERE T.SCCID = J.SCCID
       AND DD.DD1 <= 0
       AND J.WFJ_JIFEN_ID = DD.DID
    UNION ALL (SELECT ACCOUNT, SCCID
                 FROM T_ESHOP_CUSCOM OUT
                WHERE NOT EXISTS
                (SELECT SCCID FROM DT_WFJ_JIFEN WHERE OUT.SCCID = SCCID)
                  AND SUPPERSCCID IS NOT NULL
                  AND STAFFID IS NOT NULL
                  AND ACCOUNT IS NOT NULL
                  AND CUSTYPE = 7);

BEGIN

  SELECT COUNT(*)
    INTO VI_COUNT
    FROM PROGRAM_EXECUTE_LOG
   WHERE PROGRAM_NAME LIKE 'GET_ASSIGNN_FSHB_JIFEN%'
     AND IS_SUCCEED = 'N'
     AND SYSDATE - 1 / 24 <= EXECUTE_ENDTIME;

  IF VI_COUNT > 0 THEN
  
    V_ERR_MSG := '已执行，重复执行-';
    GOTO PROCESS_ERRMSG;
  
  ELSE
  
    DBMS_LOB.CREATETEMPORARY(V_EXE_MSG, TRUE); --初始化CLOB
    DBMS_LOB.CREATETEMPORARY(V_LOG, TRUE); --初始化CLOB
    V_XJHB := '微分金积分';
    --V_PRO_XJHB   := '积分';
    VI_COM_ID := 'company201009046vxdyzy4wg0000000025';
    RESULT    := 'OK';
    VI_COUNT  := 0;
  
    SELECT COUNT(*)
      INTO VI_COUNT
      FROM (SELECT T.ACCOUNT, T.SCCID
              FROM T_ESHOP_CUSCOM T,
                   DT_WFJ_JIFEN J,
                   (SELECT D.WFJ_JIFEN_ID DID,
                           SUM(NVL(DECODE(G.WFJ_GUIZE_ID,
                                          'WfjGuize20151120R5HZ2UPCV50000000006',
                                          D.JIFEN_DETAIL_SCORE),
                                   0)) DD1
                      FROM DT_WFJ_JIFEN_DETAIL D, DT_WFJ_GUIZE G
                     WHERE D.WFJ_GUIZE_ID = G.WFJ_GUIZE_ID
                       AND D.STATUS IS NULL
                       AND D.WFJ_JIFEN_ID IN
                           (SELECT J.WFJ_JIFEN_ID
                              FROM DT_WFJ_JIFEN J
                             WHERE J.SCCID IN
                                   (SELECT T.SCCID
                                      FROM T_ESHOP_CUSCOM T
                                     WHERE T.CUSTYPE = 7
                                       AND T.SUPPERSCCID IS NOT NULL
                                       AND T.STAFFID IS NOT NULL
                                       AND T.ACCOUNT IS NOT NULL))
                     GROUP BY D.WFJ_JIFEN_ID) DD
             WHERE T.SCCID = J.SCCID
               AND DD.DD1 <= 0
               AND J.WFJ_JIFEN_ID = DD.DID
            UNION ALL
            SELECT ACCOUNT, SCCID
              FROM T_ESHOP_CUSCOM OUT
             WHERE NOT EXISTS
             (SELECT SCCID FROM DT_WFJ_JIFEN WHERE OUT.SCCID = SCCID)
               AND SUPPERSCCID IS NOT NULL
               AND STAFFID IS NOT NULL
               AND ACCOUNT IS NOT NULL
               AND CUSTYPE = 7);
  
    SELECT J.BONUSPOINTSCORE, S.STAFFNAME, S.STAFFCODE, S.STAFFID, t.sccid
      INTO VI_SUMNUM, V_FSHB_SNAME, V_FSHB_SCODE, V_FSHB_SID, V_FSHB_SCCID
      FROM DT_WFJ_BONUSPOINTS J, T_ESHOP_CUSCOM T, DT_HR_STAFF S
     WHERE J.SCCID = T.SCCID
       and S.STAFFID = T.STAFFID
       AND T.ACCOUNT = 'fshb';
  
    --if VI_SUMNUM >= 1000000 then
    VI_SUMNUM := VI_SUMNUM - 1000000;
    --end if;
  
    --查询平台公司名称、组织机构ID
    /*SELECT T.COMPANYID, T.PSEUDO_COMPANY_NAME, C.GROUPCOMPANYSN
      INTO V_FSHB_COM_ID, V_FSHB_COM_NAME, V_FSHB_G_SN
      FROM T_ESHOP_CUSCOM T
      LEFT JOIN DTCOMPANY C
        ON T.COMPANYID = C.COMPANYID
     WHERE T.COMPANYID IS NOT NULL
       AND ROWNUM = 1
     START WITH T.SCCID = V_FSHB_SCCID
    CONNECT BY PRIOR T.SUPPERSCCID = T.SCCID;*/
  
    SELECT CC.CID, CC.PSEUDO_COMPANY_NAME, C.GROUPCOMPANYSN
      INTO V_FSHB_COM_ID, V_FSHB_COM_NAME, V_FSHB_G_SN
      FROM (SELECT T.COMPANYID CID, T.PSEUDO_COMPANY_NAME
              FROM T_ESHOP_CUSCOM T
             WHERE T.COMPANYID IS NOT NULL
               AND ROWNUM = 1
             START WITH T.SCCID = V_FSHB_SCCID
            CONNECT BY PRIOR T.SUPPERSCCID = T.SCCID) CC
      LEFT JOIN DTCOMPANY C
        ON CC.CID = C.COMPANYID;
  
    SELECT G.WFJ_GUIZE_ID
      INTO V_Z_GUIZE_ID
      FROM DT_WFJ_GUIZE G
     WHERE G.WFJ_GUIZE_NAME = '粉丝红包(支)'
       AND G.COMPANY_ID = VI_COM_ID;
  
    SELECT G.WFJ_GUIZE_ID
      INTO V_S_GUIZE_ID
      FROM DT_WFJ_GUIZE G
     WHERE G.WFJ_GUIZE_NAME = '粉丝红包(收)'
       AND G.COMPANY_ID = VI_COM_ID;
  
    IF VI_SUMNUM > 0 THEN
    
      select trunc(VI_SUMNUM / (VI_COUNT + 1), 5) into VI_NUM from dual;
    
      IF VI_NUM > 0.01 THEN
      
        /*DBMS_LOB.APPEND(V_LOG,
        '{\"操作平均总积分数\":' || VI_SUMNUM || ',\"操作平均积分数\":' || VI_NUM || ',\"数量\":' || VI_COUNT ||
        ',\"开始\":[');*/
      
        OPEN VCUR_GET_FS;
        FETCH VCUR_GET_FS
          INTO VI_ACCOUNT, V_SCCID;
        LOOP
          EXIT WHEN VCUR_GET_FS%NOTFOUND;
        
          VI_COUNT := 0;
        
          SELECT COUNT(*)
            INTO VI_COUNT
            FROM T_ESHOP_CUSCOM T, DT_HR_STAFF S
           WHERE S.STAFFID = T.STAFFID
             AND T.ACCOUNT = VI_ACCOUNT
             AND T.SCCID = V_SCCID;
        
          IF VI_COUNT = 1 THEN
          
            SELECT S.STAFFNAME, S.STAFFCODE, S.STAFFID, t.sccid
              INTO V_SNAME, V_SCODE, V_SID, V_SCCID
              FROM T_ESHOP_CUSCOM T, DT_HR_STAFF S
             WHERE S.STAFFID = T.STAFFID
               AND T.ACCOUNT = VI_ACCOUNT
               AND T.SCCID = V_SCCID;
          
            /*SELECT T.PSEUDO_COMPANY_NAME, C.GROUPCOMPANYSN, T.COMPANYID
              INTO V_COM_NAME, V_G_SN, V_COM_ID
              FROM T_ESHOP_CUSCOM T
              LEFT JOIN DTCOMPANY C
                ON T.COMPANYID = C.COMPANYID
             WHERE T.COMPANYID IS NOT NULL
               AND ROWNUM = 1
             START WITH T.SCCID = V_SCCID
            CONNECT BY PRIOR T.SUPPERSCCID = T.SCCID;*/
          
            SELECT CCC.PSEUDO_COMPANY_NAME,C.GROUPCOMPANYSN,CCC.CID
              INTO V_COM_NAME, V_G_SN, V_COM_ID
              FROM (SELECT T.COMPANYID CID, T.PSEUDO_COMPANY_NAME
                      FROM T_ESHOP_CUSCOM T
                     WHERE T.COMPANYID IS NOT NULL
                       AND ROWNUM = 1
                     START WITH T.SCCID = V_SCCID
                    CONNECT BY PRIOR T.SUPPERSCCID = T.SCCID) CCC
              LEFT JOIN DTCOMPANY C
                ON CCC.CID = C.COMPANYID;
          
            --支
            SELECT W.BONUSPOINTSCORE, W.BONUSPOINTSID
              INTO V_Z_JFNUM, V_Z_JF_ID
              FROM DT_WFJ_BONUSPOINTS W
             WHERE SCCID = V_FSHB_SCCID;
          
            /*DBMS_LOB.APPEND(V_LOG,
            '{\"支-账号\":\"fshb\",\"支-id\":\"' || V_Z_JF_ID ||
            '\",\"支-修改前积分总数\":' || V_Z_JFNUM || ',');*/
          
            UPDATE DT_WFJ_BONUSPOINTS
               SET BONUSPOINTSCORE = NVL(BONUSPOINTSCORE, 0) - VI_NUM
             WHERE SCCID = V_FSHB_SCCID;
          
            SELECT W.BONUSPOINTSCORE, W.BONUSPOINTSID
              INTO V_Z_JFNUM, V_Z_JF_ID
              FROM DT_WFJ_BONUSPOINTS W
             WHERE SCCID = V_FSHB_SCCID;
          
            /*DBMS_LOB.APPEND(V_LOG,
            '\"支-修改后积分总数\":' || V_Z_JFNUM || ',');*/
          
            IF V_Z_JFNUM > 0 THEN
              VI_COUNT := 0;
              --收
              /*DBMS_LOB.APPEND(V_LOG, '\"支-修改后剩余积分总数>0\":true,');*/
            
              SELECT COUNT(*)
                INTO VI_COUNT
                FROM DT_WFJ_BONUSPOINTS
               WHERE SCCID = V_SCCID;
            
              IF VI_COUNT > 0 THEN
              
                SELECT W.BONUSPOINTSCORE, W.BONUSPOINTSID
                  INTO V_S_JFNUM, V_S_JF_ID
                  FROM DT_WFJ_BONUSPOINTS W
                 WHERE SCCID = V_SCCID;
              
                /*DBMS_LOB.APPEND(V_LOG,
                '\"收-账号\":\"' || VI_ACCOUNT || '\",\"收-id\":\"' ||
                V_S_JF_ID || '\",\"收-修改前积分总数\":' || V_S_JFNUM);*/
              
                UPDATE DT_WFJ_BONUSPOINTS
                   SET BONUSPOINTSCORE = NVL(BONUSPOINTSCORE, 0) + VI_NUM
                 WHERE SCCID = V_SCCID;
              
              ELSE
                --IF SQL%NOTFOUND THEN
              
                V_S_JF_ID := FUN_GET_ID('BonusPoints');
              
                INSERT INTO DT_WFJ_BONUSPOINTS
                  (BONUSPOINTSKEY, BONUSPOINTSID, SCCID, BONUSPOINTSCORE)
                VALUES
                  (DBMS_RANDOM.STRING('x', 32), V_S_JF_ID, V_SCCID, VI_NUM);
              
                /*DBMS_LOB.APPEND(V_LOG,
                '\"收-账号\":\"' || VI_ACCOUNT || '\",\"收-id\":\"' ||
                V_S_JF_ID || '\",\"收-修改前积分总数\":0');*/
              END IF;
            
              SELECT W.BONUSPOINTSCORE, W.BONUSPOINTSID
                INTO V_S_JFNUM, V_S_JF_ID
                FROM DT_WFJ_BONUSPOINTS W
               WHERE SCCID = V_SCCID;
            
              /*DBMS_LOB.APPEND(V_LOG,
              ',\"收-修改后积分总数\":' || V_S_JFNUM || ',');*/
            
              --入库单
              V_RK_CA_ID := FUN_GET_ID('cashierbills');
              INSERT INTO DT_K_E_JIFENBILL3
                (CASHIERBILLSKEY,
                 CASHIERBILLSID,
                 COMPANYID,
                 BILLSTYPE,
                 JOURNALNUM,
                 STAFFID,
                 STAFFNAME,
                 STAFFCODE,
                 CASHIERDATE,
                 STATUS,
                 COMPANYNAME,
                 PROID,
                 PROJECTNAME, --项目名称
                 GROUPCOMPANYSN,
                 INPUTID,
                 INPUTNAME,
                 APPSTYLE,
                 PRICESUB,
                 CCOMPANYID,
                 CCOMPANYNAME,
                 STATUSBILL)
              VALUES
                (DBMS_RANDOM.STRING('X', 32),
                 V_RK_CA_ID,
                 V_COM_ID,
                 '积分入库单',
                 FUN_GET_BILL_ID(),
                 V_SID,
                 V_SNAME, --会员名称
                 V_SCODE, --会员编号
                 SYSDATE,
                 '15',
                 V_COM_NAME, --公司名称
                 '002',
                 '粉丝红包(收)',
                 V_G_SN, --集团组织机构ID
                 V_SID,
                 V_SNAME,
                 '08',
                 TO_CHAR(VI_NUM / 100,
                         'FM999999999999999999999999999999990.999999999'),
                 V_FSHB_COM_ID,
                 V_FSHB_COM_NAME,
                 '04');
            
              /*DBMS_LOB.APPEND(V_LOG,
              '\"详情\":{\"入库单id\":\"' || V_RK_CA_ID || '\",');*/
            
              --平台金币出库单
              V_CK_CA_ID := FUN_GET_ID('cashierbills');
              V_CK_JUM   := FUN_GET_BILL_ID();
              INSERT INTO DT_K_G_JIFENBILL3
                (CASHIERBILLSKEY,
                 CASHIERBILLSID,
                 COMPANYID,
                 BILLSTYPE,
                 JOURNALNUM,
                 STAFFID,
                 STAFFNAME,
                 STAFFCODE,
                 CASHIERDATE,
                 STATUS,
                 COMPANYNAME,
                 PROID,
                 PROJECTNAME, --项目名称
                 GROUPCOMPANYSN,
                 INPUTID,
                 INPUTNAME,
                 APPSTYLE,
                 PRICESUB,
                 CCOMPANYID,
                 CCOMPANYNAME,
                 CONTACTUSERID,
                 CTUSERNAME,
                 STATUSBILL)
              VALUES
                (DBMS_RANDOM.STRING('X', 32),
                 V_CK_CA_ID,
                 V_FSHB_COM_ID,
                 '积分出库单',
                 V_CK_JUM,
                 V_FSHB_SID,
                 V_FSHB_SNAME, --会员名称
                 V_FSHB_SCODE, --会员编号
                 SYSDATE,
                 '16',
                 V_FSHB_COM_NAME, --公司名称
                 '002',
                 '粉丝红包(支)',
                 V_G_SN, --集团组织机构ID
                 V_SID,
                 V_SNAME,
                 '08',
                 TO_CHAR(VI_NUM / 100,
                         'FM999999999999999999999999999999990.999999999'),
                 V_COM_ID,
                 V_COM_NAME,
                 V_SID,
                 V_SNAME,
                 '04');
            
              /*DBMS_LOB.APPEND(V_LOG, '\"出库单id\":\"' || V_CK_CA_ID || '\",');*/
            
              --平台\用户金币出库\入库产品表
              FOR I IN 1 .. 2 LOOP
                V_GOODSID   := NULL;
                V_TYPE      := NULL;
                V_GOODSNAME := V_XJHB;
              
                IF I = 1 THEN
                  --入库
                  V_NEW_CA_ID         := V_RK_CA_ID;
                  V_JIFEN_DETAIL_NAME := '粉丝红包(收)';
                  V_NEW_JF_ID         := V_S_JF_ID;
                  V_NEW_GUIZE_ID      := V_S_GUIZE_ID;
                  /*DBMS_LOB.APPEND(V_LOG, '\"入库物品单id\":');*/
                
                  V_NEW_GB_ID := FUN_GET_ID('goodsbills');
                
                  INSERT INTO DT_K_E_JIFENGOOD3
                    (GOODSBILLSKEY,
                     GOODSBILLSID,
                     --COMPANYID,
                     CASHIERBILLSID,
                     PAYTYPE, --付款方式
                     QUANTITY,
                     PRICE,
                     MONEY,
                     DEPOTNAME, --库房名称
                     IDENTIFYINGCODE, --00
                     GOODSNAME,
                     KCSTATUS, --15：已入库
                     GOODSTATUS) --状态00正常 01维修02报废
                  VALUES
                    (DBMS_RANDOM.STRING('X', 32),
                     V_NEW_GB_ID,
                     --COM_ID,
                     V_NEW_CA_ID,
                     '08',
                     TO_CHAR(VI_NUM,
                             'FM999999999999999999999999999999990.999999999'),
                     '0.01',
                     TO_CHAR(VI_NUM / 100,
                             'FM999999999999999999999999999999990.999999999'),
                     '销售库',
                     '00',
                     V_XJHB,
                     '15',
                     '00');
                ELSE
                  --出库
                  V_NEW_CA_ID         := V_CK_CA_ID;
                  V_JIFEN_DETAIL_NAME := '粉丝红包(支)';
                  V_NEW_JF_ID         := V_Z_JF_ID;
                  V_NEW_GUIZE_ID      := V_Z_GUIZE_ID;
                  /*DBMS_LOB.APPEND(V_LOG, '\"出库物品单id\":');*/
                
                  V_NEW_GB_ID := FUN_GET_ID('goodsbills');
                
                  INSERT INTO DT_K_G_JIFENGOOD3
                    (GOODSBILLSKEY,
                     GOODSBILLSID,
                     --COMPANYID,
                     CASHIERBILLSID,
                     PAYTYPE, --付款方式
                     QUANTITY,
                     PRICE,
                     MONEY,
                     DEPOTNAME, --库房名称
                     IDENTIFYINGCODE, --00
                     GOODSNAME,
                     KCSTATUS, --15：已入库
                     GOODSTATUS) --状态00正常 01维修02报废
                  VALUES
                    (DBMS_RANDOM.STRING('X', 32),
                     V_NEW_GB_ID,
                     --COM_ID,
                     V_NEW_CA_ID,
                     '08',
                     TO_CHAR(VI_NUM,
                             'FM999999999999999999999999999999990.999999999'),
                     '0.01',
                     TO_CHAR(VI_NUM / 100,
                             'FM999999999999999999999999999999990.999999999'),
                     '销售库',
                     '00',
                     V_XJHB,
                     '15',
                     '00');
                END IF;
              
                /*DBMS_LOB.APPEND(V_LOG, '\"' || V_NEW_GB_ID || '\",');*/
              
                DETAILID := FUN_GET_ID('BonusPointsDetail');
              
                INSERT INTO DT_WFJ_BONUSPOINTS_DETAIL
                  (BONUSPOINTSDETAILKEY,
                   BONUSPOINTSDETAILID,
                   BONUSPOINTSDETAILNAME,
                   BONUSPOINTSDETAILDATE,
                   BONUSPOINTSDETAILSCORE,
                   WFJGUIZEID,
                   BONUSPOINTSID,
                   WFJCASHID,
                   WFJGOODID)
                VALUES
                  (DBMS_RANDOM.STRING('x', 32),
                   DETAILID,
                   V_JIFEN_DETAIL_NAME,
                   SYSDATE,
                   TO_CHAR(VI_NUM,
                           'FM999999999999999999999999999999990.999999999'),
                   V_NEW_GUIZE_ID, --规则外键
                   V_NEW_JF_ID,
                   V_NEW_CA_ID, --金币入库单据ID
                   V_NEW_GB_ID);
              
              /*DBMS_LOB.APPEND(V_LOG, '\"积分明细id\":\"' || DETAILID || '\"');
                                                              
                                                                IF I = 1 THEN
                                                                  DBMS_LOB.APPEND(V_LOG, ',');
                                                                END IF;*/
              
              END LOOP;
              /*DBMS_LOB.APPEND(V_LOG, '},');*/
              COMMIT;
              /*DBMS_LOB.APPEND(V_LOG, '\"执行状态\":\"提交\"},');*/
            
            ELSE
            
              ROLLBACK;
            
              /*DBMS_LOB.APPEND(V_LOG,
              '\"修改后剩余积分总数>0\":false,\"执行状态\":\"回滚\"},');*/
            
            END IF;
          
          END IF;
        
          FETCH VCUR_GET_FS
            INTO VI_ACCOUNT, V_SCCID;
        END LOOP;
      
        CLOSE VCUR_GET_FS;
      
        /*DBMS_LOB.APPEND(V_LOG, ']}');*/
      
      ELSE
      
        V_ERR_MSG := '平均数小于0.01，未执行-';
        GOTO PROCESS_ERRMSG;
      
      END IF;
    
    ELSE
    
      V_ERR_MSG := '总数小于0，未执行-';
      GOTO PROCESS_ERRMSG;
    
    END IF;
  
  END IF;

  ROLLBACK;

  DBMS_LOB.APPEND(V_EXE_MSG, '执行成功!');

  SYS_SAVELOG(V_PROC_NAME, 'Y', V_EXE_MSG, V_BEGIN_TIME, V_LOG);

  dbms_lob.freetemporary(V_EXE_MSG);
  dbms_lob.freetemporary(V_LOG);

  --异常处理
  RETURN; --若为顺序执行到此位置，则直接返回

  <<PROCESS_ERRMSG>>
  SYS_PROCESS_ERRMSG(V_PROC_NAME,
                     V_EXE_MSG,
                     V_ERR_MSG,
                     V_BEGIN_TIME,
                     V_LOG,
                     RESULT);
EXCEPTION
  WHEN OTHERS THEN
  
    V_ERR_MSG := 'id:' || V_SCCID || 'SQL CODE:' || SQLCODE || CHR(10) ||
                 SQLERRM || CHR(10) ||
                 DBMS_UTILITY.FORMAT_ERROR_BACKTRACE();
    DBMS_LOB.APPEND(V_EXE_MSG, V_ERR_MSG);
    SYS_SAVELOG(V_PROC_NAME, 'N', V_EXE_MSG, V_BEGIN_TIME, V_LOG);
    RESULT := V_ERR_MSG; --错误号对应的信息
    ROLLBACK;
END GET_ASSIGNN_FSHB_JIFEN;
/

