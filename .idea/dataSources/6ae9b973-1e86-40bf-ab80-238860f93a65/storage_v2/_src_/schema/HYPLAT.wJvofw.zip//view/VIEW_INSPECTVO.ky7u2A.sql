create view VIEW_INSPECTVO as
select s.sikey,
s.siid,
       n.nfcid,
       n.sn,
       n.ln,
       n.model,
       n.oaskname,
       n.en,
       n.bindlocation,
       n.binddate,
       s.sidate,
       s.illustrate,
       s.sitype,
       s.companyid,
       s.companyname,
       s.staffid,
       s.staffname
  from dt_safetyinspect s
  left join dt_nfcchip n
    on s.nfcid = n.nfcid
 where n.bindstate = '00'
/

