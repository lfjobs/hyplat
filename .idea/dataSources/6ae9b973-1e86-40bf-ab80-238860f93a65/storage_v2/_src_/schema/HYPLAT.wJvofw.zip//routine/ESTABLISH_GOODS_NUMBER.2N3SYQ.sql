create PROCEDURE establish_goods_number(parameter_entityName     varchar2,
                                                   parameter_companyID      varchar2,
                                                   parameter_cashierBillsID varchar2,
                                                   parameter_goodsBillsID   varchar2,
                                                   parameter_goodsID        varchar2,
                                                   parameter_status         varchar2,
                                                   parameter_quantity       number,
                                                   parameter_goodsCoding    varchar2) IS
  tmp_no number(38);
  i      number(38);
  gnKey  varchar2(300);
  gnID   varchar2(300);
  ddate  date;
  tmp_sn number(38);
  procedure pro_get_no(parm_companyId in varchar2,
                       parm_goodsid   in varchar2,
                       parm_no        in number,
                       parm_opr       in varchar2) --A 增加
   as
    pragma autonomous_transaction;
  begin
  
    IF parm_opr = 'A' THEN
      begin
        tmp_sn := 0;
        select tb1.goodsnumber
          into tmp_sn
          from dtserialnumber tb1
         where tb1.companyid = parm_companyId
           and tb1.goodsid = parm_goodsid;
      EXCEPTION
        WHEN others THEN
          tmp_sn := 0;
      end;
      if tmp_sn = 0 then
        --如果数据库中没有,增加
        insert into dtserialnumber
          (SERIALNUMBERKEY,
           SERIALNUMBERID,
           COMPANYID,
           GOODSID,
           GOODSNUMBER,
           DATATIME)
        values
          (sys_guid(),
           sys_guid(),
           parm_companyId,
           parm_goodsid,
           parm_no,
           sysdate);
        commit;
      end if;
    else
      --否则更新
      update dtserialnumber u
         set u.goodsnumber = parm_no
       where u.companyid = parm_companyId
         and u.goodsid = parm_goodsid;
      commit;
    end if;
  end pro_get_no;

BEGIN

  --查询该物品保存的最大序号，若无则为0
  tmp_no := 0;
  begin
    select t.goodsnumber
      into tmp_no
      from dtserialnumber t
     where t.companyid = parameter_companyID
       and t.goodsid = parameter_goodsID;
  
  EXCEPTION
    WHEN others THEN
      tmp_no := 0;
  End;
  if tmp_no < 1 then
    --处理完历史数据.删除查询最大编号.
    begin
      select case
               when max(g.goodsnumber) is null then
                '0'
               else
                max(g.goodsnumber)
             end
        into tmp_no
        from dtgoodsnum g
       where g.goodsID = parameter_goodsID
         and g.companyID = parameter_companyID;
    EXCEPTION
      WHEN others THEN
        tmp_no := 0;
    End;
    if tmp_no = 0 then
      tmp_no := 1;
    end if;
    pro_get_no(parameter_companyID, parameter_goodsID, tmp_no, 'A');
  end if;
  select sysdate into ddate from dual;
  i := 0;
  while i < parameter_quantity loop
    --i是从0循环  所以 该次循环所填序号是tmp_no+i的基础上在加1
    tmp_no := tmp_no + i + 1;
    insert into dtgoodsnum
      (gnKey,
       gnID,
       companyID,
       goodsID,
       cashierBillsID,
       goodsBillsID,
       status,
       goodsCoding,
       goodsnumber,
       PHASEDATE)
    values
      (get_Generate_Su('7', '0', '0'),
       get_table_ID('1', parameter_entityName),
       parameter_companyID,
       parameter_goodsID,
       parameter_cashierBillsID,
       parameter_goodsBillsID,
       parameter_status,
       parameter_goodsCoding,
       tmp_no,
       ddate);
    if mod(i, 200) = 0 then
      pro_get_no(parameter_companyID, parameter_goodsID, tmp_no, 'U');
      commit;
    end if;
    i := (i + 1);
  
  end loop;
  pro_get_no(parameter_companyID, parameter_goodsID, tmp_no, 'U');
  commit;

END;
/

